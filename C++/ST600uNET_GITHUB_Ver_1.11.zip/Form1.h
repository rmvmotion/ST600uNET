/********************************************************************
* � 2017 RMV Motion Inc.
*
* SOFTWARE LICENSE AGREEMENT:
* RMV Motion Incorporated ("RMV") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with RMV's
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY RMV "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH RMV'S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL RMV BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF RMV HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, RMV'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO RMV SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  RMV has no obligation to modify, test, 
* certify, or support the code.
*
*******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//                    RMV Motion Inc. 
//                    ST600uNEt.h
//                    ST600uNET_APP Version Ver: 7.11
//                    Author: Albert Tello
/////////////////////////////////////////////////////////////////////////////

#pragma once
#include <string>
#include <msclr\marshal.h>
#include <vcclr.h> 
#include <iostream>
#include "Sequential_Trigger.h"
#include "TrapeziodalParameters.h"
/*
using namespace System;
using namespace msclr::interop;
using namespace std;
*/
 

	using namespace System;
	using namespace System::Resources;
	using namespace msclr::interop;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO; 
	using namespace System::Runtime::InteropServices; // for class Marshal
    using namespace std;
	using namespace msclr::interop;
	using namespace APP_ST600uNet;   

char ProductString[255];
 char SerialNumber[255];
 int MotorSpeed;                            // Hold speed value for all axis
 unsigned  int Acceleration;
 unsigned  int Deceleration; 

 unsigned short int buffer_data[300];
 unsigned short int buffer_data_bckup[300];
 volatile unsigned short int Indx_buffer=0;
 volatile unsigned int motion_counter=0;
 char Error[255];
 
unsigned char  DeviceAddress=0xFF;              //No connected
unsigned char Trigger[4];                       // Array Trigger mask for all controllers

unsigned short int Error_number=0;              // No Error
unsigned char OperatingMode_ADD0;
unsigned char StepResolution_ADD0;
unsigned char ControlMode_ADD0;

unsigned char motor_addr_mask =1;
unsigned char sampling_rate=2; 
unsigned char fifo_enable=0;

 unsigned char sequential_trigger_mask;
 unsigned char seq_motion_controllers_enabled;
 unsigned char pivot_controllers_mask;
	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			 MotAddSelection->SelectedIndex::set(0);                   // Select ADDR 0
			 if (MotAddSelection->SelectedIndex::get()==0){
				motor_addr_mask =1;
			}

		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  OpenDev;
	protected: 

	private: System::Windows::Forms::TextBox^  mbProductString;


	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  mbSerialNumber;
	private: System::Windows::Forms::Button^  CloseConnection;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  mbDevAddr;
	private: System::Windows::Forms::TabControl^  tabControl6;

	private: System::Windows::Forms::TabPage^  tabPage1;



	private: System::Windows::Forms::TabPage^  tabPage5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::NumericUpDown^  Speed1;
	internal: System::Windows::Forms::GroupBox^  MMode1;
	private: 

	private: System::Windows::Forms::RadioButton^  mbCLMode1;
	internal: 
	private: 

	private: System::Windows::Forms::RadioButton^  mbCMode1;
	internal: 

	private: System::Windows::Forms::RadioButton^  mbVMode1;
	private: System::Windows::Forms::GroupBox^  MResulution1;


	private: System::Windows::Forms::RadioButton^  StepRes2;
	private: System::Windows::Forms::RadioButton^  StepRes1;
	private: System::Windows::Forms::RadioButton^  StepRes0;
	private: System::Windows::Forms::RadioButton^  StepRes4;

	private: System::Windows::Forms::RadioButton^  StepRes3;
	private: System::Windows::Forms::RadioButton^  StepRes7;
	private: System::Windows::Forms::RadioButton^  StepRes6;
	private: System::Windows::Forms::RadioButton^  StepRes5;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::NumericUpDown^  SetpNum1;

	private: System::Windows::Forms::NumericUpDown^  Accel1;

	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Button^  Trigger1;
	private: System::Windows::Forms::NumericUpDown^  Decel1;

	private: System::Windows::Forms::Label^  label6;
	internal: System::Windows::Forms::GroupBox^  MControl1;
	private: System::Windows::Forms::RadioButton^  TrapeCtrl1;
	internal: 

	private: System::Windows::Forms::RadioButton^  PosCtrl1;
	internal: 
	private: 



	private: System::Windows::Forms::RadioButton^  SpeedCtrl1;
	internal: 
	private: 



	internal: 


	private: System::Windows::Forms::Button^  Triggeroff1;
	internal: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::RadioButton^  MUnipolar1;
	internal: 
	private: 

	private: System::Windows::Forms::RadioButton^  MBipolar1;
	private: System::Windows::Forms::RichTextBox^  MInduct1;
	internal: 




	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::RichTextBox^  MCurrt1;

	private: System::Windows::Forms::RichTextBox^  MRes1;
	private: System::Windows::Forms::RichTextBox^  MPower1;



	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Button^  MParam1;
private: System::Windows::Forms::Button^  MRParam1;

internal: System::Windows::Forms::GroupBox^  groupBox5;
private: 
private: System::Windows::Forms::Button^  button2;
internal: 
private: System::Windows::Forms::Button^  button3;
private: System::Windows::Forms::RichTextBox^  richTextBox1;
private: System::Windows::Forms::Label^  label12;
private: System::Windows::Forms::RichTextBox^  richTextBox2;
private: System::Windows::Forms::RichTextBox^  richTextBox3;
private: System::Windows::Forms::RichTextBox^  richTextBox4;
private: System::Windows::Forms::Label^  label13;
private: System::Windows::Forms::Label^  label14;
private: System::Windows::Forms::Label^  label15;
private: System::Windows::Forms::RadioButton^  radioButton2;
private: System::Windows::Forms::RadioButton^  radioButton3;
private: System::Windows::Forms::Button^  button4;
internal: System::Windows::Forms::GroupBox^  groupBox6;
private: 
private: System::Windows::Forms::RadioButton^  radioButton4;
internal: 
private: System::Windows::Forms::RadioButton^  radioButton5;
private: System::Windows::Forms::RadioButton^  radioButton6;
private: System::Windows::Forms::NumericUpDown^  numericUpDown2;
private: System::Windows::Forms::Label^  label16;
private: System::Windows::Forms::Button^  button5;
private: System::Windows::Forms::NumericUpDown^  numericUpDown3;
private: System::Windows::Forms::Label^  label17;
private: System::Windows::Forms::NumericUpDown^  numericUpDown4;
private: System::Windows::Forms::Label^  label18;
private: System::Windows::Forms::GroupBox^  groupBox7;
private: System::Windows::Forms::RadioButton^  radioButton7;
private: System::Windows::Forms::RadioButton^  radioButton8;
private: System::Windows::Forms::RadioButton^  radioButton9;
private: System::Windows::Forms::RadioButton^  radioButton10;
private: System::Windows::Forms::RadioButton^  radioButton11;
private: System::Windows::Forms::RadioButton^  radioButton12;
private: System::Windows::Forms::RadioButton^  radioButton13;
private: System::Windows::Forms::RadioButton^  radioButton14;
internal: System::Windows::Forms::GroupBox^  groupBox8;
private: 
private: System::Windows::Forms::RadioButton^  radioButton15;
internal: 
private: System::Windows::Forms::RadioButton^  radioButton16;
private: System::Windows::Forms::RadioButton^  radioButton17;
private: System::Windows::Forms::Label^  label19;
private: System::Windows::Forms::NumericUpDown^  numericUpDown5;
private: System::Windows::Forms::Button^  MConfig1;
private: System::Windows::Forms::Label^  label20;
private: System::Windows::Forms::RichTextBox^  MOLSpeed1;
private: System::Windows::Forms::Button^  Stop1;
private: System::Windows::Forms::RadioButton^  ProfSCtrl1;

private: System::Windows::Forms::Button^  OpeMode1;
private: System::Windows::Forms::Button^  StepResol1;
private: System::Windows::Forms::FolderBrowserDialog^  folderBrowserDialog1;
private: System::Windows::Forms::TabPage^  tabPage6;
private: System::Windows::Forms::GroupBox^  groupBox1;
private: System::Windows::Forms::RadioButton^  Degree1_8;
private: System::Windows::Forms::RadioButton^  Degree0_9;
private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;
private: System::Windows::Forms::SaveFileDialog^  saveFileDialog1;
private: System::Windows::Forms::Panel^  panel1;
private: System::Windows::Forms::GroupBox^  groupBox2;
private: System::Windows::Forms::Button^  OpenFile;





private: System::Windows::Forms::RichTextBox^  StepNumB;

private: System::Windows::Forms::Label^  MotTrapeL;
private: System::Windows::Forms::Button^  SendData;




private: System::Windows::Forms::RichTextBox^  AccelB;


private: System::Windows::Forms::Label^  LabMotB2;
private: System::Windows::Forms::RichTextBox^  SlewRateB;

private: System::Windows::Forms::RichTextBox^  DeccelB;




private: System::Windows::Forms::Label^  LabMotB1;
private: System::Windows::Forms::Label^  LabMotB5;



private: System::Windows::Forms::Label^  LabMotB4;

private: System::Windows::Forms::Label^  LabMotB3;
private: System::Windows::Forms::RichTextBox^  MotCounter;


private: System::Windows::Forms::Label^  label26;
private: System::Windows::Forms::Button^  AddBuffer;
private: System::Windows::Forms::Label^  MotAddress;


private: System::Windows::Forms::Label^  label22;
private: System::Windows::Forms::ListBox^  MotAddSelection;
private: System::Windows::Forms::Label^  label21;
private: System::Windows::Forms::RichTextBox^  ArrayLenght;
private: System::Windows::Forms::RichTextBox^  FifoSpace;
private: System::Windows::Forms::Button^  FIFOfreespace;
private: System::Windows::Forms::Label^  LabMotB6;
private: System::Windows::Forms::RichTextBox^  FirstRateB;

private: System::Windows::Forms::RadioButton^  ScurveCtrl1;

private: System::Windows::Forms::ListBox^  SampleR;
private: System::Windows::Forms::Label^  label23;
private: System::Windows::Forms::Button^  button1;
private: System::Windows::Forms::CheckBox^  FIFOEnable;

private: System::Windows::Forms::Button^  MSAveParam1;

private: System::Windows::Forms::TextBox^  Password;







private: System::Windows::Forms::Timer^  timer1;










private: System::Windows::Forms::RichTextBox^  KFlagsT;












private: System::Windows::Forms::Button^  AdjustMIN;

private: System::Windows::Forms::Button^  AdjustMAX;
private: System::Windows::Forms::ProgressBar^  progressBar1;
private: System::Windows::Forms::Timer^  timer2;
private: System::Windows::Forms::Button^  CurrentSave;
private: System::Windows::Forms::Label^  label31;
private: System::Windows::Forms::Button^  ReportCu;
private: System::Windows::Forms::GroupBox^  groupBox3;
private: System::Windows::Forms::CheckBox^  ZeroCurrAdj;




private: System::Windows::Forms::CheckBox^  CurrentParaSaved;
private: System::Windows::Forms::RichTextBox^  Status;

private: System::Windows::Forms::Label^  label32;
private: System::Windows::Forms::ErrorProvider^  errorProvider1;
private: System::Windows::Forms::Label^  label33;
private: System::Windows::Forms::Label^  label35;
private: System::Windows::Forms::Label^  label34;
private: System::Windows::Forms::CheckBox^  MaxCurrAdj;

private: System::Windows::Forms::TabPage^  tabPage2;
private: System::Windows::Forms::Button^  ReadHex;
private: System::Windows::Forms::TextBox^  Address;



private: System::Windows::Forms::Button^  BootLoader;
private: System::Windows::Forms::RichTextBox^  FlashStatus;
private: System::Windows::Forms::Label^  label37;
private: System::Windows::Forms::Label^  label36;
private: System::Windows::Forms::Button^  BootLoaderInfo;
private: System::Windows::Forms::Button^  ProgramFlash;
private: System::Windows::Forms::Button^  VerifyF;

private: System::Windows::Forms::Button^  EraseF;



private: System::Windows::Forms::Label^  label38;
private: System::Windows::Forms::RichTextBox^  BootL;
private: System::Windows::Forms::Button^  RUN_APP;
private: System::Windows::Forms::Timer^  timer3;
private: System::Windows::Forms::ProgressBar^  FlashProgresBar;
private: System::Windows::Forms::Label^  label39;
private: System::Windows::Forms::Label^  label40;
private: System::Windows::Forms::CheckBox^  SEQ_Event;
private: System::Windows::Forms::Button^  PauseM;
private: System::Windows::Forms::Label^  label41;
private: System::Windows::Forms::Label^  label44;
private: System::Windows::Forms::Label^  label43;
private: System::Windows::Forms::Label^  label42;
internal: System::Windows::Forms::GroupBox^  groupBox9;
private: System::Windows::Forms::Button^  SetHoldingTorque;
internal: 
private: 

private: System::Windows::Forms::RadioButton^  HoldingC25;
internal: 

private: System::Windows::Forms::RadioButton^  HoldingC50;

private: System::Windows::Forms::RadioButton^  HoldingCF;
private: System::Windows::Forms::Button^  CW;
private: System::Windows::Forms::Button^  CCW;


private: System::Windows::Forms::Panel^  panel3;
private: System::Windows::Forms::Button^  Reset;

private: System::Windows::Forms::TextBox^  StepRegister;
private: System::Windows::Forms::Timer^  timer4;
private: System::Windows::Forms::CheckBox^  MCompleated;

private: System::Windows::Forms::Label^  label45;
private: System::Windows::Forms::RadioButton^  Degree1_2;
private: System::Windows::Forms::RadioButton^  Degree0_36;

private: System::Windows::Forms::RadioButton^  Degree0_72;
private: System::Windows::Forms::TabPage^  tabPage3;
private: System::Windows::Forms::Panel^  panel4;



private: System::Windows::Forms::Label^  label46;
private: System::Windows::Forms::Label^  label47;


private: System::Windows::Forms::CheckBox^  Output_0;


private: System::Windows::Forms::Label^  label49;

private: System::Windows::Forms::Label^  label48;
private: System::Windows::Forms::Label^  label50;
private: System::Windows::Forms::CheckBox^  Output_5;
private: System::Windows::Forms::CheckBox^  Output_4;
private: System::Windows::Forms::CheckBox^  Output_3;
private: System::Windows::Forms::CheckBox^  Output_2;
private: System::Windows::Forms::CheckBox^  Output_1;
private: System::Windows::Forms::Panel^  panel5;
private: System::Windows::Forms::CheckBox^  Input_3;
private: System::Windows::Forms::CheckBox^  Input_2;
private: System::Windows::Forms::CheckBox^  Input_1;
private: System::Windows::Forms::CheckBox^  Input_0;
private: System::Windows::Forms::Label^  label52;
private: System::Windows::Forms::Label^  label53;
private: System::Windows::Forms::Label^  label54;
private: System::Windows::Forms::Label^  label55;
private: System::Windows::Forms::Label^  label51;
private: System::Windows::Forms::Button^  SOutPut;

private: System::Windows::Forms::Label^  label56;
private: System::Windows::Forms::TextBox^  A4_20mA;
private: System::Windows::Forms::TextBox^  A5V;
private: System::Windows::Forms::TextBox^  ATemp;
private: System::Windows::Forms::Label^  label59;
private: System::Windows::Forms::Label^  label58;
private: System::Windows::Forms::Label^  label57;
private: System::Windows::Forms::Button^  ReadAnalog;
private: System::Windows::Forms::RadioButton^  ProfTrapCtrl1;

private: System::Windows::Forms::Label^  label60;
private: System::Windows::Forms::Label^  label61;
private: System::Windows::Forms::Label^  label62;







private: System::Windows::Forms::Label^  label63;

private: System::Windows::Forms::Button^  button6;
private: System::Windows::Forms::CheckBox^  OTW_F;

private: System::Windows::Forms::CheckBox^  Fault_F;
private: System::Windows::Forms::TextBox^  Error_Counter;

private: System::Windows::Forms::Label^  label24;
internal: System::Windows::Forms::GroupBox^  groupBox10;
private: System::Windows::Forms::Button^  ErrorClear;
private: System::Windows::Forms::Button^  Jog;
private: System::Windows::Forms::CheckBox^  LSW_Left;
private: System::Windows::Forms::CheckBox^  LSW_Right;



private: System::Windows::Forms::Button^  RdReport;
private: System::Windows::Forms::Panel^  panel2;
private: System::Windows::Forms::Label^  label25;
private: System::Windows::Forms::CheckBox^  Athome;


private: System::Windows::Forms::Button^  SeekH_ccw;

private: System::Windows::Forms::Button^  SeekH_cw;
private: System::Windows::Forms::Timer^  timer5;
private: System::Windows::Forms::Panel^  panel6;
private: System::Windows::Forms::Button^  LimitSW_CCW;




private: System::Windows::Forms::CheckBox^  SW_Left;


private: System::Windows::Forms::Label^  label64;
private: System::Windows::Forms::TextBox^  NumSteppRL_SW;
private: System::Windows::Forms::CheckBox^  SW_Right;
private: System::Windows::Forms::Label^  label65;
private: System::Windows::Forms::Label^  label68;
private: System::Windows::Forms::Label^  label67;
private: System::Windows::Forms::Label^  label66;
private: System::Windows::Forms::Label^  label70;
private: System::Windows::Forms::Label^  label69;
private: System::Windows::Forms::Button^  ReadRp;
private: System::Windows::Forms::Button^  AdjustMiddle;
private: System::Windows::Forms::Label^  label30;
private: System::Windows::Forms::CheckBox^  MiddleCurrAdj;
private: System::Windows::Forms::Label^  label27;
private: System::Windows::Forms::Label^  label72;
private: System::Windows::Forms::Label^  label71;
private: System::Windows::Forms::Label^  label29;
private: System::Windows::Forms::Label^  label28;
private: System::Windows::Forms::Label^  label75;
private: System::Windows::Forms::Label^  label74;
private: System::Windows::Forms::Label^  label73;
private: System::Windows::Forms::Button^  ResetCounters;






internal: 
private: 

internal: 




















private: System::ComponentModel::IContainer^  components;

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->OpenDev = (gcnew System::Windows::Forms::Button());
			this->mbProductString = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->mbSerialNumber = (gcnew System::Windows::Forms::TextBox());
			this->CloseConnection = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->mbDevAddr = (gcnew System::Windows::Forms::TextBox());
			this->tabControl6 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox10 = (gcnew System::Windows::Forms::GroupBox());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->ErrorClear = (gcnew System::Windows::Forms::Button());
			this->Error_Counter = (gcnew System::Windows::Forms::TextBox());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->RdReport = (gcnew System::Windows::Forms::Button());
			this->LSW_Left = (gcnew System::Windows::Forms::CheckBox());
			this->LSW_Right = (gcnew System::Windows::Forms::CheckBox());
			this->Jog = (gcnew System::Windows::Forms::Button());
			this->OTW_F = (gcnew System::Windows::Forms::CheckBox());
			this->Fault_F = (gcnew System::Windows::Forms::CheckBox());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->MCompleated = (gcnew System::Windows::Forms::CheckBox());
			this->StepRegister = (gcnew System::Windows::Forms::TextBox());
			this->Reset = (gcnew System::Windows::Forms::Button());
			this->CW = (gcnew System::Windows::Forms::Button());
			this->CCW = (gcnew System::Windows::Forms::Button());
			this->Stop1 = (gcnew System::Windows::Forms::Button());
			this->Trigger1 = (gcnew System::Windows::Forms::Button());
			this->PauseM = (gcnew System::Windows::Forms::Button());
			this->Triggeroff1 = (gcnew System::Windows::Forms::Button());
			this->groupBox9 = (gcnew System::Windows::Forms::GroupBox());
			this->SetHoldingTorque = (gcnew System::Windows::Forms::Button());
			this->HoldingC25 = (gcnew System::Windows::Forms::RadioButton());
			this->HoldingC50 = (gcnew System::Windows::Forms::RadioButton());
			this->HoldingCF = (gcnew System::Windows::Forms::RadioButton());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->label43 = (gcnew System::Windows::Forms::Label());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->MSAveParam1 = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->Degree0_36 = (gcnew System::Windows::Forms::RadioButton());
			this->Degree0_72 = (gcnew System::Windows::Forms::RadioButton());
			this->Degree1_2 = (gcnew System::Windows::Forms::RadioButton());
			this->Degree0_9 = (gcnew System::Windows::Forms::RadioButton());
			this->Degree1_8 = (gcnew System::Windows::Forms::RadioButton());
			this->MOLSpeed1 = (gcnew System::Windows::Forms::RichTextBox());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->MRParam1 = (gcnew System::Windows::Forms::Button());
			this->MParam1 = (gcnew System::Windows::Forms::Button());
			this->MPower1 = (gcnew System::Windows::Forms::RichTextBox());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->MCurrt1 = (gcnew System::Windows::Forms::RichTextBox());
			this->MRes1 = (gcnew System::Windows::Forms::RichTextBox());
			this->MInduct1 = (gcnew System::Windows::Forms::RichTextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->MUnipolar1 = (gcnew System::Windows::Forms::RadioButton());
			this->MBipolar1 = (gcnew System::Windows::Forms::RadioButton());
			this->MControl1 = (gcnew System::Windows::Forms::GroupBox());
			this->ProfTrapCtrl1 = (gcnew System::Windows::Forms::RadioButton());
			this->SEQ_Event = (gcnew System::Windows::Forms::CheckBox());
			this->FIFOEnable = (gcnew System::Windows::Forms::CheckBox());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->SampleR = (gcnew System::Windows::Forms::ListBox());
			this->ScurveCtrl1 = (gcnew System::Windows::Forms::RadioButton());
			this->ProfSCtrl1 = (gcnew System::Windows::Forms::RadioButton());
			this->MConfig1 = (gcnew System::Windows::Forms::Button());
			this->TrapeCtrl1 = (gcnew System::Windows::Forms::RadioButton());
			this->PosCtrl1 = (gcnew System::Windows::Forms::RadioButton());
			this->SpeedCtrl1 = (gcnew System::Windows::Forms::RadioButton());
			this->Decel1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->Accel1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->SetpNum1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->MResulution1 = (gcnew System::Windows::Forms::GroupBox());
			this->StepResol1 = (gcnew System::Windows::Forms::Button());
			this->StepRes7 = (gcnew System::Windows::Forms::RadioButton());
			this->StepRes6 = (gcnew System::Windows::Forms::RadioButton());
			this->StepRes5 = (gcnew System::Windows::Forms::RadioButton());
			this->StepRes4 = (gcnew System::Windows::Forms::RadioButton());
			this->StepRes3 = (gcnew System::Windows::Forms::RadioButton());
			this->StepRes2 = (gcnew System::Windows::Forms::RadioButton());
			this->StepRes1 = (gcnew System::Windows::Forms::RadioButton());
			this->StepRes0 = (gcnew System::Windows::Forms::RadioButton());
			this->MMode1 = (gcnew System::Windows::Forms::GroupBox());
			this->OpeMode1 = (gcnew System::Windows::Forms::Button());
			this->mbCLMode1 = (gcnew System::Windows::Forms::RadioButton());
			this->mbCMode1 = (gcnew System::Windows::Forms::RadioButton());
			this->mbVMode1 = (gcnew System::Windows::Forms::RadioButton());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->Speed1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->tabPage5 = (gcnew System::Windows::Forms::TabPage());
			this->ResetCounters = (gcnew System::Windows::Forms::Button());
			this->label72 = (gcnew System::Windows::Forms::Label());
			this->label71 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->AdjustMiddle = (gcnew System::Windows::Forms::Button());
			this->label70 = (gcnew System::Windows::Forms::Label());
			this->label69 = (gcnew System::Windows::Forms::Label());
			this->label68 = (gcnew System::Windows::Forms::Label());
			this->label67 = (gcnew System::Windows::Forms::Label());
			this->label66 = (gcnew System::Windows::Forms::Label());
			this->label65 = (gcnew System::Windows::Forms::Label());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->ReadRp = (gcnew System::Windows::Forms::Button());
			this->SW_Right = (gcnew System::Windows::Forms::CheckBox());
			this->LimitSW_CCW = (gcnew System::Windows::Forms::Button());
			this->SW_Left = (gcnew System::Windows::Forms::CheckBox());
			this->label64 = (gcnew System::Windows::Forms::Label());
			this->NumSteppRL_SW = (gcnew System::Windows::Forms::TextBox());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->SeekH_cw = (gcnew System::Windows::Forms::Button());
			this->SeekH_ccw = (gcnew System::Windows::Forms::Button());
			this->Athome = (gcnew System::Windows::Forms::CheckBox());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->Password = (gcnew System::Windows::Forms::TextBox());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->label63 = (gcnew System::Windows::Forms::Label());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->Status = (gcnew System::Windows::Forms::RichTextBox());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->MiddleCurrAdj = (gcnew System::Windows::Forms::CheckBox());
			this->MaxCurrAdj = (gcnew System::Windows::Forms::CheckBox());
			this->ZeroCurrAdj = (gcnew System::Windows::Forms::CheckBox());
			this->CurrentParaSaved = (gcnew System::Windows::Forms::CheckBox());
			this->ReportCu = (gcnew System::Windows::Forms::Button());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->CurrentSave = (gcnew System::Windows::Forms::Button());
			this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
			this->AdjustMAX = (gcnew System::Windows::Forms::Button());
			this->AdjustMIN = (gcnew System::Windows::Forms::Button());
			this->KFlagsT = (gcnew System::Windows::Forms::RichTextBox());
			this->tabPage6 = (gcnew System::Windows::Forms::TabPage());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label62 = (gcnew System::Windows::Forms::Label());
			this->label61 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->FifoSpace = (gcnew System::Windows::Forms::RichTextBox());
			this->FIFOfreespace = (gcnew System::Windows::Forms::Button());
			this->SendData = (gcnew System::Windows::Forms::Button());
			this->MotTrapeL = (gcnew System::Windows::Forms::Label());
			this->OpenFile = (gcnew System::Windows::Forms::Button());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label60 = (gcnew System::Windows::Forms::Label());
			this->LabMotB6 = (gcnew System::Windows::Forms::Label());
			this->FirstRateB = (gcnew System::Windows::Forms::RichTextBox());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->ArrayLenght = (gcnew System::Windows::Forms::RichTextBox());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->AddBuffer = (gcnew System::Windows::Forms::Button());
			this->MotCounter = (gcnew System::Windows::Forms::RichTextBox());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->LabMotB5 = (gcnew System::Windows::Forms::Label());
			this->LabMotB4 = (gcnew System::Windows::Forms::Label());
			this->LabMotB3 = (gcnew System::Windows::Forms::Label());
			this->LabMotB1 = (gcnew System::Windows::Forms::Label());
			this->LabMotB2 = (gcnew System::Windows::Forms::Label());
			this->SlewRateB = (gcnew System::Windows::Forms::RichTextBox());
			this->DeccelB = (gcnew System::Windows::Forms::RichTextBox());
			this->AccelB = (gcnew System::Windows::Forms::RichTextBox());
			this->StepNumB = (gcnew System::Windows::Forms::RichTextBox());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->label39 = (gcnew System::Windows::Forms::Label());
			this->FlashProgresBar = (gcnew System::Windows::Forms::ProgressBar());
			this->RUN_APP = (gcnew System::Windows::Forms::Button());
			this->label38 = (gcnew System::Windows::Forms::Label());
			this->BootL = (gcnew System::Windows::Forms::RichTextBox());
			this->EraseF = (gcnew System::Windows::Forms::Button());
			this->VerifyF = (gcnew System::Windows::Forms::Button());
			this->ProgramFlash = (gcnew System::Windows::Forms::Button());
			this->BootLoaderInfo = (gcnew System::Windows::Forms::Button());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->FlashStatus = (gcnew System::Windows::Forms::RichTextBox());
			this->BootLoader = (gcnew System::Windows::Forms::Button());
			this->ReadHex = (gcnew System::Windows::Forms::Button());
			this->Address = (gcnew System::Windows::Forms::TextBox());
			this->tabPage3 = (gcnew System::Windows::Forms::TabPage());
			this->label75 = (gcnew System::Windows::Forms::Label());
			this->label74 = (gcnew System::Windows::Forms::Label());
			this->label73 = (gcnew System::Windows::Forms::Label());
			this->ReadAnalog = (gcnew System::Windows::Forms::Button());
			this->label59 = (gcnew System::Windows::Forms::Label());
			this->label58 = (gcnew System::Windows::Forms::Label());
			this->label57 = (gcnew System::Windows::Forms::Label());
			this->A4_20mA = (gcnew System::Windows::Forms::TextBox());
			this->A5V = (gcnew System::Windows::Forms::TextBox());
			this->ATemp = (gcnew System::Windows::Forms::TextBox());
			this->label56 = (gcnew System::Windows::Forms::Label());
			this->SOutPut = (gcnew System::Windows::Forms::Button());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->Input_3 = (gcnew System::Windows::Forms::CheckBox());
			this->Input_2 = (gcnew System::Windows::Forms::CheckBox());
			this->Input_1 = (gcnew System::Windows::Forms::CheckBox());
			this->Input_0 = (gcnew System::Windows::Forms::CheckBox());
			this->label52 = (gcnew System::Windows::Forms::Label());
			this->label53 = (gcnew System::Windows::Forms::Label());
			this->label54 = (gcnew System::Windows::Forms::Label());
			this->label55 = (gcnew System::Windows::Forms::Label());
			this->label51 = (gcnew System::Windows::Forms::Label());
			this->label50 = (gcnew System::Windows::Forms::Label());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->Output_5 = (gcnew System::Windows::Forms::CheckBox());
			this->Output_4 = (gcnew System::Windows::Forms::CheckBox());
			this->Output_3 = (gcnew System::Windows::Forms::CheckBox());
			this->Output_2 = (gcnew System::Windows::Forms::CheckBox());
			this->Output_1 = (gcnew System::Windows::Forms::CheckBox());
			this->Output_0 = (gcnew System::Windows::Forms::CheckBox());
			this->label49 = (gcnew System::Windows::Forms::Label());
			this->label48 = (gcnew System::Windows::Forms::Label());
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->MotAddress = (gcnew System::Windows::Forms::Label());
			this->groupBox5 = (gcnew System::Windows::Forms::GroupBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->richTextBox2 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox3 = (gcnew System::Windows::Forms::RichTextBox());
			this->richTextBox4 = (gcnew System::Windows::Forms::RichTextBox());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->radioButton2 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton3 = (gcnew System::Windows::Forms::RadioButton());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->groupBox6 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton4 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton5 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton6 = (gcnew System::Windows::Forms::RadioButton());
			this->numericUpDown2 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->numericUpDown3 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown4 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->groupBox7 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton7 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton8 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton9 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton10 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton11 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton12 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton13 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton14 = (gcnew System::Windows::Forms::RadioButton());
			this->groupBox8 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton15 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton16 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton17 = (gcnew System::Windows::Forms::RadioButton());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown5 = (gcnew System::Windows::Forms::NumericUpDown());
			this->folderBrowserDialog1 = (gcnew System::Windows::Forms::FolderBrowserDialog());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->MotAddSelection = (gcnew System::Windows::Forms::ListBox());
			this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
			this->timer2 = (gcnew System::Windows::Forms::Timer(this->components));
			this->errorProvider1 = (gcnew System::Windows::Forms::ErrorProvider(this->components));
			this->timer3 = (gcnew System::Windows::Forms::Timer(this->components));
			this->timer4 = (gcnew System::Windows::Forms::Timer(this->components));
			this->timer5 = (gcnew System::Windows::Forms::Timer(this->components));
			this->tabControl6->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->groupBox10->SuspendLayout();
			this->panel3->SuspendLayout();
			this->groupBox9->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->MControl1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Decel1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Accel1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->SetpNum1))->BeginInit();
			this->MResulution1->SuspendLayout();
			this->MMode1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Speed1))->BeginInit();
			this->tabPage5->SuspendLayout();
			this->panel6->SuspendLayout();
			this->panel2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->tabPage6->SuspendLayout();
			this->panel1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->tabPage2->SuspendLayout();
			this->tabPage3->SuspendLayout();
			this->panel5->SuspendLayout();
			this->panel4->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->groupBox6->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown4))->BeginInit();
			this->groupBox7->SuspendLayout();
			this->groupBox8->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->errorProvider1))->BeginInit();
			this->SuspendLayout();
			// 
			// OpenDev
			// 
			this->OpenDev->BackColor = System::Drawing::Color::Green;
			this->OpenDev->FlatAppearance->BorderColor = System::Drawing::Color::Silver;
			this->OpenDev->FlatAppearance->BorderSize = 3;
			this->OpenDev->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->OpenDev->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->OpenDev->Location = System::Drawing::Point(3, 12);
			this->OpenDev->Name = L"OpenDev";
			this->OpenDev->Size = System::Drawing::Size(122, 33);
			this->OpenDev->TabIndex = 0;
			this->OpenDev->Text = L"    &Open Connection     ";
			this->OpenDev->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			this->OpenDev->UseVisualStyleBackColor = false;
			this->OpenDev->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// mbProductString
			// 
			this->mbProductString->CharacterCasing = System::Windows::Forms::CharacterCasing::Upper;
			this->mbProductString->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->mbProductString->ForeColor = System::Drawing::Color::Maroon;
			this->mbProductString->Location = System::Drawing::Point(217, 19);
			this->mbProductString->Name = L"mbProductString";
			this->mbProductString->Size = System::Drawing::Size(241, 20);
			this->mbProductString->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(131, 22);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(80, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Product String: ";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(462, 22);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(76, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Serial Number:";
			// 
			// mbSerialNumber
			// 
			this->mbSerialNumber->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->mbSerialNumber->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->mbSerialNumber->Location = System::Drawing::Point(537, 19);
			this->mbSerialNumber->Name = L"mbSerialNumber";
			this->mbSerialNumber->Size = System::Drawing::Size(84, 20);
			this->mbSerialNumber->TabIndex = 4;
			// 
			// CloseConnection
			// 
			this->CloseConnection->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)), 
				static_cast<System::Int32>(static_cast<System::Byte>(128)));
			this->CloseConnection->Enabled = false;
			this->CloseConnection->FlatAppearance->BorderColor = System::Drawing::Color::Silver;
			this->CloseConnection->FlatAppearance->BorderSize = 3;
			this->CloseConnection->FlatStyle = System::Windows::Forms::FlatStyle::System;
			this->CloseConnection->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->CloseConnection->Location = System::Drawing::Point(3, 41);
			this->CloseConnection->Name = L"CloseConnection";
			this->CloseConnection->Size = System::Drawing::Size(122, 29);
			this->CloseConnection->TabIndex = 5;
			this->CloseConnection->Text = L"   &Close Connection ";
			this->CloseConnection->UseVisualStyleBackColor = false;
			this->CloseConnection->Click += gcnew System::EventHandler(this, &Form1::CloseConnection_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(627, 22);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(69, 13);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Device Addr:";
			// 
			// mbDevAddr
			// 
			this->mbDevAddr->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->mbDevAddr->Location = System::Drawing::Point(698, 22);
			this->mbDevAddr->Name = L"mbDevAddr";
			this->mbDevAddr->Size = System::Drawing::Size(32, 20);
			this->mbDevAddr->TabIndex = 7;
			// 
			// tabControl6
			// 
			this->tabControl6->AllowDrop = true;
			this->tabControl6->Controls->Add(this->tabPage1);
			this->tabControl6->Controls->Add(this->tabPage5);
			this->tabControl6->Controls->Add(this->tabPage6);
			this->tabControl6->Controls->Add(this->tabPage2);
			this->tabControl6->Controls->Add(this->tabPage3);
			this->tabControl6->Font = (gcnew System::Drawing::Font(L"Constantia", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->tabControl6->Location = System::Drawing::Point(3, 73);
			this->tabControl6->Multiline = true;
			this->tabControl6->Name = L"tabControl6";
			this->tabControl6->SelectedIndex = 0;
			this->tabControl6->Size = System::Drawing::Size(735, 581);
			this->tabControl6->TabIndex = 8;
			this->tabControl6->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::tabControl6_SelectedIndexChanged);
			// 
			// tabPage1
			// 
			this->tabPage1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)), 
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->tabPage1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::None;
			this->tabPage1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->tabPage1->Controls->Add(this->groupBox10);
			this->tabPage1->Controls->Add(this->panel3);
			this->tabPage1->Controls->Add(this->groupBox9);
			this->tabPage1->Controls->Add(this->label44);
			this->tabPage1->Controls->Add(this->label43);
			this->tabPage1->Controls->Add(this->label42);
			this->tabPage1->Controls->Add(this->label41);
			this->tabPage1->Controls->Add(this->groupBox4);
			this->tabPage1->Controls->Add(this->MControl1);
			this->tabPage1->Controls->Add(this->Decel1);
			this->tabPage1->Controls->Add(this->label6);
			this->tabPage1->Controls->Add(this->Accel1);
			this->tabPage1->Controls->Add(this->label9);
			this->tabPage1->Controls->Add(this->SetpNum1);
			this->tabPage1->Controls->Add(this->label5);
			this->tabPage1->Controls->Add(this->MResulution1);
			this->tabPage1->Controls->Add(this->MMode1);
			this->tabPage1->Controls->Add(this->label4);
			this->tabPage1->Controls->Add(this->Speed1);
			this->tabPage1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->tabPage1->Location = System::Drawing::Point(4, 27);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(727, 550);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"Motion Functions ";
			this->tabPage1->UseVisualStyleBackColor = true;
			this->tabPage1->Click += gcnew System::EventHandler(this, &Form1::tabPage1_Click);
			// 
			// groupBox10
			// 
			this->groupBox10->Controls->Add(this->label24);
			this->groupBox10->Controls->Add(this->ErrorClear);
			this->groupBox10->Controls->Add(this->Error_Counter);
			this->groupBox10->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox10->ForeColor = System::Drawing::Color::Maroon;
			this->groupBox10->Location = System::Drawing::Point(342, 485);
			this->groupBox10->Name = L"groupBox10";
			this->groupBox10->Size = System::Drawing::Size(378, 63);
			this->groupBox10->TabIndex = 102;
			this->groupBox10->TabStop = false;
			this->groupBox10->Text = L"Internal Errors";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label24->Location = System::Drawing::Point(7, 33);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(101, 15);
			this->label24->TabIndex = 111;
			this->label24->Text = L"Error  Counter:";
			// 
			// ErrorClear
			// 
			this->ErrorClear->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ErrorClear->ForeColor = System::Drawing::Color::Red;
			this->ErrorClear->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->ErrorClear->Location = System::Drawing::Point(228, 18);
			this->ErrorClear->Name = L"ErrorClear";
			this->ErrorClear->Size = System::Drawing::Size(144, 30);
			this->ErrorClear->TabIndex = 3;
			this->ErrorClear->Text = L"&Clear Internal Errors ";
			this->ErrorClear->UseVisualStyleBackColor = true;
			this->ErrorClear->Click += gcnew System::EventHandler(this, &Form1::ErrorClear_Click);
			// 
			// Error_Counter
			// 
			this->Error_Counter->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Error_Counter->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->Error_Counter->Location = System::Drawing::Point(114, 26);
			this->Error_Counter->Name = L"Error_Counter";
			this->Error_Counter->ReadOnly = true;
			this->Error_Counter->Size = System::Drawing::Size(105, 22);
			this->Error_Counter->TabIndex = 110;
			this->Error_Counter->Text = L"0";
			// 
			// panel3
			// 
			this->panel3->Controls->Add(this->RdReport);
			this->panel3->Controls->Add(this->LSW_Left);
			this->panel3->Controls->Add(this->LSW_Right);
			this->panel3->Controls->Add(this->Jog);
			this->panel3->Controls->Add(this->OTW_F);
			this->panel3->Controls->Add(this->Fault_F);
			this->panel3->Controls->Add(this->label45);
			this->panel3->Controls->Add(this->MCompleated);
			this->panel3->Controls->Add(this->StepRegister);
			this->panel3->Controls->Add(this->Reset);
			this->panel3->Controls->Add(this->CW);
			this->panel3->Controls->Add(this->CCW);
			this->panel3->Controls->Add(this->Stop1);
			this->panel3->Controls->Add(this->Trigger1);
			this->panel3->Controls->Add(this->PauseM);
			this->panel3->Controls->Add(this->Triggeroff1);
			this->panel3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->panel3->Location = System::Drawing::Point(5, 389);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(335, 163);
			this->panel3->TabIndex = 104;
			// 
			// RdReport
			// 
			this->RdReport->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->RdReport->ForeColor = System::Drawing::Color::SteelBlue;
			this->RdReport->Location = System::Drawing::Point(6, 93);
			this->RdReport->Name = L"RdReport";
			this->RdReport->Size = System::Drawing::Size(154, 23);
			this->RdReport->TabIndex = 113;
			this->RdReport->Text = L"Read Internal Repor&t";
			this->RdReport->UseVisualStyleBackColor = true;
			this->RdReport->Click += gcnew System::EventHandler(this, &Form1::RdReport_Click);
			// 
			// LSW_Left
			// 
			this->LSW_Left->AutoSize = true;
			this->LSW_Left->ForeColor = System::Drawing::Color::Brown;
			this->LSW_Left->Location = System::Drawing::Point(3, 118);
			this->LSW_Left->Name = L"LSW_Left";
			this->LSW_Left->Size = System::Drawing::Size(90, 17);
			this->LSW_Left->TabIndex = 112;
			this->LSW_Left->Text = L"LSW_LEFT";
			this->LSW_Left->UseVisualStyleBackColor = true;
			// 
			// LSW_Right
			// 
			this->LSW_Right->AutoSize = true;
			this->LSW_Right->ForeColor = System::Drawing::Color::Brown;
			this->LSW_Right->Location = System::Drawing::Point(185, 118);
			this->LSW_Right->Name = L"LSW_Right";
			this->LSW_Right->Size = System::Drawing::Size(99, 17);
			this->LSW_Right->TabIndex = 111;
			this->LSW_Right->Text = L"LSW_RIGHT";
			this->LSW_Right->UseVisualStyleBackColor = true;
			// 
			// Jog
			// 
			this->Jog->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Jog->ForeColor = System::Drawing::Color::SaddleBrown;
			this->Jog->Location = System::Drawing::Point(6, 64);
			this->Jog->Name = L"Jog";
			this->Jog->Size = System::Drawing::Size(61, 26);
			this->Jog->TabIndex = 110;
			this->Jog->Text = L"JO&G";
			this->Jog->UseVisualStyleBackColor = true;
			this->Jog->Click += gcnew System::EventHandler(this, &Form1::Jog_Click_2);
			// 
			// OTW_F
			// 
			this->OTW_F->AutoSize = true;
			this->OTW_F->ForeColor = System::Drawing::Color::Red;
			this->OTW_F->Location = System::Drawing::Point(185, 139);
			this->OTW_F->Name = L"OTW_F";
			this->OTW_F->Size = System::Drawing::Size(126, 17);
			this->OTW_F->TabIndex = 109;
			this->OTW_F->Text = L"Driver Over Temp";
			this->OTW_F->UseVisualStyleBackColor = true;
			// 
			// Fault_F
			// 
			this->Fault_F->AutoSize = true;
			this->Fault_F->ForeColor = System::Drawing::Color::Red;
			this->Fault_F->Location = System::Drawing::Point(4, 139);
			this->Fault_F->Name = L"Fault_F";
			this->Fault_F->Size = System::Drawing::Size(140, 17);
			this->Fault_F->TabIndex = 108;
			this->Fault_F->Text = L"Driver Over Current ";
			this->Fault_F->UseVisualStyleBackColor = true;
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label45->Location = System::Drawing::Point(99, 75);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(102, 15);
			this->label45->TabIndex = 107;
			this->label45->Text = L"Step  Counter :";
			// 
			// MCompleated
			// 
			this->MCompleated->AutoSize = true;
			this->MCompleated->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MCompleated->ForeColor = System::Drawing::Color::Navy;
			this->MCompleated->Location = System::Drawing::Point(185, 93);
			this->MCompleated->Name = L"MCompleated";
			this->MCompleated->Size = System::Drawing::Size(147, 19);
			this->MCompleated->TabIndex = 106;
			this->MCompleated->Text = L"Motion Completed ";
			this->MCompleated->UseVisualStyleBackColor = true;
			// 
			// StepRegister
			// 
			this->StepRegister->Location = System::Drawing::Point(200, 74);
			this->StepRegister->Name = L"StepRegister";
			this->StepRegister->ReadOnly = true;
			this->StepRegister->Size = System::Drawing::Size(124, 20);
			this->StepRegister->TabIndex = 105;
			this->StepRegister->Text = L"0";
			// 
			// Reset
			// 
			this->Reset->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->Reset->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Reset->ForeColor = System::Drawing::Color::DarkRed;
			this->Reset->Location = System::Drawing::Point(244, 3);
			this->Reset->Name = L"Reset";
			this->Reset->Size = System::Drawing::Size(80, 37);
			this->Reset->TabIndex = 104;
			this->Reset->Text = L"FUL&L  \r\nRESET ";
			this->Reset->UseVisualStyleBackColor = true;
			this->Reset->Click += gcnew System::EventHandler(this, &Form1::Reset_Click);
			// 
			// CW
			// 
			this->CW->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->CW->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->CW->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->CW->Location = System::Drawing::Point(6, 7);
			this->CW->Name = L"CW";
			this->CW->Size = System::Drawing::Size(64, 31);
			this->CW->TabIndex = 102;
			this->CW->Text = L"&CW";
			this->CW->UseVisualStyleBackColor = true;
			this->CW->Click += gcnew System::EventHandler(this, &Form1::CW_Click);
			// 
			// CCW
			// 
			this->CCW->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->CCW->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->CCW->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->CCW->Location = System::Drawing::Point(74, 6);
			this->CCW->Name = L"CCW";
			this->CCW->Size = System::Drawing::Size(64, 31);
			this->CCW->TabIndex = 103;
			this->CCW->Text = L"CC&W";
			this->CCW->UseVisualStyleBackColor = true;
			this->CCW->Click += gcnew System::EventHandler(this, &Form1::CCW_Click);
			// 
			// Stop1
			// 
			this->Stop1->Font = (gcnew System::Drawing::Font(L"Nina", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Stop1->ForeColor = System::Drawing::Color::Red;
			this->Stop1->Location = System::Drawing::Point(144, 7);
			this->Stop1->Name = L"Stop1";
			this->Stop1->Size = System::Drawing::Size(83, 25);
			this->Stop1->TabIndex = 17;
			this->Stop1->Text = L"&STOP";
			this->Stop1->UseVisualStyleBackColor = true;
			this->Stop1->Click += gcnew System::EventHandler(this, &Form1::Stop1_Click);
			// 
			// Trigger1
			// 
			this->Trigger1->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->Trigger1->Font = (gcnew System::Drawing::Font(L"Nina", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Trigger1->ForeColor = System::Drawing::Color::DarkOliveGreen;
			this->Trigger1->Location = System::Drawing::Point(6, 37);
			this->Trigger1->Name = L"Trigger1";
			this->Trigger1->Size = System::Drawing::Size(107, 25);
			this->Trigger1->TabIndex = 11;
			this->Trigger1->Text = L"&TRIGGER ON";
			this->Trigger1->UseVisualStyleBackColor = true;
			this->Trigger1->Click += gcnew System::EventHandler(this, &Form1::button1_Click_1);
			// 
			// PauseM
			// 
			this->PauseM->Font = (gcnew System::Drawing::Font(L"Nina", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PauseM->ForeColor = System::Drawing::Color::DarkOrange;
			this->PauseM->Location = System::Drawing::Point(244, 43);
			this->PauseM->Name = L"PauseM";
			this->PauseM->Size = System::Drawing::Size(80, 25);
			this->PauseM->TabIndex = 18;
			this->PauseM->Text = L"Pa&use ";
			this->PauseM->UseVisualStyleBackColor = true;
			this->PauseM->Click += gcnew System::EventHandler(this, &Form1::button6_Click_5);
			// 
			// Triggeroff1
			// 
			this->Triggeroff1->Font = (gcnew System::Drawing::Font(L"Nina", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Triggeroff1->ForeColor = System::Drawing::Color::DarkOliveGreen;
			this->Triggeroff1->Location = System::Drawing::Point(113, 37);
			this->Triggeroff1->Name = L"Triggeroff1";
			this->Triggeroff1->Size = System::Drawing::Size(116, 25);
			this->Triggeroff1->TabIndex = 15;
			this->Triggeroff1->Text = L"TRIGGER O&FF";
			this->Triggeroff1->UseVisualStyleBackColor = true;
			this->Triggeroff1->Click += gcnew System::EventHandler(this, &Form1::Triggeroff1_Click);
			// 
			// groupBox9
			// 
			this->groupBox9->Controls->Add(this->SetHoldingTorque);
			this->groupBox9->Controls->Add(this->HoldingC25);
			this->groupBox9->Controls->Add(this->HoldingC50);
			this->groupBox9->Controls->Add(this->HoldingCF);
			this->groupBox9->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox9->ForeColor = System::Drawing::Color::Maroon;
			this->groupBox9->Location = System::Drawing::Point(344, 406);
			this->groupBox9->Name = L"groupBox9";
			this->groupBox9->Size = System::Drawing::Size(378, 77);
			this->groupBox9->TabIndex = 101;
			this->groupBox9->TabStop = false;
			this->groupBox9->Text = L"Holding Torque";
			this->groupBox9->Enter += gcnew System::EventHandler(this, &Form1::groupBox9_Enter);
			// 
			// SetHoldingTorque
			// 
			this->SetHoldingTorque->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SetHoldingTorque->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->SetHoldingTorque->Location = System::Drawing::Point(113, 45);
			this->SetHoldingTorque->Name = L"SetHoldingTorque";
			this->SetHoldingTorque->Size = System::Drawing::Size(155, 28);
			this->SetHoldingTorque->TabIndex = 3;
			this->SetHoldingTorque->Text = L"Set Holding T&orque ";
			this->SetHoldingTorque->UseVisualStyleBackColor = true;
			this->SetHoldingTorque->Click += gcnew System::EventHandler(this, &Form1::SetHoldingTorque_Click);
			// 
			// HoldingC25
			// 
			this->HoldingC25->AutoSize = true;
			this->HoldingC25->ForeColor = System::Drawing::Color::Black;
			this->HoldingC25->Location = System::Drawing::Point(131, 19);
			this->HoldingC25->Name = L"HoldingC25";
			this->HoldingC25->Size = System::Drawing::Size(113, 25);
			this->HoldingC25->TabIndex = 2;
			this->HoldingC25->Text = L"25% Current";
			this->HoldingC25->UseVisualStyleBackColor = true;
			// 
			// HoldingC50
			// 
			this->HoldingC50->AutoSize = true;
			this->HoldingC50->ForeColor = System::Drawing::Color::Black;
			this->HoldingC50->Location = System::Drawing::Point(249, 19);
			this->HoldingC50->Name = L"HoldingC50";
			this->HoldingC50->Size = System::Drawing::Size(117, 25);
			this->HoldingC50->TabIndex = 1;
			this->HoldingC50->Text = L"50% Current ";
			this->HoldingC50->UseVisualStyleBackColor = true;
			// 
			// HoldingCF
			// 
			this->HoldingCF->AutoSize = true;
			this->HoldingCF->Checked = true;
			this->HoldingCF->ForeColor = System::Drawing::Color::Black;
			this->HoldingCF->Location = System::Drawing::Point(13, 20);
			this->HoldingCF->Name = L"HoldingCF";
			this->HoldingCF->Size = System::Drawing::Size(121, 25);
			this->HoldingCF->TabIndex = 0;
			this->HoldingCF->TabStop = true;
			this->HoldingCF->Text = L"100% Current";
			this->HoldingCF->UseVisualStyleBackColor = true;
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->ForeColor = System::Drawing::SystemColors::WindowFrame;
			this->label44->Location = System::Drawing::Point(205, 72);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(133, 13);
			this->label44->TabIndex = 22;
			this->label44->Text = L".POSITION CONTROL";
			// 
			// label43
			// 
			this->label43->AutoSize = true;
			this->label43->ForeColor = System::Drawing::SystemColors::WindowFrame;
			this->label43->Location = System::Drawing::Point(205, 51);
			this->label43->Name = L"label43";
			this->label43->Size = System::Drawing::Size(131, 13);
			this->label43->TabIndex = 21;
			this->label43->Text = L".SPEED CONTROL    ";
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->ForeColor = System::Drawing::SystemColors::WindowFrame;
			this->label42->Location = System::Drawing::Point(205, 30);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(124, 13);
			this->label42->TabIndex = 20;
			this->label42->Text = L"    Changes Only for ";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->ForeColor = System::Drawing::SystemColors::WindowFrame;
			this->label41->Location = System::Drawing::Point(208, 9);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(125, 13);
			this->label41->TabIndex = 19;
			this->label41->Text = L"UP-DOWN   AUTO   ";
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->MSAveParam1);
			this->groupBox4->Controls->Add(this->groupBox1);
			this->groupBox4->Controls->Add(this->MOLSpeed1);
			this->groupBox4->Controls->Add(this->label20);
			this->groupBox4->Controls->Add(this->MRParam1);
			this->groupBox4->Controls->Add(this->MParam1);
			this->groupBox4->Controls->Add(this->MPower1);
			this->groupBox4->Controls->Add(this->label11);
			this->groupBox4->Controls->Add(this->MCurrt1);
			this->groupBox4->Controls->Add(this->MRes1);
			this->groupBox4->Controls->Add(this->MInduct1);
			this->groupBox4->Controls->Add(this->label7);
			this->groupBox4->Controls->Add(this->label8);
			this->groupBox4->Controls->Add(this->label10);
			this->groupBox4->Controls->Add(this->MUnipolar1);
			this->groupBox4->Controls->Add(this->MBipolar1);
			this->groupBox4->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox4->ForeColor = System::Drawing::Color::Maroon;
			this->groupBox4->Location = System::Drawing::Point(5, 101);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(337, 288);
			this->groupBox4->TabIndex = 16;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"Motor Factory Parameters ";
			// 
			// MSAveParam1
			// 
			this->MSAveParam1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MSAveParam1->ForeColor = System::Drawing::Color::SaddleBrown;
			this->MSAveParam1->Location = System::Drawing::Point(15, 259);
			this->MSAveParam1->Name = L"MSAveParam1";
			this->MSAveParam1->Size = System::Drawing::Size(282, 23);
			this->MSAveParam1->TabIndex = 28;
			this->MSAveParam1->Text = L"Save Motor-Motion Parameters to &FLASH ";
			this->MSAveParam1->UseVisualStyleBackColor = true;
			this->MSAveParam1->Click += gcnew System::EventHandler(this, &Form1::MSAveParam1_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->Degree0_36);
			this->groupBox1->Controls->Add(this->Degree0_72);
			this->groupBox1->Controls->Add(this->Degree1_2);
			this->groupBox1->Controls->Add(this->Degree0_9);
			this->groupBox1->Controls->Add(this->Degree1_8);
			this->groupBox1->ForeColor = System::Drawing::Color::SaddleBrown;
			this->groupBox1->Location = System::Drawing::Point(6, 150);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(329, 45);
			this->groupBox1->TabIndex = 27;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Motor Step Angle";
			// 
			// Degree0_36
			// 
			this->Degree0_36->AutoSize = true;
			this->Degree0_36->Font = (gcnew System::Drawing::Font(L"Lucida Fax", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Degree0_36->ForeColor = System::Drawing::Color::Black;
			this->Degree0_36->Location = System::Drawing::Point(263, 20);
			this->Degree0_36->Name = L"Degree0_36";
			this->Degree0_36->Size = System::Drawing::Size(62, 19);
			this->Degree0_36->TabIndex = 4;
			this->Degree0_36->Text = L"0.36*";
			this->Degree0_36->UseVisualStyleBackColor = true;
			// 
			// Degree0_72
			// 
			this->Degree0_72->AutoSize = true;
			this->Degree0_72->Font = (gcnew System::Drawing::Font(L"Lucida Fax", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Degree0_72->ForeColor = System::Drawing::Color::Black;
			this->Degree0_72->Location = System::Drawing::Point(197, 20);
			this->Degree0_72->Name = L"Degree0_72";
			this->Degree0_72->Size = System::Drawing::Size(62, 19);
			this->Degree0_72->TabIndex = 3;
			this->Degree0_72->Text = L"0.72*";
			this->Degree0_72->UseVisualStyleBackColor = true;
			// 
			// Degree1_2
			// 
			this->Degree1_2->AutoSize = true;
			this->Degree1_2->Font = (gcnew System::Drawing::Font(L"Lucida Fax", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Degree1_2->ForeColor = System::Drawing::Color::Black;
			this->Degree1_2->Location = System::Drawing::Point(133, 20);
			this->Degree1_2->Name = L"Degree1_2";
			this->Degree1_2->Size = System::Drawing::Size(53, 19);
			this->Degree1_2->TabIndex = 2;
			this->Degree1_2->Text = L"1.2*";
			this->Degree1_2->UseVisualStyleBackColor = true;
			// 
			// Degree0_9
			// 
			this->Degree0_9->AutoSize = true;
			this->Degree0_9->Font = (gcnew System::Drawing::Font(L"Lucida Fax", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Degree0_9->ForeColor = System::Drawing::Color::Black;
			this->Degree0_9->Location = System::Drawing::Point(68, 20);
			this->Degree0_9->Name = L"Degree0_9";
			this->Degree0_9->Size = System::Drawing::Size(53, 19);
			this->Degree0_9->TabIndex = 1;
			this->Degree0_9->Text = L"0.9*";
			this->Degree0_9->UseVisualStyleBackColor = true;
			// 
			// Degree1_8
			// 
			this->Degree1_8->AutoSize = true;
			this->Degree1_8->Checked = true;
			this->Degree1_8->Font = (gcnew System::Drawing::Font(L"Lucida Fax", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Degree1_8->ForeColor = System::Drawing::Color::Black;
			this->Degree1_8->Location = System::Drawing::Point(6, 20);
			this->Degree1_8->Name = L"Degree1_8";
			this->Degree1_8->Size = System::Drawing::Size(53, 19);
			this->Degree1_8->TabIndex = 0;
			this->Degree1_8->TabStop = true;
			this->Degree1_8->Text = L"1.8*";
			this->Degree1_8->UseVisualStyleBackColor = true;
			this->Degree1_8->CheckedChanged += gcnew System::EventHandler(this, &Form1::radioButton1_CheckedChanged);
			// 
			// MOLSpeed1
			// 
			this->MOLSpeed1->Location = System::Drawing::Point(270, 126);
			this->MOLSpeed1->MaxLength = 10;
			this->MOLSpeed1->Multiline = false;
			this->MOLSpeed1->Name = L"MOLSpeed1";
			this->MOLSpeed1->ReadOnly = true;
			this->MOLSpeed1->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->MOLSpeed1->Size = System::Drawing::Size(61, 21);
			this->MOLSpeed1->TabIndex = 26;
			this->MOLSpeed1->Text = L"0";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label20->ForeColor = System::Drawing::Color::Black;
			this->label20->Location = System::Drawing::Point(12, 134);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(238, 13);
			this->label20->TabIndex = 25;
			this->label20->Text = L"Aprox. Maximum Open Loop Speed at Full Steps:";
			// 
			// MRParam1
			// 
			this->MRParam1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MRParam1->ForeColor = System::Drawing::Color::SaddleBrown;
			this->MRParam1->Location = System::Drawing::Point(47, 230);
			this->MRParam1->Name = L"MRParam1";
			this->MRParam1->Size = System::Drawing::Size(227, 23);
			this->MRParam1->TabIndex = 24;
			this->MRParam1->Text = L"&Read Motor Factory  Parameters ";
			this->MRParam1->UseVisualStyleBackColor = true;
			this->MRParam1->Click += gcnew System::EventHandler(this, &Form1::MRParam1_Click);
			// 
			// MParam1
			// 
			this->MParam1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MParam1->ForeColor = System::Drawing::Color::SaddleBrown;
			this->MParam1->Location = System::Drawing::Point(47, 201);
			this->MParam1->Name = L"MParam1";
			this->MParam1->Size = System::Drawing::Size(227, 23);
			this->MParam1->TabIndex = 23;
			this->MParam1->Text = L"&Set Motor Factory  Parameters ";
			this->MParam1->UseVisualStyleBackColor = true;
			this->MParam1->Click += gcnew System::EventHandler(this, &Form1::MParam1_Click);
			// 
			// MPower1
			// 
			this->MPower1->Location = System::Drawing::Point(270, 107);
			this->MPower1->MaxLength = 10;
			this->MPower1->Multiline = false;
			this->MPower1->Name = L"MPower1";
			this->MPower1->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->MPower1->Size = System::Drawing::Size(61, 21);
			this->MPower1->TabIndex = 22;
			this->MPower1->Text = L"24";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label11->ForeColor = System::Drawing::Color::Black;
			this->label11->Location = System::Drawing::Point(12, 113);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(199, 13);
			this->label11->TabIndex = 21;
			this->label11->Text = L"Motor Power Supply    (from 14V to 50V):";
			// 
			// MCurrt1
			// 
			this->MCurrt1->Location = System::Drawing::Point(270, 86);
			this->MCurrt1->MaxLength = 10;
			this->MCurrt1->Multiline = false;
			this->MCurrt1->Name = L"MCurrt1";
			this->MCurrt1->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->MCurrt1->Size = System::Drawing::Size(61, 21);
			this->MCurrt1->TabIndex = 20;
			this->MCurrt1->Text = L"2000";
			// 
			// MRes1
			// 
			this->MRes1->Location = System::Drawing::Point(270, 45);
			this->MRes1->MaxLength = 10;
			this->MRes1->Multiline = false;
			this->MRes1->Name = L"MRes1";
			this->MRes1->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->MRes1->Size = System::Drawing::Size(61, 21);
			this->MRes1->TabIndex = 19;
			this->MRes1->Text = L"0.56";
			// 
			// MInduct1
			// 
			this->MInduct1->Location = System::Drawing::Point(270, 66);
			this->MInduct1->MaxLength = 10;
			this->MInduct1->Multiline = false;
			this->MInduct1->Name = L"MInduct1";
			this->MInduct1->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->MInduct1->Size = System::Drawing::Size(61, 21);
			this->MInduct1->TabIndex = 18;
			this->MInduct1->Text = L"4.00";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::Black;
			this->label7->Location = System::Drawing::Point(12, 94);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(240, 13);
			this->label7->TabIndex = 16;
			this->label7->Text = L"Motor Winding Current (from 400  to 4000 mAmp):";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::Color::Black;
			this->label8->Location = System::Drawing::Point(12, 75);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(180, 13);
			this->label8->TabIndex = 15;
			this->label8->Text = L"Motor Inductance (Decimal , in mH.):";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::Color::Black;
			this->label10->Location = System::Drawing::Point(12, 55);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(226, 13);
			this->label10->TabIndex = 14;
			this->label10->Text = L"Motor Winding Resistance ( Decimal, in Ohms)";
			// 
			// MUnipolar1
			// 
			this->MUnipolar1->AutoSize = true;
			this->MUnipolar1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MUnipolar1->ForeColor = System::Drawing::Color::Black;
			this->MUnipolar1->Location = System::Drawing::Point(129, 26);
			this->MUnipolar1->Name = L"MUnipolar1";
			this->MUnipolar1->Size = System::Drawing::Size(117, 22);
			this->MUnipolar1->TabIndex = 1;
			this->MUnipolar1->Text = L"Motor Unipolar";
			this->MUnipolar1->UseVisualStyleBackColor = true;
			this->MUnipolar1->CheckedChanged += gcnew System::EventHandler(this, &Form1::MUnipolar1_CheckedChanged);
			// 
			// MBipolar1
			// 
			this->MBipolar1->AutoSize = true;
			this->MBipolar1->Checked = true;
			this->MBipolar1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MBipolar1->ForeColor = System::Drawing::Color::Black;
			this->MBipolar1->Location = System::Drawing::Point(15, 26);
			this->MBipolar1->Name = L"MBipolar1";
			this->MBipolar1->Size = System::Drawing::Size(107, 22);
			this->MBipolar1->TabIndex = 0;
			this->MBipolar1->TabStop = true;
			this->MBipolar1->Text = L"Motor Bipolar";
			this->MBipolar1->UseVisualStyleBackColor = true;
			// 
			// MControl1
			// 
			this->MControl1->Controls->Add(this->ProfTrapCtrl1);
			this->MControl1->Controls->Add(this->SEQ_Event);
			this->MControl1->Controls->Add(this->FIFOEnable);
			this->MControl1->Controls->Add(this->label23);
			this->MControl1->Controls->Add(this->SampleR);
			this->MControl1->Controls->Add(this->ScurveCtrl1);
			this->MControl1->Controls->Add(this->ProfSCtrl1);
			this->MControl1->Controls->Add(this->MConfig1);
			this->MControl1->Controls->Add(this->TrapeCtrl1);
			this->MControl1->Controls->Add(this->PosCtrl1);
			this->MControl1->Controls->Add(this->SpeedCtrl1);
			this->MControl1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MControl1->ForeColor = System::Drawing::Color::Maroon;
			this->MControl1->Location = System::Drawing::Point(343, 206);
			this->MControl1->Name = L"MControl1";
			this->MControl1->Size = System::Drawing::Size(378, 199);
			this->MControl1->TabIndex = 14;
			this->MControl1->TabStop = false;
			this->MControl1->Text = L"Motion Control  Mode ";
			// 
			// ProfTrapCtrl1
			// 
			this->ProfTrapCtrl1->AutoSize = true;
			this->ProfTrapCtrl1->ForeColor = System::Drawing::Color::Black;
			this->ProfTrapCtrl1->Location = System::Drawing::Point(14, 112);
			this->ProfTrapCtrl1->Name = L"ProfTrapCtrl1";
			this->ProfTrapCtrl1->Size = System::Drawing::Size(232, 25);
			this->ProfTrapCtrl1->TabIndex = 16;
			this->ProfTrapCtrl1->TabStop = true;
			this->ProfTrapCtrl1->Text = L"Trapeziodal  Profile Control (F)";
			this->ProfTrapCtrl1->UseVisualStyleBackColor = true;
			this->ProfTrapCtrl1->CheckedChanged += gcnew System::EventHandler(this, &Form1::ProfTrapCtrl1_CheckedChanged);
			// 
			// SEQ_Event
			// 
			this->SEQ_Event->AutoSize = true;
			this->SEQ_Event->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SEQ_Event->ForeColor = System::Drawing::Color::Black;
			this->SEQ_Event->Location = System::Drawing::Point(201, 141);
			this->SEQ_Event->Name = L"SEQ_Event";
			this->SEQ_Event->Size = System::Drawing::Size(176, 22);
			this->SEQ_Event->TabIndex = 15;
			this->SEQ_Event->Text = L"Enable Sequential Motion";
			this->SEQ_Event->UseVisualStyleBackColor = true;
			this->SEQ_Event->CheckedChanged += gcnew System::EventHandler(this, &Form1::SEQ_Event_CheckedChanged);
			// 
			// FIFOEnable
			// 
			this->FIFOEnable->AutoSize = true;
			this->FIFOEnable->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->FIFOEnable->ForeColor = System::Drawing::Color::Black;
			this->FIFOEnable->Location = System::Drawing::Point(14, 141);
			this->FIFOEnable->Name = L"FIFOEnable";
			this->FIFOEnable->Size = System::Drawing::Size(173, 22);
			this->FIFOEnable->TabIndex = 14;
			this->FIFOEnable->Text = L"Enable Data FIFO Buffer";
			this->FIFOEnable->UseVisualStyleBackColor = true;
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Font = (gcnew System::Drawing::Font(L"Lucida Bright", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label23->Location = System::Drawing::Point(198, 19);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(138, 14);
			this->label23->TabIndex = 13;
			this->label23->Text = L"Select Sampling Rate :";
			// 
			// SampleR
			// 
			this->SampleR->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SampleR->ForeColor = System::Drawing::Color::Maroon;
			this->SampleR->FormattingEnabled = true;
			this->SampleR->ItemHeight = 16;
			this->SampleR->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"2 ms", L"1   ms", L"5  ms"});
			this->SampleR->Location = System::Drawing::Point(295, 38);
			this->SampleR->Name = L"SampleR";
			this->SampleR->ScrollAlwaysVisible = true;
			this->SampleR->Size = System::Drawing::Size(76, 20);
			this->SampleR->TabIndex = 12;
			this->SampleR->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::SampleR_SelectedIndexChanged);
			// 
			// ScurveCtrl1
			// 
			this->ScurveCtrl1->AutoSize = true;
			this->ScurveCtrl1->Enabled = false;
			this->ScurveCtrl1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ScurveCtrl1->ForeColor = System::Drawing::Color::Black;
			this->ScurveCtrl1->Location = System::Drawing::Point(14, 63);
			this->ScurveCtrl1->Name = L"ScurveCtrl1";
			this->ScurveCtrl1->Size = System::Drawing::Size(116, 22);
			this->ScurveCtrl1->TabIndex = 4;
			this->ScurveCtrl1->Text = L"S-Curve Motion";
			this->ScurveCtrl1->UseVisualStyleBackColor = true;
			// 
			// ProfSCtrl1
			// 
			this->ProfSCtrl1->AutoSize = true;
			this->ProfSCtrl1->ForeColor = System::Drawing::Color::Black;
			this->ProfSCtrl1->Location = System::Drawing::Point(14, 85);
			this->ProfSCtrl1->Name = L"ProfSCtrl1";
			this->ProfSCtrl1->Size = System::Drawing::Size(195, 25);
			this->ProfSCtrl1->TabIndex = 3;
			this->ProfSCtrl1->TabStop = true;
			this->ProfSCtrl1->Text = L"Speed  Profile Control (F)";
			this->ProfSCtrl1->UseVisualStyleBackColor = true;
			this->ProfSCtrl1->CheckedChanged += gcnew System::EventHandler(this, &Form1::ProfCtrl1_CheckedChanged);
			// 
			// MConfig1
			// 
			this->MConfig1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 11, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MConfig1->ForeColor = System::Drawing::Color::Maroon;
			this->MConfig1->Location = System::Drawing::Point(74, 162);
			this->MConfig1->Name = L"MConfig1";
			this->MConfig1->Size = System::Drawing::Size(222, 26);
			this->MConfig1->TabIndex = 3;
			this->MConfig1->Text = L"Set &All  Motion Configuratiom";
			this->MConfig1->UseVisualStyleBackColor = true;
			this->MConfig1->Click += gcnew System::EventHandler(this, &Form1::MConfig1_Click);
			// 
			// TrapeCtrl1
			// 
			this->TrapeCtrl1->AutoSize = true;
			this->TrapeCtrl1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->TrapeCtrl1->ForeColor = System::Drawing::Color::Black;
			this->TrapeCtrl1->Location = System::Drawing::Point(225, 63);
			this->TrapeCtrl1->Name = L"TrapeCtrl1";
			this->TrapeCtrl1->Size = System::Drawing::Size(146, 22);
			this->TrapeCtrl1->TabIndex = 2;
			this->TrapeCtrl1->Text = L"Trapezoidal  Motion ";
			this->TrapeCtrl1->UseVisualStyleBackColor = true;
			this->TrapeCtrl1->CheckedChanged += gcnew System::EventHandler(this, &Form1::TrapeCtrl1_CheckedChanged);
			// 
			// PosCtrl1
			// 
			this->PosCtrl1->AutoSize = true;
			this->PosCtrl1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PosCtrl1->ForeColor = System::Drawing::Color::Black;
			this->PosCtrl1->Location = System::Drawing::Point(225, 87);
			this->PosCtrl1->Name = L"PosCtrl1";
			this->PosCtrl1->Size = System::Drawing::Size(122, 22);
			this->PosCtrl1->TabIndex = 1;
			this->PosCtrl1->Text = L"Position Control";
			this->PosCtrl1->UseVisualStyleBackColor = true;
			this->PosCtrl1->CheckedChanged += gcnew System::EventHandler(this, &Form1::CtrlPos1_CheckedChanged);
			// 
			// SpeedCtrl1
			// 
			this->SpeedCtrl1->AutoSize = true;
			this->SpeedCtrl1->Checked = true;
			this->SpeedCtrl1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SpeedCtrl1->ForeColor = System::Drawing::Color::Black;
			this->SpeedCtrl1->Location = System::Drawing::Point(14, 36);
			this->SpeedCtrl1->Name = L"SpeedCtrl1";
			this->SpeedCtrl1->Size = System::Drawing::Size(282, 22);
			this->SpeedCtrl1->TabIndex = 0;
			this->SpeedCtrl1->TabStop = true;
			this->SpeedCtrl1->Text = L"Speed Control , Please select Sampling Rate:";
			this->SpeedCtrl1->UseVisualStyleBackColor = true;
			this->SpeedCtrl1->CheckedChanged += gcnew System::EventHandler(this, &Form1::radioButton4_CheckedChanged);
			// 
			// Decel1
			// 
			this->Decel1->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {50, 0, 0, 0});
			this->Decel1->Location = System::Drawing::Point(98, 70);
			this->Decel1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {20000, 0, 0, 0});
			this->Decel1->Name = L"Decel1";
			this->Decel1->Size = System::Drawing::Size(96, 20);
			this->Decel1->TabIndex = 13;
			this->Decel1->ThousandsSeparator = true;
			this->Decel1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(6, 77);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(70, 13);
			this->label6->TabIndex = 12;
			this->label6->Text = L"Deceleration:";
			// 
			// Accel1
			// 
			this->Accel1->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {50, 0, 0, 0});
			this->Accel1->Location = System::Drawing::Point(98, 49);
			this->Accel1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {20000, 0, 0, 0});
			this->Accel1->Name = L"Accel1";
			this->Accel1->Size = System::Drawing::Size(96, 20);
			this->Accel1->TabIndex = 100;
			this->Accel1->ThousandsSeparator = true;
			this->Accel1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->Accel1->ValueChanged += gcnew System::EventHandler(this, &Form1::Accel1_ValueChanged);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(5, 56);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(69, 13);
			this->label9->TabIndex = 9;
			this->label9->Text = L"Acceleration:";
			// 
			// SetpNum1
			// 
			this->SetpNum1->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {1000, 0, 0, 0});
			this->SetpNum1->Location = System::Drawing::Point(98, 7);
			this->SetpNum1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {32000000, 0, 0, 0});
			this->SetpNum1->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {32000000, 0, 0, System::Int32::MinValue});
			this->SetpNum1->Name = L"SetpNum1";
			this->SetpNum1->Size = System::Drawing::Size(97, 20);
			this->SetpNum1->TabIndex = 8;
			this->SetpNum1->ThousandsSeparator = true;
			this->SetpNum1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {5000, 0, 0, 0});
			this->SetpNum1->ValueChanged += gcnew System::EventHandler(this, &Form1::SetpNum1_ValueChanged);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->label5->Location = System::Drawing::Point(6, 12);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(80, 13);
			this->label5->TabIndex = 6;
			this->label5->Text = L"Step Numbers: ";
			// 
			// MResulution1
			// 
			this->MResulution1->Controls->Add(this->StepResol1);
			this->MResulution1->Controls->Add(this->StepRes7);
			this->MResulution1->Controls->Add(this->StepRes6);
			this->MResulution1->Controls->Add(this->StepRes5);
			this->MResulution1->Controls->Add(this->StepRes4);
			this->MResulution1->Controls->Add(this->StepRes3);
			this->MResulution1->Controls->Add(this->StepRes2);
			this->MResulution1->Controls->Add(this->StepRes1);
			this->MResulution1->Controls->Add(this->StepRes0);
			this->MResulution1->Font = (gcnew System::Drawing::Font(L"Georgia", 11, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MResulution1->ForeColor = System::Drawing::Color::DarkOliveGreen;
			this->MResulution1->Location = System::Drawing::Point(346, 86);
			this->MResulution1->Name = L"MResulution1";
			this->MResulution1->Size = System::Drawing::Size(375, 120);
			this->MResulution1->TabIndex = 5;
			this->MResulution1->TabStop = false;
			this->MResulution1->Text = L"Step Resolution ";
			// 
			// StepResol1
			// 
			this->StepResol1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 11.25F, System::Drawing::FontStyle::Bold));
			this->StepResol1->ForeColor = System::Drawing::Color::Maroon;
			this->StepResol1->Location = System::Drawing::Point(230, 86);
			this->StepResol1->Name = L"StepResol1";
			this->StepResol1->Size = System::Drawing::Size(139, 28);
			this->StepResol1->TabIndex = 8;
			this->StepResol1->Text = L"Change Step Re&sol.";
			this->StepResol1->UseVisualStyleBackColor = true;
			this->StepResol1->Click += gcnew System::EventHandler(this, &Form1::StepResol1_Click);
			// 
			// StepRes7
			// 
			this->StepRes7->AutoSize = true;
			this->StepRes7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes7->ForeColor = System::Drawing::Color::Black;
			this->StepRes7->Location = System::Drawing::Point(128, 87);
			this->StepRes7->Name = L"StepRes7";
			this->StepRes7->Size = System::Drawing::Size(99, 21);
			this->StepRes7->TabIndex = 7;
			this->StepRes7->TabStop = true;
			this->StepRes7->Text = L"1/128  Step";
			this->StepRes7->UseVisualStyleBackColor = true;
			// 
			// StepRes6
			// 
			this->StepRes6->AutoSize = true;
			this->StepRes6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes6->ForeColor = System::Drawing::Color::Black;
			this->StepRes6->Location = System::Drawing::Point(22, 87);
			this->StepRes6->Name = L"StepRes6";
			this->StepRes6->Size = System::Drawing::Size(91, 21);
			this->StepRes6->TabIndex = 6;
			this->StepRes6->Text = L"1/64  Step";
			this->StepRes6->UseVisualStyleBackColor = true;
			// 
			// StepRes5
			// 
			this->StepRes5->AutoSize = true;
			this->StepRes5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes5->ForeColor = System::Drawing::Color::Black;
			this->StepRes5->Location = System::Drawing::Point(230, 60);
			this->StepRes5->Name = L"StepRes5";
			this->StepRes5->Size = System::Drawing::Size(91, 21);
			this->StepRes5->TabIndex = 5;
			this->StepRes5->TabStop = true;
			this->StepRes5->Text = L"1/32  Step";
			this->StepRes5->UseVisualStyleBackColor = true;
			// 
			// StepRes4
			// 
			this->StepRes4->AutoSize = true;
			this->StepRes4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes4->ForeColor = System::Drawing::Color::Black;
			this->StepRes4->Location = System::Drawing::Point(128, 60);
			this->StepRes4->Name = L"StepRes4";
			this->StepRes4->Size = System::Drawing::Size(91, 21);
			this->StepRes4->TabIndex = 4;
			this->StepRes4->TabStop = true;
			this->StepRes4->Text = L"1/16  Step";
			this->StepRes4->UseVisualStyleBackColor = true;
			// 
			// StepRes3
			// 
			this->StepRes3->AutoSize = true;
			this->StepRes3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes3->ForeColor = System::Drawing::Color::Black;
			this->StepRes3->Location = System::Drawing::Point(22, 60);
			this->StepRes3->Name = L"StepRes3";
			this->StepRes3->Size = System::Drawing::Size(83, 21);
			this->StepRes3->TabIndex = 3;
			this->StepRes3->TabStop = true;
			this->StepRes3->Text = L"1/8  Step";
			this->StepRes3->UseVisualStyleBackColor = true;
			// 
			// StepRes2
			// 
			this->StepRes2->AutoSize = true;
			this->StepRes2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes2->ForeColor = System::Drawing::Color::Black;
			this->StepRes2->Location = System::Drawing::Point(230, 33);
			this->StepRes2->Name = L"StepRes2";
			this->StepRes2->Size = System::Drawing::Size(83, 21);
			this->StepRes2->TabIndex = 2;
			this->StepRes2->TabStop = true;
			this->StepRes2->Text = L"1/4  Step";
			this->StepRes2->UseVisualStyleBackColor = true;
			// 
			// StepRes1
			// 
			this->StepRes1->AutoSize = true;
			this->StepRes1->Checked = true;
			this->StepRes1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes1->ForeColor = System::Drawing::Color::Black;
			this->StepRes1->Location = System::Drawing::Point(128, 33);
			this->StepRes1->Name = L"StepRes1";
			this->StepRes1->Size = System::Drawing::Size(84, 21);
			this->StepRes1->TabIndex = 1;
			this->StepRes1->TabStop = true;
			this->StepRes1->Text = L"Half Step";
			this->StepRes1->UseVisualStyleBackColor = true;
			// 
			// StepRes0
			// 
			this->StepRes0->AutoSize = true;
			this->StepRes0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepRes0->ForeColor = System::Drawing::Color::Black;
			this->StepRes0->Location = System::Drawing::Point(22, 33);
			this->StepRes0->Name = L"StepRes0";
			this->StepRes0->Size = System::Drawing::Size(81, 21);
			this->StepRes0->TabIndex = 0;
			this->StepRes0->Text = L"Full Step";
			this->StepRes0->UseVisualStyleBackColor = true;
			// 
			// MMode1
			// 
			this->MMode1->Controls->Add(this->OpeMode1);
			this->MMode1->Controls->Add(this->mbCLMode1);
			this->MMode1->Controls->Add(this->mbCMode1);
			this->MMode1->Controls->Add(this->mbVMode1);
			this->MMode1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MMode1->ForeColor = System::Drawing::Color::Maroon;
			this->MMode1->Location = System::Drawing::Point(346, -1);
			this->MMode1->Name = L"MMode1";
			this->MMode1->Size = System::Drawing::Size(378, 86);
			this->MMode1->TabIndex = 4;
			this->MMode1->TabStop = false;
			this->MMode1->Text = L"Operating Mode ";
			// 
			// OpeMode1
			// 
			this->OpeMode1->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->OpeMode1->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->OpeMode1->Location = System::Drawing::Point(128, 50);
			this->OpeMode1->Name = L"OpeMode1";
			this->OpeMode1->Size = System::Drawing::Size(155, 31);
			this->OpeMode1->TabIndex = 3;
			this->OpeMode1->Text = L"Set Operating &Mode ";
			this->OpeMode1->UseVisualStyleBackColor = true;
			this->OpeMode1->Click += gcnew System::EventHandler(this, &Form1::OpeMode1_Click);
			// 
			// mbCLMode1
			// 
			this->mbCLMode1->AutoSize = true;
			this->mbCLMode1->ForeColor = System::Drawing::Color::Black;
			this->mbCLMode1->Location = System::Drawing::Point(251, 23);
			this->mbCLMode1->Name = L"mbCLMode1";
			this->mbCLMode1->Size = System::Drawing::Size(109, 25);
			this->mbCLMode1->TabIndex = 2;
			this->mbCLMode1->Text = L"Closed Loop";
			this->mbCLMode1->UseVisualStyleBackColor = true;
			// 
			// mbCMode1
			// 
			this->mbCMode1->AutoSize = true;
			this->mbCMode1->ForeColor = System::Drawing::Color::Black;
			this->mbCMode1->Location = System::Drawing::Point(128, 23);
			this->mbCMode1->Name = L"mbCMode1";
			this->mbCMode1->Size = System::Drawing::Size(125, 25);
			this->mbCMode1->TabIndex = 1;
			this->mbCMode1->Text = L"Fixed Current ";
			this->mbCMode1->UseVisualStyleBackColor = true;
			// 
			// mbVMode1
			// 
			this->mbVMode1->AutoSize = true;
			this->mbVMode1->Checked = true;
			this->mbVMode1->ForeColor = System::Drawing::Color::Black;
			this->mbVMode1->Location = System::Drawing::Point(11, 23);
			this->mbVMode1->Name = L"mbVMode1";
			this->mbVMode1->Size = System::Drawing::Size(117, 25);
			this->mbVMode1->TabIndex = 0;
			this->mbVMode1->TabStop = true;
			this->mbVMode1->Text = L"Fixed Volatge";
			this->mbVMode1->UseVisualStyleBackColor = true;
			this->mbVMode1->CheckedChanged += gcnew System::EventHandler(this, &Form1::mbVMode1_CheckedChanged);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(6, 35);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(62, 13);
			this->label4->TabIndex = 1;
			this->label4->Text = L"Slew Rate :";
			// 
			// Speed1
			// 
			this->Speed1->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {50, 0, 0, 0});
			this->Speed1->Location = System::Drawing::Point(98, 28);
			this->Speed1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {20000, 0, 0, 0});
			this->Speed1->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {20000, 0, 0, System::Int32::MinValue});
			this->Speed1->Name = L"Speed1";
			this->Speed1->Size = System::Drawing::Size(96, 20);
			this->Speed1->TabIndex = 0;
			this->Speed1->ThousandsSeparator = true;
			this->Speed1->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {500, 0, 0, 0});
			this->Speed1->ValueChanged += gcnew System::EventHandler(this, &Form1::Speed1_ValueChanged);
			// 
			// tabPage5
			// 
			this->tabPage5->BackColor = System::Drawing::Color::Tan;
			this->tabPage5->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->tabPage5->Controls->Add(this->ResetCounters);
			this->tabPage5->Controls->Add(this->label72);
			this->tabPage5->Controls->Add(this->label71);
			this->tabPage5->Controls->Add(this->label29);
			this->tabPage5->Controls->Add(this->label28);
			this->tabPage5->Controls->Add(this->label27);
			this->tabPage5->Controls->Add(this->label30);
			this->tabPage5->Controls->Add(this->AdjustMiddle);
			this->tabPage5->Controls->Add(this->label70);
			this->tabPage5->Controls->Add(this->label69);
			this->tabPage5->Controls->Add(this->label68);
			this->tabPage5->Controls->Add(this->label67);
			this->tabPage5->Controls->Add(this->label66);
			this->tabPage5->Controls->Add(this->label65);
			this->tabPage5->Controls->Add(this->panel6);
			this->tabPage5->Controls->Add(this->panel2);
			this->tabPage5->Controls->Add(this->button6);
			this->tabPage5->Controls->Add(this->label63);
			this->tabPage5->Controls->Add(this->label40);
			this->tabPage5->Controls->Add(this->label35);
			this->tabPage5->Controls->Add(this->label34);
			this->tabPage5->Controls->Add(this->label33);
			this->tabPage5->Controls->Add(this->Status);
			this->tabPage5->Controls->Add(this->label32);
			this->tabPage5->Controls->Add(this->groupBox3);
			this->tabPage5->Controls->Add(this->ReportCu);
			this->tabPage5->Controls->Add(this->label31);
			this->tabPage5->Controls->Add(this->CurrentSave);
			this->tabPage5->Controls->Add(this->progressBar1);
			this->tabPage5->Controls->Add(this->AdjustMAX);
			this->tabPage5->Controls->Add(this->AdjustMIN);
			this->tabPage5->Controls->Add(this->KFlagsT);
			this->tabPage5->Location = System::Drawing::Point(4, 27);
			this->tabPage5->Name = L"tabPage5";
			this->tabPage5->Padding = System::Windows::Forms::Padding(3);
			this->tabPage5->Size = System::Drawing::Size(727, 550);
			this->tabPage5->TabIndex = 4;
			this->tabPage5->Text = L"Motor Internal Functions";
			this->tabPage5->Click += gcnew System::EventHandler(this, &Form1::tabPage5_Click);
			// 
			// ResetCounters
			// 
			this->ResetCounters->ForeColor = System::Drawing::Color::DarkGreen;
			this->ResetCounters->Location = System::Drawing::Point(381, 243);
			this->ResetCounters->Name = L"ResetCounters";
			this->ResetCounters->Size = System::Drawing::Size(334, 34);
			this->ResetCounters->TabIndex = 65;
			this->ResetCounters->Text = L"Reset Motor &Internal Registers - Counters";
			this->ResetCounters->UseVisualStyleBackColor = true;
			this->ResetCounters->Click += gcnew System::EventHandler(this, &Form1::ResetCounters_Click);
			// 
			// label72
			// 
			this->label72->AutoSize = true;
			this->label72->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label72->Location = System::Drawing::Point(15, 89);
			this->label72->Name = L"label72";
			this->label72->Size = System::Drawing::Size(214, 16);
			this->label72->TabIndex = 64;
			this->label72->Text = L"Third: Adjust to Maximum current";
			// 
			// label71
			// 
			this->label71->AutoSize = true;
			this->label71->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label71->Location = System::Drawing::Point(15, 69);
			this->label71->Name = L"label71";
			this->label71->Size = System::Drawing::Size(195, 16);
			this->label71->TabIndex = 63;
			this->label71->Text = L"Second: Adjust to Half current";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label29->Location = System::Drawing::Point(16, 49);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(188, 16);
			this->label29->TabIndex = 62;
			this->label29->Text = L"First : Adjust to Zero current ";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Font = (gcnew System::Drawing::Font(L"Constantia", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label28->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label28->Location = System::Drawing::Point(16, 22);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(178, 18);
			this->label28->TabIndex = 61;
			this->label28->Text = L"please proceed as follows :";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Font = (gcnew System::Drawing::Font(L"Constantia", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label27->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label27->Location = System::Drawing::Point(15, 4);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(310, 18);
			this->label27->TabIndex = 60;
			this->label27->Text = L"In order to adjust the chopper driver current,  ";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(9, 281);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(38, 18);
			this->label30->TabIndex = 59;
			this->label30->Text = L"5) ->";
			// 
			// AdjustMiddle
			// 
			this->AdjustMiddle->Enabled = false;
			this->AdjustMiddle->ForeColor = System::Drawing::Color::Navy;
			this->AdjustMiddle->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->AdjustMiddle->Location = System::Drawing::Point(47, 162);
			this->AdjustMiddle->Name = L"AdjustMiddle";
			this->AdjustMiddle->Size = System::Drawing::Size(266, 27);
			this->AdjustMiddle->TabIndex = 58;
			this->AdjustMiddle->Text = L"Adjust Channels to Half Current";
			this->AdjustMiddle->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->AdjustMiddle->UseVisualStyleBackColor = true;
			this->AdjustMiddle->Click += gcnew System::EventHandler(this, &Form1::AdjustMiddle_Click);
			// 
			// label70
			// 
			this->label70->AutoSize = true;
			this->label70->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label70->Location = System::Drawing::Point(3, 370);
			this->label70->Name = L"label70";
			this->label70->Size = System::Drawing::Size(121, 17);
			this->label70->TabIndex = 57;
			this->label70->Text = L"previous motion.";
			// 
			// label69
			// 
			this->label69->AutoSize = true;
			this->label69->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label69->ForeColor = System::Drawing::Color::Black;
			this->label69->Location = System::Drawing::Point(3, 353);
			this->label69->Name = L"label69";
			this->label69->Size = System::Drawing::Size(281, 17);
			this->label69->TabIndex = 56;
			this->label69->Text = L"Note: the direction must be oposite from,";
			// 
			// label68
			// 
			this->label68->AutoSize = true;
			this->label68->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label68->ForeColor = System::Drawing::Color::Black;
			this->label68->Location = System::Drawing::Point(3, 336);
			this->label68->Name = L"label68";
			this->label68->Size = System::Drawing::Size(297, 17);
			this->label68->TabIndex = 55;
			this->label68->Text = L"Move axixs from Left or Right Limit Switch . ";
			// 
			// label67
			// 
			this->label67->AutoSize = true;
			this->label67->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label67->ForeColor = System::Drawing::Color::Green;
			this->label67->Location = System::Drawing::Point(373, 367);
			this->label67->Name = L"label67";
			this->label67->Size = System::Drawing::Size(187, 17);
			this->label67->TabIndex = 54;
			this->label67->Text = L"indicated in the CheckBox ";
			// 
			// label66
			// 
			this->label66->AutoSize = true;
			this->label66->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label66->ForeColor = System::Drawing::Color::Green;
			this->label66->Location = System::Drawing::Point(378, 350);
			this->label66->Name = L"label66";
			this->label66->Size = System::Drawing::Size(309, 17);
			this->label66->TabIndex = 53;
			this->label66->Text = L"When  Home Limit Switch is reached, will be ";
			// 
			// label65
			// 
			this->label65->AutoSize = true;
			this->label65->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label65->ForeColor = System::Drawing::Color::Green;
			this->label65->Location = System::Drawing::Point(373, 333);
			this->label65->Name = L"label65";
			this->label65->Size = System::Drawing::Size(319, 17);
			this->label65->TabIndex = 52;
			this->label65->Text = L" \"Seek Home Position\" :Please Press CCw or CW";
			// 
			// panel6
			// 
			this->panel6->BackColor = System::Drawing::Color::Cornsilk;
			this->panel6->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel6->Controls->Add(this->ReadRp);
			this->panel6->Controls->Add(this->SW_Right);
			this->panel6->Controls->Add(this->LimitSW_CCW);
			this->panel6->Controls->Add(this->SW_Left);
			this->panel6->Controls->Add(this->label64);
			this->panel6->Controls->Add(this->NumSteppRL_SW);
			this->panel6->Location = System::Drawing::Point(4, 391);
			this->panel6->Name = L"panel6";
			this->panel6->Size = System::Drawing::Size(359, 99);
			this->panel6->TabIndex = 51;
			// 
			// ReadRp
			// 
			this->ReadRp->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->ReadRp->Location = System::Drawing::Point(101, 37);
			this->ReadRp->Name = L"ReadRp";
			this->ReadRp->Size = System::Drawing::Size(126, 24);
			this->ReadRp->TabIndex = 56;
			this->ReadRp->Text = L"Read Report";
			this->ReadRp->UseVisualStyleBackColor = true;
			this->ReadRp->Click += gcnew System::EventHandler(this, &Form1::ReadRp_Click);
			// 
			// SW_Right
			// 
			this->SW_Right->AutoSize = true;
			this->SW_Right->Font = (gcnew System::Drawing::Font(L"Calibri Light", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SW_Right->ForeColor = System::Drawing::Color::Green;
			this->SW_Right->Location = System::Drawing::Point(256, 42);
			this->SW_Right->Name = L"SW_Right";
			this->SW_Right->Size = System::Drawing::Size(99, 22);
			this->SW_Right->TabIndex = 55;
			this->SW_Right->Text = L"SW_RIGHT";
			this->SW_Right->UseVisualStyleBackColor = true;
			this->SW_Right->CheckedChanged += gcnew System::EventHandler(this, &Form1::SW_Right_CheckedChanged);
			// 
			// LimitSW_CCW
			// 
			this->LimitSW_CCW->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->LimitSW_CCW->ForeColor = System::Drawing::Color::DarkOrange;
			this->LimitSW_CCW->Location = System::Drawing::Point(3, 67);
			this->LimitSW_CCW->Name = L"LimitSW_CCW";
			this->LimitSW_CCW->Size = System::Drawing::Size(349, 25);
			this->LimitSW_CCW->TabIndex = 53;
			this->LimitSW_CCW->Text = L"Move C&CW (Steps  -) or CW (Steps +) from Switch ";
			this->LimitSW_CCW->UseVisualStyleBackColor = true;
			this->LimitSW_CCW->Click += gcnew System::EventHandler(this, &Form1::LimitSW_CCW_Click);
			// 
			// SW_Left
			// 
			this->SW_Left->AutoSize = true;
			this->SW_Left->Font = (gcnew System::Drawing::Font(L"Calibri Light", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SW_Left->ForeColor = System::Drawing::Color::Green;
			this->SW_Left->Location = System::Drawing::Point(7, 42);
			this->SW_Left->Name = L"SW_Left";
			this->SW_Left->Size = System::Drawing::Size(88, 22);
			this->SW_Left->TabIndex = 51;
			this->SW_Left->Text = L"SW_LEFT";
			this->SW_Left->UseVisualStyleBackColor = true;
			this->SW_Left->CheckedChanged += gcnew System::EventHandler(this, &Form1::SW_Left_CheckedChanged);
			// 
			// label64
			// 
			this->label64->AutoSize = true;
			this->label64->Location = System::Drawing::Point(70, 11);
			this->label64->Name = L"label64";
			this->label64->Size = System::Drawing::Size(191, 18);
			this->label64->TabIndex = 6;
			this->label64->Text = L"Number of Steps to Move:";
			// 
			// NumSteppRL_SW
			// 
			this->NumSteppRL_SW->Font = (gcnew System::Drawing::Font(L"Ebrima", 11, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->NumSteppRL_SW->Location = System::Drawing::Point(267, 3);
			this->NumSteppRL_SW->MaxLength = 5;
			this->NumSteppRL_SW->Name = L"NumSteppRL_SW";
			this->NumSteppRL_SW->Size = System::Drawing::Size(85, 26);
			this->NumSteppRL_SW->TabIndex = 5;
			this->NumSteppRL_SW->Text = L"0";
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::Cornsilk;
			this->panel2->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel2->Controls->Add(this->SeekH_cw);
			this->panel2->Controls->Add(this->SeekH_ccw);
			this->panel2->Controls->Add(this->Athome);
			this->panel2->Controls->Add(this->label25);
			this->panel2->Controls->Add(this->Password);
			this->panel2->Location = System::Drawing::Point(364, 391);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(351, 99);
			this->panel2->TabIndex = 50;
			// 
			// SeekH_cw
			// 
			this->SeekH_cw->Location = System::Drawing::Point(179, 67);
			this->SeekH_cw->Name = L"SeekH_cw";
			this->SeekH_cw->Size = System::Drawing::Size(165, 25);
			this->SeekH_cw->TabIndex = 54;
			this->SeekH_cw->Text = L"Look Home CW->";
			this->SeekH_cw->UseVisualStyleBackColor = true;
			this->SeekH_cw->Click += gcnew System::EventHandler(this, &Form1::SeekH_cw_Click);
			// 
			// SeekH_ccw
			// 
			this->SeekH_ccw->Location = System::Drawing::Point(3, 67);
			this->SeekH_ccw->Name = L"SeekH_ccw";
			this->SeekH_ccw->Size = System::Drawing::Size(162, 25);
			this->SeekH_ccw->TabIndex = 53;
			this->SeekH_ccw->Text = L"Look Home <-CCW";
			this->SeekH_ccw->UseVisualStyleBackColor = true;
			this->SeekH_ccw->Click += gcnew System::EventHandler(this, &Form1::SeekH_ccw_Click);
			// 
			// Athome
			// 
			this->Athome->AutoSize = true;
			this->Athome->Font = (gcnew System::Drawing::Font(L"Calibri Light", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Athome->ForeColor = System::Drawing::Color::Green;
			this->Athome->Location = System::Drawing::Point(57, 42);
			this->Athome->Name = L"Athome";
			this->Athome->Size = System::Drawing::Size(146, 22);
			this->Athome->TabIndex = 51;
			this->Athome->Text = L"AXIS IS AT HOME ";
			this->Athome->UseVisualStyleBackColor = true;
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(54, 16);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(136, 18);
			this->label25->TabIndex = 6;
			this->label25->Text = L"Position Counter:";
			// 
			// Password
			// 
			this->Password->Font = (gcnew System::Drawing::Font(L"Ebrima", 11, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Password->Location = System::Drawing::Point(211, 10);
			this->Password->MaxLength = 16;
			this->Password->Name = L"Password";
			this->Password->ReadOnly = true;
			this->Password->Size = System::Drawing::Size(125, 26);
			this->Password->TabIndex = 5;
			this->Password->Text = L"0";
			// 
			// button6
			// 
			this->button6->ForeColor = System::Drawing::Color::Olive;
			this->button6->Location = System::Drawing::Point(493, 188);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(193, 37);
			this->button6->TabIndex = 49;
			this->button6->Text = L"&Change System Gain ";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click_6);
			// 
			// label63
			// 
			this->label63->AutoSize = true;
			this->label63->Location = System::Drawing::Point(447, 162);
			this->label63->Name = L"label63";
			this->label63->Size = System::Drawing::Size(127, 18);
			this->label63->TabIndex = 48;
			this->label63->Text = L"System Gain  Ks:";
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Location = System::Drawing::Point(8, 243);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(39, 18);
			this->label40->TabIndex = 47;
			this->label40->Text = L"4) ->";
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(9, 207);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(38, 18);
			this->label35->TabIndex = 46;
			this->label35->Text = L"3) ->";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(9, 168);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(38, 18);
			this->label34->TabIndex = 45;
			this->label34->Text = L"2) ->";
			this->label34->Click += gcnew System::EventHandler(this, &Form1::label34_Click);
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(11, 131);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(36, 18);
			this->label33->TabIndex = 44;
			this->label33->Text = L"1) ->";
			// 
			// Status
			// 
			this->Status->BackColor = System::Drawing::Color::LightGray;
			this->Status->Font = (gcnew System::Drawing::Font(L"Times New Roman", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Status->ForeColor = System::Drawing::Color::Red;
			this->Status->Location = System::Drawing::Point(300, 514);
			this->Status->MaxLength = 15;
			this->Status->Name = L"Status";
			this->Status->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->Status->Size = System::Drawing::Size(417, 26);
			this->Status->TabIndex = 43;
			this->Status->Text = L"";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->label32->Location = System::Drawing::Point(303, 493);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(56, 18);
			this->label32->TabIndex = 42;
			this->label32->Text = L"Status:";
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->MiddleCurrAdj);
			this->groupBox3->Controls->Add(this->MaxCurrAdj);
			this->groupBox3->Controls->Add(this->ZeroCurrAdj);
			this->groupBox3->Controls->Add(this->CurrentParaSaved);
			this->groupBox3->Location = System::Drawing::Point(438, 16);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(254, 133);
			this->groupBox3->TabIndex = 41;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Chopper Driver Status  ";
			// 
			// MiddleCurrAdj
			// 
			this->MiddleCurrAdj->AutoSize = true;
			this->MiddleCurrAdj->ForeColor = System::Drawing::Color::DarkGreen;
			this->MiddleCurrAdj->Location = System::Drawing::Point(14, 73);
			this->MiddleCurrAdj->Name = L"MiddleCurrAdj";
			this->MiddleCurrAdj->Size = System::Drawing::Size(189, 22);
			this->MiddleCurrAdj->TabIndex = 3;
			this->MiddleCurrAdj->Text = L"Half Current Adjusted ";
			this->MiddleCurrAdj->UseVisualStyleBackColor = true;
			// 
			// MaxCurrAdj
			// 
			this->MaxCurrAdj->AutoSize = true;
			this->MaxCurrAdj->ForeColor = System::Drawing::Color::DarkGreen;
			this->MaxCurrAdj->Location = System::Drawing::Point(13, 101);
			this->MaxCurrAdj->Name = L"MaxCurrAdj";
			this->MaxCurrAdj->Size = System::Drawing::Size(235, 22);
			this->MaxCurrAdj->TabIndex = 2;
			this->MaxCurrAdj->Text = L" Maximum Current Adjusted ";
			this->MaxCurrAdj->UseVisualStyleBackColor = true;
			// 
			// ZeroCurrAdj
			// 
			this->ZeroCurrAdj->AutoSize = true;
			this->ZeroCurrAdj->ForeColor = System::Drawing::Color::DarkGreen;
			this->ZeroCurrAdj->Location = System::Drawing::Point(14, 45);
			this->ZeroCurrAdj->Name = L"ZeroCurrAdj";
			this->ZeroCurrAdj->Size = System::Drawing::Size(192, 22);
			this->ZeroCurrAdj->TabIndex = 1;
			this->ZeroCurrAdj->Text = L"Zero Current Adjusted ";
			this->ZeroCurrAdj->UseVisualStyleBackColor = true;
			// 
			// CurrentParaSaved
			// 
			this->CurrentParaSaved->AutoSize = true;
			this->CurrentParaSaved->ForeColor = System::Drawing::Color::DodgerBlue;
			this->CurrentParaSaved->Location = System::Drawing::Point(14, 20);
			this->CurrentParaSaved->Name = L"CurrentParaSaved";
			this->CurrentParaSaved->Size = System::Drawing::Size(220, 22);
			this->CurrentParaSaved->TabIndex = 0;
			this->CurrentParaSaved->Text = L"Current Parameters Saved ";
			this->CurrentParaSaved->UseVisualStyleBackColor = true;
			// 
			// ReportCu
			// 
			this->ReportCu->ForeColor = System::Drawing::Color::OrangeRed;
			this->ReportCu->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->ReportCu->Location = System::Drawing::Point(47, 275);
			this->ReportCu->Name = L"ReportCu";
			this->ReportCu->Size = System::Drawing::Size(266, 24);
			this->ReportCu->TabIndex = 40;
			this->ReportCu->Text = L"  Read &Internal Current Report";
			this->ReportCu->UseVisualStyleBackColor = true;
			this->ReportCu->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(15, 493);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(79, 18);
			this->label31->TabIndex = 39;
			this->label31->Text = L"Progress :";
			// 
			// CurrentSave
			// 
			this->CurrentSave->Cursor = System::Windows::Forms::Cursors::Default;
			this->CurrentSave->ForeColor = System::Drawing::Color::DarkGreen;
			this->CurrentSave->Location = System::Drawing::Point(47, 234);
			this->CurrentSave->Name = L"CurrentSave";
			this->CurrentSave->Size = System::Drawing::Size(266, 27);
			this->CurrentSave->TabIndex = 38;
			this->CurrentSave->Text = L"Sa&ve  All Parameters to FLASH";
			this->CurrentSave->UseVisualStyleBackColor = true;
			this->CurrentSave->Click += gcnew System::EventHandler(this, &Form1::CurrentSave_Click);
			// 
			// progressBar1
			// 
			this->progressBar1->BackColor = System::Drawing::Color::Peru;
			this->progressBar1->ForeColor = System::Drawing::Color::DimGray;
			this->progressBar1->Location = System::Drawing::Point(11, 514);
			this->progressBar1->Name = L"progressBar1";
			this->progressBar1->Size = System::Drawing::Size(248, 23);
			this->progressBar1->TabIndex = 37;
			// 
			// AdjustMAX
			// 
			this->AdjustMAX->Enabled = false;
			this->AdjustMAX->ForeColor = System::Drawing::Color::Brown;
			this->AdjustMAX->Location = System::Drawing::Point(47, 198);
			this->AdjustMAX->Name = L"AdjustMAX";
			this->AdjustMAX->Size = System::Drawing::Size(266, 27);
			this->AdjustMAX->TabIndex = 36;
			this->AdjustMAX->Text = L"A&djust Channels to Max Current";
			this->AdjustMAX->UseVisualStyleBackColor = true;
			this->AdjustMAX->Click += gcnew System::EventHandler(this, &Form1::AdjustMAX_Click);
			// 
			// AdjustMIN
			// 
			this->AdjustMIN->ForeColor = System::Drawing::SystemColors::MenuHighlight;
			this->AdjustMIN->Location = System::Drawing::Point(47, 122);
			this->AdjustMIN->Name = L"AdjustMIN";
			this->AdjustMIN->Size = System::Drawing::Size(266, 27);
			this->AdjustMIN->TabIndex = 35;
			this->AdjustMIN->Text = L"&Adjust Channels to Zero ";
			this->AdjustMIN->UseVisualStyleBackColor = true;
			this->AdjustMIN->Click += gcnew System::EventHandler(this, &Form1::AdjustMIN_Click);
			// 
			// KFlagsT
			// 
			this->KFlagsT->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->KFlagsT->ForeColor = System::Drawing::Color::Red;
			this->KFlagsT->Location = System::Drawing::Point(592, 155);
			this->KFlagsT->MaxLength = 10;
			this->KFlagsT->Multiline = false;
			this->KFlagsT->Name = L"KFlagsT";
			this->KFlagsT->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->KFlagsT->Size = System::Drawing::Size(89, 27);
			this->KFlagsT->TabIndex = 29;
			this->KFlagsT->Text = L"7200";
			this->KFlagsT->TextChanged += gcnew System::EventHandler(this, &Form1::richTextBox5_TextChanged_2);
			// 
			// tabPage6
			// 
			this->tabPage6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)), 
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->tabPage6->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->tabPage6->Controls->Add(this->panel1);
			this->tabPage6->Location = System::Drawing::Point(4, 27);
			this->tabPage6->Name = L"tabPage6";
			this->tabPage6->Padding = System::Windows::Forms::Padding(3);
			this->tabPage6->Size = System::Drawing::Size(727, 550);
			this->tabPage6->TabIndex = 5;
			this->tabPage6->Text = L"Motion Buffer";
			this->tabPage6->UseVisualStyleBackColor = true;
			this->tabPage6->Click += gcnew System::EventHandler(this, &Form1::tabPage6_Click);
			// 
			// panel1
			// 
			this->panel1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel1->Controls->Add(this->label62);
			this->panel1->Controls->Add(this->label61);
			this->panel1->Controls->Add(this->button1);
			this->panel1->Controls->Add(this->FifoSpace);
			this->panel1->Controls->Add(this->FIFOfreespace);
			this->panel1->Controls->Add(this->SendData);
			this->panel1->Controls->Add(this->MotTrapeL);
			this->panel1->Controls->Add(this->OpenFile);
			this->panel1->Controls->Add(this->groupBox2);
			this->panel1->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->panel1->Location = System::Drawing::Point(-2, -3);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(728, 558);
			this->panel1->TabIndex = 0;
			this->panel1->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::panel1_Paint);
			// 
			// label62
			// 
			this->label62->AutoSize = true;
			this->label62->ForeColor = System::Drawing::Color::DarkRed;
			this->label62->Location = System::Drawing::Point(443, 441);
			this->label62->Name = L"label62";
			this->label62->Size = System::Drawing::Size(261, 18);
			this->label62->TabIndex = 8;
			this->label62->Text = L"Maximum  FIFO Lenght : 700 words";
			// 
			// label61
			// 
			this->label61->AutoSize = true;
			this->label61->Location = System::Drawing::Point(664, 331);
			this->label61->Name = L"label61";
			this->label61->Size = System::Drawing::Size(54, 18);
			this->label61->TabIndex = 7;
			this->label61->Text = L"Words";
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(447, 287);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(225, 29);
			this->button1->TabIndex = 6;
			this->button1->Text = L"&Delete FIFO Data";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click_3);
			// 
			// FifoSpace
			// 
			this->FifoSpace->Font = (gcnew System::Drawing::Font(L"Consolas", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->FifoSpace->ForeColor = System::Drawing::Color::DarkOrange;
			this->FifoSpace->Location = System::Drawing::Point(608, 320);
			this->FifoSpace->Name = L"FifoSpace";
			this->FifoSpace->Size = System::Drawing::Size(54, 29);
			this->FifoSpace->TabIndex = 5;
			this->FifoSpace->Text = L"0";
			// 
			// FIFOfreespace
			// 
			this->FIFOfreespace->Font = (gcnew System::Drawing::Font(L"Constantia", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->FIFOfreespace->Location = System::Drawing::Point(447, 322);
			this->FIFOfreespace->Name = L"FIFOfreespace";
			this->FIFOfreespace->Size = System::Drawing::Size(157, 29);
			this->FIFOfreespace->TabIndex = 4;
			this->FIFOfreespace->Text = L"&FIFO  Space  Available";
			this->FIFOfreespace->UseVisualStyleBackColor = true;
			this->FIFOfreespace->Click += gcnew System::EventHandler(this, &Form1::FIFOfreespace_Click);
			// 
			// SendData
			// 
			this->SendData->Font = (gcnew System::Drawing::Font(L"Times New Roman", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SendData->ForeColor = System::Drawing::Color::DarkGreen;
			this->SendData->Location = System::Drawing::Point(447, 390);
			this->SendData->Name = L"SendData";
			this->SendData->Size = System::Drawing::Size(225, 29);
			this->SendData->TabIndex = 3;
			this->SendData->Text = L"&Send Data to RMVuST857 Controller";
			this->SendData->UseVisualStyleBackColor = true;
			this->SendData->Click += gcnew System::EventHandler(this, &Form1::SendData_Click);
			// 
			// MotTrapeL
			// 
			this->MotTrapeL->AutoSize = true;
			this->MotTrapeL->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->MotTrapeL->Font = (gcnew System::Drawing::Font(L"Times New Roman", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MotTrapeL->Location = System::Drawing::Point(455, 46);
			this->MotTrapeL->Name = L"MotTrapeL";
			this->MotTrapeL->Size = System::Drawing::Size(2, 17);
			this->MotTrapeL->TabIndex = 2;
			// 
			// OpenFile
			// 
			this->OpenFile->Location = System::Drawing::Point(447, 355);
			this->OpenFile->Name = L"OpenFile";
			this->OpenFile->Size = System::Drawing::Size(225, 29);
			this->OpenFile->TabIndex = 0;
			this->OpenFile->Text = L"&Open Motion File ";
			this->OpenFile->UseVisualStyleBackColor = true;
			this->OpenFile->Click += gcnew System::EventHandler(this, &Form1::button1_Click_2);
			// 
			// groupBox2
			// 
			this->groupBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->groupBox2->Controls->Add(this->label60);
			this->groupBox2->Controls->Add(this->LabMotB6);
			this->groupBox2->Controls->Add(this->FirstRateB);
			this->groupBox2->Controls->Add(this->label21);
			this->groupBox2->Controls->Add(this->ArrayLenght);
			this->groupBox2->Controls->Add(this->label22);
			this->groupBox2->Controls->Add(this->AddBuffer);
			this->groupBox2->Controls->Add(this->MotCounter);
			this->groupBox2->Controls->Add(this->label26);
			this->groupBox2->Controls->Add(this->LabMotB5);
			this->groupBox2->Controls->Add(this->LabMotB4);
			this->groupBox2->Controls->Add(this->LabMotB3);
			this->groupBox2->Controls->Add(this->LabMotB1);
			this->groupBox2->Controls->Add(this->LabMotB2);
			this->groupBox2->Controls->Add(this->SlewRateB);
			this->groupBox2->Controls->Add(this->DeccelB);
			this->groupBox2->Controls->Add(this->AccelB);
			this->groupBox2->Controls->Add(this->StepNumB);
			this->groupBox2->Font = (gcnew System::Drawing::Font(L"Corbel", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox2->Location = System::Drawing::Point(6, 7);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(431, 544);
			this->groupBox2->TabIndex = 0;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Different Motion  Schemes       ";
			// 
			// label60
			// 
			this->label60->AutoSize = true;
			this->label60->Font = (gcnew System::Drawing::Font(L"Georgia", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label60->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label60->Location = System::Drawing::Point(6, 370);
			this->label60->Name = L"label60";
			this->label60->Size = System::Drawing::Size(325, 18);
			this->label60->TabIndex = 18;
			this->label60->Text = L"Four (4) Motions can be sent  at ones:  56 Bytes";
			// 
			// LabMotB6
			// 
			this->LabMotB6->AutoSize = true;
			this->LabMotB6->Font = (gcnew System::Drawing::Font(L"Rockwell", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->LabMotB6->Location = System::Drawing::Point(6, 260);
			this->LabMotB6->Name = L"LabMotB6";
			this->LabMotB6->Size = System::Drawing::Size(14, 15);
			this->LabMotB6->TabIndex = 17;
			this->LabMotB6->Text = L"*";
			// 
			// FirstRateB
			// 
			this->FirstRateB->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->FirstRateB->Location = System::Drawing::Point(238, 247);
			this->FirstRateB->MaxLength = 6;
			this->FirstRateB->Multiline = false;
			this->FirstRateB->Name = L"FirstRateB";
			this->FirstRateB->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->FirstRateB->Size = System::Drawing::Size(81, 28);
			this->FirstRateB->TabIndex = 16;
			this->FirstRateB->Text = L"0";
			this->FirstRateB->WordWrap = false;
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Font = (gcnew System::Drawing::Font(L"Rockwell", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label21->ForeColor = System::Drawing::Color::Green;
			this->label21->Location = System::Drawing::Point(5, 331);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(232, 15);
			this->label21->TabIndex = 15;
			this->label21->Text = L"Total Motion Array Lenght (words):";
			// 
			// ArrayLenght
			// 
			this->ArrayLenght->Font = (gcnew System::Drawing::Font(L"Eras Medium ITC", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->ArrayLenght->ForeColor = System::Drawing::Color::Teal;
			this->ArrayLenght->Location = System::Drawing::Point(238, 318);
			this->ArrayLenght->Name = L"ArrayLenght";
			this->ArrayLenght->Size = System::Drawing::Size(46, 28);
			this->ArrayLenght->TabIndex = 14;
			this->ArrayLenght->Text = L"0";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Font = (gcnew System::Drawing::Font(L"Nina", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label22->Location = System::Drawing::Point(6, 456);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(425, 14);
			this->label22->TabIndex = 13;
			this->label22->Text = L"After motion buffer has finalized , pelase press Send to RMV858 controller";
			// 
			// AddBuffer
			// 
			this->AddBuffer->Location = System::Drawing::Point(78, 406);
			this->AddBuffer->Name = L"AddBuffer";
			this->AddBuffer->Size = System::Drawing::Size(206, 26);
			this->AddBuffer->TabIndex = 12;
			this->AddBuffer->Text = L"&ADD to Motion Buffer";
			this->AddBuffer->UseVisualStyleBackColor = true;
			this->AddBuffer->Click += gcnew System::EventHandler(this, &Form1::AddBuffer_Click);
			// 
			// MotCounter
			// 
			this->MotCounter->Font = (gcnew System::Drawing::Font(L"Eras Medium ITC", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MotCounter->ForeColor = System::Drawing::Color::Brown;
			this->MotCounter->Location = System::Drawing::Point(238, 284);
			this->MotCounter->Multiline = false;
			this->MotCounter->Name = L"MotCounter";
			this->MotCounter->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->MotCounter->Size = System::Drawing::Size(48, 28);
			this->MotCounter->TabIndex = 11;
			this->MotCounter->Text = L"0";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Font = (gcnew System::Drawing::Font(L"Rockwell", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label26->ForeColor = System::Drawing::Color::Green;
			this->label26->Location = System::Drawing::Point(5, 297);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(122, 15);
			this->label26->TabIndex = 7;
			this->label26->Text = L"Motions Counter :";
			this->label26->Click += gcnew System::EventHandler(this, &Form1::label26_Click);
			// 
			// LabMotB5
			// 
			this->LabMotB5->AutoSize = true;
			this->LabMotB5->Font = (gcnew System::Drawing::Font(L"Rockwell", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->LabMotB5->Location = System::Drawing::Point(6, 226);
			this->LabMotB5->Name = L"LabMotB5";
			this->LabMotB5->Size = System::Drawing::Size(14, 15);
			this->LabMotB5->TabIndex = 10;
			this->LabMotB5->Text = L"*";
			// 
			// LabMotB4
			// 
			this->LabMotB4->AutoSize = true;
			this->LabMotB4->Font = (gcnew System::Drawing::Font(L"Rockwell", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->LabMotB4->Location = System::Drawing::Point(5, 192);
			this->LabMotB4->Name = L"LabMotB4";
			this->LabMotB4->Size = System::Drawing::Size(14, 15);
			this->LabMotB4->TabIndex = 9;
			this->LabMotB4->Text = L"*";
			// 
			// LabMotB3
			// 
			this->LabMotB3->AutoSize = true;
			this->LabMotB3->Font = (gcnew System::Drawing::Font(L"Rockwell", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->LabMotB3->Location = System::Drawing::Point(6, 158);
			this->LabMotB3->Name = L"LabMotB3";
			this->LabMotB3->Size = System::Drawing::Size(14, 15);
			this->LabMotB3->TabIndex = 8;
			this->LabMotB3->Text = L"*";
			this->LabMotB3->Click += gcnew System::EventHandler(this, &Form1::label23_Click);
			// 
			// LabMotB1
			// 
			this->LabMotB1->AutoSize = true;
			this->LabMotB1->Font = (gcnew System::Drawing::Font(L"Corbel", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->LabMotB1->ForeColor = System::Drawing::Color::Maroon;
			this->LabMotB1->Location = System::Drawing::Point(5, 33);
			this->LabMotB1->Name = L"LabMotB1";
			this->LabMotB1->Size = System::Drawing::Size(14, 15);
			this->LabMotB1->TabIndex = 7;
			this->LabMotB1->Text = L"*";
			// 
			// LabMotB2
			// 
			this->LabMotB2->AutoSize = true;
			this->LabMotB2->Font = (gcnew System::Drawing::Font(L"Rockwell", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->LabMotB2->Location = System::Drawing::Point(5, 124);
			this->LabMotB2->Name = L"LabMotB2";
			this->LabMotB2->Size = System::Drawing::Size(14, 15);
			this->LabMotB2->TabIndex = 6;
			this->LabMotB2->Text = L"*";
			// 
			// SlewRateB
			// 
			this->SlewRateB->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->SlewRateB->Location = System::Drawing::Point(238, 213);
			this->SlewRateB->MaxLength = 6;
			this->SlewRateB->Multiline = false;
			this->SlewRateB->Name = L"SlewRateB";
			this->SlewRateB->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->SlewRateB->Size = System::Drawing::Size(81, 28);
			this->SlewRateB->TabIndex = 5;
			this->SlewRateB->Text = L"0";
			this->SlewRateB->WordWrap = false;
			// 
			// DeccelB
			// 
			this->DeccelB->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->DeccelB->Location = System::Drawing::Point(238, 179);
			this->DeccelB->MaxLength = 6;
			this->DeccelB->Multiline = false;
			this->DeccelB->Name = L"DeccelB";
			this->DeccelB->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->DeccelB->Size = System::Drawing::Size(81, 28);
			this->DeccelB->TabIndex = 4;
			this->DeccelB->Text = L"0";
			this->DeccelB->WordWrap = false;
			// 
			// AccelB
			// 
			this->AccelB->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->AccelB->Location = System::Drawing::Point(238, 145);
			this->AccelB->MaxLength = 6;
			this->AccelB->Multiline = false;
			this->AccelB->Name = L"AccelB";
			this->AccelB->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->AccelB->Size = System::Drawing::Size(81, 28);
			this->AccelB->TabIndex = 3;
			this->AccelB->Text = L"0";
			this->AccelB->WordWrap = false;
			this->AccelB->TextChanged += gcnew System::EventHandler(this, &Form1::AccelB_TextChanged);
			// 
			// StepNumB
			// 
			this->StepNumB->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->StepNumB->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->StepNumB->Location = System::Drawing::Point(238, 111);
			this->StepNumB->MaxLength = 10;
			this->StepNumB->Multiline = false;
			this->StepNumB->Name = L"StepNumB";
			this->StepNumB->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->StepNumB->Size = System::Drawing::Size(112, 28);
			this->StepNumB->TabIndex = 1;
			this->StepNumB->Text = L"0";
			this->StepNumB->WordWrap = false;
			this->StepNumB->TextChanged += gcnew System::EventHandler(this, &Form1::richTextBox5_TextChanged);
			// 
			// tabPage2
			// 
			this->tabPage2->BackColor = System::Drawing::Color::DarkKhaki;
			this->tabPage2->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->tabPage2->Controls->Add(this->label39);
			this->tabPage2->Controls->Add(this->FlashProgresBar);
			this->tabPage2->Controls->Add(this->RUN_APP);
			this->tabPage2->Controls->Add(this->label38);
			this->tabPage2->Controls->Add(this->BootL);
			this->tabPage2->Controls->Add(this->EraseF);
			this->tabPage2->Controls->Add(this->VerifyF);
			this->tabPage2->Controls->Add(this->ProgramFlash);
			this->tabPage2->Controls->Add(this->BootLoaderInfo);
			this->tabPage2->Controls->Add(this->label37);
			this->tabPage2->Controls->Add(this->label36);
			this->tabPage2->Controls->Add(this->FlashStatus);
			this->tabPage2->Controls->Add(this->BootLoader);
			this->tabPage2->Controls->Add(this->ReadHex);
			this->tabPage2->Controls->Add(this->Address);
			this->tabPage2->Location = System::Drawing::Point(4, 27);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Size = System::Drawing::Size(727, 550);
			this->tabPage2->TabIndex = 6;
			this->tabPage2->Text = L"Flash Memory Utilities";
			// 
			// label39
			// 
			this->label39->AutoSize = true;
			this->label39->Location = System::Drawing::Point(363, 378);
			this->label39->Name = L"label39";
			this->label39->Size = System::Drawing::Size(79, 18);
			this->label39->TabIndex = 14;
			this->label39->Text = L"Progress :";
			// 
			// FlashProgresBar
			// 
			this->FlashProgresBar->ForeColor = System::Drawing::Color::Maroon;
			this->FlashProgresBar->Location = System::Drawing::Point(448, 370);
			this->FlashProgresBar->Name = L"FlashProgresBar";
			this->FlashProgresBar->Size = System::Drawing::Size(272, 26);
			this->FlashProgresBar->Step = 1;
			this->FlashProgresBar->TabIndex = 13;
			// 
			// RUN_APP
			// 
			this->RUN_APP->Enabled = false;
			this->RUN_APP->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->errorProvider1->SetIconAlignment(this->RUN_APP, System::Windows::Forms::ErrorIconAlignment::BottomLeft);
			this->RUN_APP->Location = System::Drawing::Point(35, 366);
			this->RUN_APP->Name = L"RUN_APP";
			this->RUN_APP->Size = System::Drawing::Size(267, 32);
			this->RUN_APP->TabIndex = 12;
			this->RUN_APP->Text = L"&Run ST600uNet ";
			this->RUN_APP->UseVisualStyleBackColor = true;
			this->RUN_APP->Click += gcnew System::EventHandler(this, &Form1::RUN_APP_Click);
			// 
			// label38
			// 
			this->label38->AutoSize = true;
			this->label38->Location = System::Drawing::Point(141, 42);
			this->label38->Name = L"label38";
			this->label38->Size = System::Drawing::Size(161, 18);
			this->label38->TabIndex = 11;
			this->label38->Text = L"Bootloader Verssion :";
			// 
			// BootL
			// 
			this->BootL->Font = (gcnew System::Drawing::Font(L"Courier New", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->BootL->ForeColor = System::Drawing::Color::ForestGreen;
			this->BootL->Location = System::Drawing::Point(366, 42);
			this->BootL->Name = L"BootL";
			this->BootL->Size = System::Drawing::Size(212, 27);
			this->BootL->TabIndex = 10;
			this->BootL->Text = L"BootLoader";
			// 
			// EraseF
			// 
			this->EraseF->Enabled = false;
			this->EraseF->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->errorProvider1->SetIconAlignment(this->EraseF, System::Windows::Forms::ErrorIconAlignment::BottomLeft);
			this->EraseF->Location = System::Drawing::Point(448, 267);
			this->EraseF->Name = L"EraseF";
			this->EraseF->Size = System::Drawing::Size(267, 32);
			this->EraseF->TabIndex = 9;
			this->EraseF->Text = L"&Erase Flash Memory ";
			this->EraseF->UseVisualStyleBackColor = true;
			this->EraseF->Click += gcnew System::EventHandler(this, &Form1::button7_Click_1);
			// 
			// VerifyF
			// 
			this->VerifyF->Enabled = false;
			this->VerifyF->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->errorProvider1->SetIconAlignment(this->VerifyF, System::Windows::Forms::ErrorIconAlignment::BottomLeft);
			this->VerifyF->Location = System::Drawing::Point(35, 317);
			this->VerifyF->Name = L"VerifyF";
			this->VerifyF->Size = System::Drawing::Size(267, 32);
			this->VerifyF->TabIndex = 8;
			this->VerifyF->Text = L"Verify  FlashMemory";
			this->VerifyF->UseVisualStyleBackColor = true;
			this->VerifyF->Click += gcnew System::EventHandler(this, &Form1::button6_Click_3);
			// 
			// ProgramFlash
			// 
			this->ProgramFlash->Enabled = false;
			this->ProgramFlash->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->errorProvider1->SetIconAlignment(this->ProgramFlash, System::Windows::Forms::ErrorIconAlignment::BottomLeft);
			this->ProgramFlash->Location = System::Drawing::Point(447, 317);
			this->ProgramFlash->Name = L"ProgramFlash";
			this->ProgramFlash->Size = System::Drawing::Size(267, 32);
			this->ProgramFlash->TabIndex = 7;
			this->ProgramFlash->Text = L"Program Flash";
			this->ProgramFlash->UseVisualStyleBackColor = true;
			this->ProgramFlash->Click += gcnew System::EventHandler(this, &Form1::ProgramFlash_Click);
			// 
			// BootLoaderInfo
			// 
			this->BootLoaderInfo->Enabled = false;
			this->BootLoaderInfo->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->errorProvider1->SetIconAlignment(this->BootLoaderInfo, System::Windows::Forms::ErrorIconAlignment::BottomLeft);
			this->BootLoaderInfo->Location = System::Drawing::Point(448, 221);
			this->BootLoaderInfo->Name = L"BootLoaderInfo";
			this->BootLoaderInfo->Size = System::Drawing::Size(267, 32);
			this->BootLoaderInfo->TabIndex = 6;
			this->BootLoaderInfo->Text = L"BootLoader &Version";
			this->BootLoaderInfo->UseVisualStyleBackColor = true;
			this->BootLoaderInfo->Click += gcnew System::EventHandler(this, &Form1::BootLoaderInfo_Click);
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->ForeColor = System::Drawing::Color::SeaGreen;
			this->label37->Location = System::Drawing::Point(32, 154);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(99, 18);
			this->label37->TabIndex = 5;
			this->label37->Text = L"File Address:";
			this->label37->Click += gcnew System::EventHandler(this, &Form1::label37_Click);
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->ForeColor = System::Drawing::Color::Maroon;
			this->label36->Location = System::Drawing::Point(3, 503);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(56, 18);
			this->label36->TabIndex = 4;
			this->label36->Text = L"Status:";
			// 
			// FlashStatus
			// 
			this->FlashStatus->BackColor = System::Drawing::Color::Gainsboro;
			this->FlashStatus->ForeColor = System::Drawing::Color::DarkGreen;
			this->FlashStatus->Location = System::Drawing::Point(60, 496);
			this->FlashStatus->Name = L"FlashStatus";
			this->FlashStatus->Size = System::Drawing::Size(654, 25);
			this->FlashStatus->TabIndex = 3;
			this->FlashStatus->Text = L"";
			// 
			// BootLoader
			// 
			this->BootLoader->ForeColor = System::Drawing::Color::SaddleBrown;
			this->BootLoader->Location = System::Drawing::Point(35, 223);
			this->BootLoader->Name = L"BootLoader";
			this->BootLoader->Size = System::Drawing::Size(267, 30);
			this->BootLoader->TabIndex = 2;
			this->BootLoader->Text = L"<Enter>  Bootloader Mode";
			this->BootLoader->UseVisualStyleBackColor = true;
			this->BootLoader->Click += gcnew System::EventHandler(this, &Form1::BootLoader_Click);
			// 
			// ReadHex
			// 
			this->ReadHex->Enabled = false;
			this->ReadHex->FlatAppearance->BorderColor = System::Drawing::Color::White;
			this->errorProvider1->SetIconAlignment(this->ReadHex, System::Windows::Forms::ErrorIconAlignment::BottomLeft);
			this->ReadHex->Location = System::Drawing::Point(35, 267);
			this->ReadHex->Name = L"ReadHex";
			this->ReadHex->Size = System::Drawing::Size(267, 32);
			this->ReadHex->TabIndex = 1;
			this->ReadHex->Text = L"Load &Hex File";
			this->ReadHex->UseVisualStyleBackColor = true;
			this->ReadHex->Click += gcnew System::EventHandler(this, &Form1::button6_Click_2);
			// 
			// Address
			// 
			this->Address->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->Address->Font = (gcnew System::Drawing::Font(L"Euro Sign", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Address->Location = System::Drawing::Point(34, 175);
			this->Address->Name = L"Address";
			this->Address->ReadOnly = true;
			this->Address->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->Address->Size = System::Drawing::Size(680, 27);
			this->Address->TabIndex = 0;
			// 
			// tabPage3
			// 
			this->tabPage3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(255)), 
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->tabPage3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->tabPage3->Controls->Add(this->label75);
			this->tabPage3->Controls->Add(this->label74);
			this->tabPage3->Controls->Add(this->label73);
			this->tabPage3->Controls->Add(this->ReadAnalog);
			this->tabPage3->Controls->Add(this->label59);
			this->tabPage3->Controls->Add(this->label58);
			this->tabPage3->Controls->Add(this->label57);
			this->tabPage3->Controls->Add(this->A4_20mA);
			this->tabPage3->Controls->Add(this->A5V);
			this->tabPage3->Controls->Add(this->ATemp);
			this->tabPage3->Controls->Add(this->label56);
			this->tabPage3->Controls->Add(this->SOutPut);
			this->tabPage3->Controls->Add(this->panel5);
			this->tabPage3->Controls->Add(this->label51);
			this->tabPage3->Controls->Add(this->label50);
			this->tabPage3->Controls->Add(this->panel4);
			this->tabPage3->Location = System::Drawing::Point(4, 27);
			this->tabPage3->Name = L"tabPage3";
			this->tabPage3->Padding = System::Windows::Forms::Padding(3);
			this->tabPage3->Size = System::Drawing::Size(727, 550);
			this->tabPage3->TabIndex = 7;
			this->tabPage3->Text = L"IO\'s ";
			// 
			// label75
			// 
			this->label75->AutoSize = true;
			this->label75->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label75->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label75->Location = System::Drawing::Point(416, 436);
			this->label75->Name = L"label75";
			this->label75->Size = System::Drawing::Size(58, 18);
			this->label75->TabIndex = 16;
			this->label75->Text = L"ADDR3";
			// 
			// label74
			// 
			this->label74->AutoSize = true;
			this->label74->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label74->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label74->Location = System::Drawing::Point(416, 404);
			this->label74->Name = L"label74";
			this->label74->Size = System::Drawing::Size(58, 18);
			this->label74->TabIndex = 15;
			this->label74->Text = L"ADDR2";
			// 
			// label73
			// 
			this->label73->AutoSize = true;
			this->label73->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label73->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label73->Location = System::Drawing::Point(416, 372);
			this->label73->Name = L"label73";
			this->label73->Size = System::Drawing::Size(58, 18);
			this->label73->TabIndex = 15;
			this->label73->Text = L"ADDR1";
			// 
			// ReadAnalog
			// 
			this->ReadAnalog->ForeColor = System::Drawing::Color::Green;
			this->ReadAnalog->Location = System::Drawing::Point(160, 479);
			this->ReadAnalog->Name = L"ReadAnalog";
			this->ReadAnalog->Size = System::Drawing::Size(385, 33);
			this->ReadAnalog->TabIndex = 14;
			this->ReadAnalog->Text = L"Read &Analog Channels  from the Address Selected ";
			this->ReadAnalog->UseVisualStyleBackColor = true;
			this->ReadAnalog->Click += gcnew System::EventHandler(this, &Form1::ReadAnalog_Click);
			// 
			// label59
			// 
			this->label59->AutoSize = true;
			this->label59->Location = System::Drawing::Point(188, 404);
			this->label59->Name = L"label59";
			this->label59->Size = System::Drawing::Size(69, 18);
			this->label59->TabIndex = 13;
			this->label59->Text = L"4-20 mA:";
			// 
			// label58
			// 
			this->label58->AutoSize = true;
			this->label58->Location = System::Drawing::Point(188, 436);
			this->label58->Name = L"label58";
			this->label58->Size = System::Drawing::Size(73, 18);
			this->label58->TabIndex = 12;
			this->label58->Text = L"0-5 Volts:";
			// 
			// label57
			// 
			this->label57->AutoSize = true;
			this->label57->Location = System::Drawing::Point(88, 372);
			this->label57->Name = L"label57";
			this->label57->Size = System::Drawing::Size(173, 18);
			this->label57->TabIndex = 11;
			this->label57->Text = L"Heatsink Temperature:";
			// 
			// A4_20mA
			// 
			this->A4_20mA->Location = System::Drawing::Point(267, 396);
			this->A4_20mA->Name = L"A4_20mA";
			this->A4_20mA->ReadOnly = true;
			this->A4_20mA->Size = System::Drawing::Size(127, 26);
			this->A4_20mA->TabIndex = 10;
			// 
			// A5V
			// 
			this->A5V->Location = System::Drawing::Point(267, 428);
			this->A5V->Name = L"A5V";
			this->A5V->ReadOnly = true;
			this->A5V->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->A5V->Size = System::Drawing::Size(127, 26);
			this->A5V->TabIndex = 9;
			// 
			// ATemp
			// 
			this->ATemp->Location = System::Drawing::Point(267, 364);
			this->ATemp->Name = L"ATemp";
			this->ATemp->ReadOnly = true;
			this->ATemp->Size = System::Drawing::Size(127, 26);
			this->ATemp->TabIndex = 8;
			// 
			// label56
			// 
			this->label56->AutoSize = true;
			this->label56->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Underline, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label56->ForeColor = System::Drawing::Color::Maroon;
			this->label56->Location = System::Drawing::Point(272, 334);
			this->label56->Name = L"label56";
			this->label56->Size = System::Drawing::Size(109, 18);
			this->label56->TabIndex = 6;
			this->label56->Text = L"Analog Input";
			this->label56->Click += gcnew System::EventHandler(this, &Form1::label56_Click);
			// 
			// SOutPut
			// 
			this->SOutPut->ForeColor = System::Drawing::Color::Green;
			this->SOutPut->Location = System::Drawing::Point(102, 271);
			this->SOutPut->Name = L"SOutPut";
			this->SOutPut->Size = System::Drawing::Size(533, 33);
			this->SOutPut->TabIndex = 4;
			this->SOutPut->Text = L"Update Digital Input  and Output for the Address Selected ";
			this->SOutPut->UseVisualStyleBackColor = true;
			this->SOutPut->Click += gcnew System::EventHandler(this, &Form1::SOutPut_Click);
			// 
			// panel5
			// 
			this->panel5->AccessibleName = L"";
			this->panel5->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel5->Controls->Add(this->Input_3);
			this->panel5->Controls->Add(this->Input_2);
			this->panel5->Controls->Add(this->Input_1);
			this->panel5->Controls->Add(this->Input_0);
			this->panel5->Controls->Add(this->label52);
			this->panel5->Controls->Add(this->label53);
			this->panel5->Controls->Add(this->label54);
			this->panel5->Controls->Add(this->label55);
			this->panel5->Location = System::Drawing::Point(396, 91);
			this->panel5->Name = L"panel5";
			this->panel5->Size = System::Drawing::Size(283, 163);
			this->panel5->TabIndex = 3;
			// 
			// Input_3
			// 
			this->Input_3->AutoSize = true;
			this->Input_3->Location = System::Drawing::Point(176, 123);
			this->Input_3->Name = L"Input_3";
			this->Input_3->Size = System::Drawing::Size(78, 22);
			this->Input_3->TabIndex = 14;
			this->Input_3->Text = L"Input 3";
			this->Input_3->UseVisualStyleBackColor = true;
			// 
			// Input_2
			// 
			this->Input_2->AutoSize = true;
			this->Input_2->Location = System::Drawing::Point(17, 123);
			this->Input_2->Name = L"Input_2";
			this->Input_2->Size = System::Drawing::Size(78, 22);
			this->Input_2->TabIndex = 13;
			this->Input_2->Text = L"Input 2";
			this->Input_2->UseVisualStyleBackColor = true;
			// 
			// Input_1
			// 
			this->Input_1->AutoSize = true;
			this->Input_1->Location = System::Drawing::Point(177, 28);
			this->Input_1->Name = L"Input_1";
			this->Input_1->Size = System::Drawing::Size(76, 22);
			this->Input_1->TabIndex = 11;
			this->Input_1->Text = L"Input 1";
			this->Input_1->UseVisualStyleBackColor = true;
			// 
			// Input_0
			// 
			this->Input_0->AutoSize = true;
			this->Input_0->Location = System::Drawing::Point(17, 28);
			this->Input_0->Name = L"Input_0";
			this->Input_0->Size = System::Drawing::Size(80, 22);
			this->Input_0->TabIndex = 9;
			this->Input_0->Text = L"Input 0";
			this->Input_0->UseVisualStyleBackColor = true;
			// 
			// label52
			// 
			this->label52->AutoSize = true;
			this->label52->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label52->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label52->Location = System::Drawing::Point(190, 102);
			this->label52->Name = L"label52";
			this->label52->Size = System::Drawing::Size(58, 18);
			this->label52->TabIndex = 8;
			this->label52->Text = L"ADDR3";
			// 
			// label53
			// 
			this->label53->AutoSize = true;
			this->label53->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label53->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label53->Location = System::Drawing::Point(38, 102);
			this->label53->Name = L"label53";
			this->label53->Size = System::Drawing::Size(58, 18);
			this->label53->TabIndex = 6;
			this->label53->Text = L"ADDR2";
			// 
			// label54
			// 
			this->label54->AutoSize = true;
			this->label54->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label54->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label54->Location = System::Drawing::Point(190, 3);
			this->label54->Name = L"label54";
			this->label54->Size = System::Drawing::Size(58, 18);
			this->label54->TabIndex = 3;
			this->label54->Text = L"ADDR1";
			// 
			// label55
			// 
			this->label55->AutoSize = true;
			this->label55->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label55->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label55->Location = System::Drawing::Point(38, 3);
			this->label55->Name = L"label55";
			this->label55->Size = System::Drawing::Size(58, 18);
			this->label55->TabIndex = 1;
			this->label55->Text = L"ADDR0";
			// 
			// label51
			// 
			this->label51->AutoSize = true;
			this->label51->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Underline, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label51->ForeColor = System::Drawing::Color::Maroon;
			this->label51->Location = System::Drawing::Point(462, 62);
			this->label51->Name = L"label51";
			this->label51->Size = System::Drawing::Size(130, 18);
			this->label51->TabIndex = 2;
			this->label51->Text = L"Isolated  Inputs";
			// 
			// label50
			// 
			this->label50->AutoSize = true;
			this->label50->Font = (gcnew System::Drawing::Font(L"Arial Rounded MT Bold", 12, System::Drawing::FontStyle::Underline, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label50->ForeColor = System::Drawing::Color::Maroon;
			this->label50->Location = System::Drawing::Point(76, 62);
			this->label50->Name = L"label50";
			this->label50->Size = System::Drawing::Size(140, 18);
			this->label50->TabIndex = 1;
			this->label50->Text = L"Isolated Outputs";
			// 
			// panel4
			// 
			this->panel4->AccessibleName = L"";
			this->panel4->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel4->Controls->Add(this->Output_5);
			this->panel4->Controls->Add(this->Output_4);
			this->panel4->Controls->Add(this->Output_3);
			this->panel4->Controls->Add(this->Output_2);
			this->panel4->Controls->Add(this->Output_1);
			this->panel4->Controls->Add(this->Output_0);
			this->panel4->Controls->Add(this->label49);
			this->panel4->Controls->Add(this->label48);
			this->panel4->Controls->Add(this->label47);
			this->panel4->Controls->Add(this->label46);
			this->panel4->Location = System::Drawing::Point(29, 91);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(283, 163);
			this->panel4->TabIndex = 0;
			// 
			// Output_5
			// 
			this->Output_5->AutoSize = true;
			this->Output_5->Location = System::Drawing::Point(176, 123);
			this->Output_5->Name = L"Output_5";
			this->Output_5->Size = System::Drawing::Size(89, 22);
			this->Output_5->TabIndex = 14;
			this->Output_5->Text = L"Output 5";
			this->Output_5->UseVisualStyleBackColor = true;
			// 
			// Output_4
			// 
			this->Output_4->AutoSize = true;
			this->Output_4->Location = System::Drawing::Point(17, 123);
			this->Output_4->Name = L"Output_4";
			this->Output_4->Size = System::Drawing::Size(90, 22);
			this->Output_4->TabIndex = 13;
			this->Output_4->Text = L"Output 4";
			this->Output_4->UseVisualStyleBackColor = true;
			// 
			// Output_3
			// 
			this->Output_3->AutoSize = true;
			this->Output_3->Location = System::Drawing::Point(177, 50);
			this->Output_3->Name = L"Output_3";
			this->Output_3->Size = System::Drawing::Size(89, 22);
			this->Output_3->TabIndex = 12;
			this->Output_3->Text = L"Output 3";
			this->Output_3->UseVisualStyleBackColor = true;
			// 
			// Output_2
			// 
			this->Output_2->AutoSize = true;
			this->Output_2->Location = System::Drawing::Point(177, 28);
			this->Output_2->Name = L"Output_2";
			this->Output_2->Size = System::Drawing::Size(89, 22);
			this->Output_2->TabIndex = 11;
			this->Output_2->Text = L"Output 2";
			this->Output_2->UseVisualStyleBackColor = true;
			// 
			// Output_1
			// 
			this->Output_1->AutoSize = true;
			this->Output_1->Location = System::Drawing::Point(17, 50);
			this->Output_1->Name = L"Output_1";
			this->Output_1->Size = System::Drawing::Size(87, 22);
			this->Output_1->TabIndex = 10;
			this->Output_1->Text = L"Output 1";
			this->Output_1->UseVisualStyleBackColor = true;
			// 
			// Output_0
			// 
			this->Output_0->AutoSize = true;
			this->Output_0->Location = System::Drawing::Point(17, 28);
			this->Output_0->Name = L"Output_0";
			this->Output_0->Size = System::Drawing::Size(91, 22);
			this->Output_0->TabIndex = 9;
			this->Output_0->Text = L"Output 0";
			this->Output_0->UseVisualStyleBackColor = true;
			// 
			// label49
			// 
			this->label49->AutoSize = true;
			this->label49->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label49->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label49->Location = System::Drawing::Point(190, 102);
			this->label49->Name = L"label49";
			this->label49->Size = System::Drawing::Size(58, 18);
			this->label49->TabIndex = 8;
			this->label49->Text = L"ADDR3";
			// 
			// label48
			// 
			this->label48->AutoSize = true;
			this->label48->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label48->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label48->Location = System::Drawing::Point(38, 102);
			this->label48->Name = L"label48";
			this->label48->Size = System::Drawing::Size(58, 18);
			this->label48->TabIndex = 6;
			this->label48->Text = L"ADDR2";
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label47->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label47->Location = System::Drawing::Point(190, 3);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(58, 18);
			this->label47->TabIndex = 3;
			this->label47->Text = L"ADDR1";
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label46->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->label46->Location = System::Drawing::Point(38, 3);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(58, 18);
			this->label46->TabIndex = 1;
			this->label46->Text = L"ADDR0";
			// 
			// MotAddress
			// 
			this->MotAddress->AutoSize = true;
			this->MotAddress->Font = (gcnew System::Drawing::Font(L"Constantia", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MotAddress->ForeColor = System::Drawing::Color::Crimson;
			this->MotAddress->Location = System::Drawing::Point(471, 55);
			this->MotAddress->Name = L"MotAddress";
			this->MotAddress->Size = System::Drawing::Size(142, 15);
			this->MotAddress->TabIndex = 6;
			this->MotAddress->Text = L"Select Motor Address:";
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->button2);
			this->groupBox5->Controls->Add(this->button3);
			this->groupBox5->Controls->Add(this->richTextBox1);
			this->groupBox5->Controls->Add(this->label12);
			this->groupBox5->Controls->Add(this->richTextBox2);
			this->groupBox5->Controls->Add(this->richTextBox3);
			this->groupBox5->Controls->Add(this->richTextBox4);
			this->groupBox5->Controls->Add(this->label13);
			this->groupBox5->Controls->Add(this->label14);
			this->groupBox5->Controls->Add(this->label15);
			this->groupBox5->Controls->Add(this->radioButton2);
			this->groupBox5->Controls->Add(this->radioButton3);
			this->groupBox5->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox5->ForeColor = System::Drawing::Color::Maroon;
			this->groupBox5->Location = System::Drawing::Point(0, 116);
			this->groupBox5->Name = L"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(337, 201);
			this->groupBox5->TabIndex = 16;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = L"Motor Factory Parameters ";
			// 
			// button2
			// 
			this->button2->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button2->ForeColor = System::Drawing::Color::SaddleBrown;
			this->button2->Location = System::Drawing::Point(58, 172);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(227, 23);
			this->button2->TabIndex = 24;
			this->button2->Text = L"Read Motor Factory  Parameters ";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			this->button3->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button3->ForeColor = System::Drawing::Color::SaddleBrown;
			this->button3->Location = System::Drawing::Point(58, 149);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(227, 23);
			this->button3->TabIndex = 23;
			this->button3->Text = L"Set Motor Factory  Parameters ";
			this->button3->UseVisualStyleBackColor = true;
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(270, 116);
			this->richTextBox1->MaxLength = 10;
			this->richTextBox1->Multiline = false;
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox1->Size = System::Drawing::Size(61, 21);
			this->richTextBox1->TabIndex = 22;
			this->richTextBox1->Text = L"24";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label12->ForeColor = System::Drawing::Color::Black;
			this->label12->Location = System::Drawing::Point(12, 122);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(199, 13);
			this->label12->TabIndex = 21;
			this->label12->Text = L"Motor Power Supply    (from 14V to 50V):";
			// 
			// richTextBox2
			// 
			this->richTextBox2->Location = System::Drawing::Point(270, 95);
			this->richTextBox2->MaxLength = 10;
			this->richTextBox2->Multiline = false;
			this->richTextBox2->Name = L"richTextBox2";
			this->richTextBox2->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox2->Size = System::Drawing::Size(61, 21);
			this->richTextBox2->TabIndex = 20;
			this->richTextBox2->Text = L"2300";
			// 
			// richTextBox3
			// 
			this->richTextBox3->Location = System::Drawing::Point(270, 54);
			this->richTextBox3->MaxLength = 10;
			this->richTextBox3->Multiline = false;
			this->richTextBox3->Name = L"richTextBox3";
			this->richTextBox3->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox3->Size = System::Drawing::Size(61, 21);
			this->richTextBox3->TabIndex = 19;
			this->richTextBox3->Text = L"2.3";
			// 
			// richTextBox4
			// 
			this->richTextBox4->Location = System::Drawing::Point(270, 75);
			this->richTextBox4->MaxLength = 10;
			this->richTextBox4->Multiline = false;
			this->richTextBox4->Name = L"richTextBox4";
			this->richTextBox4->ScrollBars = System::Windows::Forms::RichTextBoxScrollBars::None;
			this->richTextBox4->Size = System::Drawing::Size(61, 21);
			this->richTextBox4->TabIndex = 18;
			this->richTextBox4->Text = L"4";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label13->ForeColor = System::Drawing::Color::Black;
			this->label13->Location = System::Drawing::Point(12, 103);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(234, 13);
			this->label13->TabIndex = 16;
			this->label13->Text = L"Motor Winding Current (from 0.5 to 4000 mAmp):";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label14->ForeColor = System::Drawing::Color::Black;
			this->label14->Location = System::Drawing::Point(12, 84);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(169, 13);
			this->label14->TabIndex = 15;
			this->label14->Text = L"Motor Inductance (Decimal , mH.):";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label15->ForeColor = System::Drawing::Color::Black;
			this->label15->Location = System::Drawing::Point(12, 64);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(215, 13);
			this->label15->TabIndex = 14;
			this->label15->Text = L"Motor Winding Resistance ( Decimal, Ohms)";
			// 
			// radioButton2
			// 
			this->radioButton2->AutoSize = true;
			this->radioButton2->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton2->ForeColor = System::Drawing::Color::Black;
			this->radioButton2->Location = System::Drawing::Point(131, 33);
			this->radioButton2->Name = L"radioButton2";
			this->radioButton2->Size = System::Drawing::Size(117, 22);
			this->radioButton2->TabIndex = 1;
			this->radioButton2->Text = L"Motor Unipolar";
			this->radioButton2->UseVisualStyleBackColor = true;
			// 
			// radioButton3
			// 
			this->radioButton3->AutoSize = true;
			this->radioButton3->Checked = true;
			this->radioButton3->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton3->ForeColor = System::Drawing::Color::Black;
			this->radioButton3->Location = System::Drawing::Point(15, 33);
			this->radioButton3->Name = L"radioButton3";
			this->radioButton3->Size = System::Drawing::Size(107, 22);
			this->radioButton3->TabIndex = 0;
			this->radioButton3->TabStop = true;
			this->radioButton3->Text = L"Motor Bipolar";
			this->radioButton3->UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			this->button4->Font = (gcnew System::Drawing::Font(L"Nina", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button4->ForeColor = System::Drawing::Color::DarkGreen;
			this->button4->Location = System::Drawing::Point(138, 352);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(103, 25);
			this->button4->TabIndex = 15;
			this->button4->Text = L"TRIGGER OFF";
			this->button4->UseVisualStyleBackColor = true;
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->radioButton4);
			this->groupBox6->Controls->Add(this->radioButton5);
			this->groupBox6->Controls->Add(this->radioButton6);
			this->groupBox6->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox6->ForeColor = System::Drawing::Color::Maroon;
			this->groupBox6->Location = System::Drawing::Point(343, 228);
			this->groupBox6->Name = L"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(366, 69);
			this->groupBox6->TabIndex = 14;
			this->groupBox6->TabStop = false;
			this->groupBox6->Text = L"Control  Mode ";
			// 
			// radioButton4
			// 
			this->radioButton4->AutoSize = true;
			this->radioButton4->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton4->ForeColor = System::Drawing::Color::Black;
			this->radioButton4->Location = System::Drawing::Point(253, 33);
			this->radioButton4->Name = L"radioButton4";
			this->radioButton4->Size = System::Drawing::Size(109, 22);
			this->radioButton4->TabIndex = 2;
			this->radioButton4->Text = L"Mixed Control";
			this->radioButton4->UseVisualStyleBackColor = true;
			// 
			// radioButton5
			// 
			this->radioButton5->AutoSize = true;
			this->radioButton5->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton5->ForeColor = System::Drawing::Color::Black;
			this->radioButton5->Location = System::Drawing::Point(131, 33);
			this->radioButton5->Name = L"radioButton5";
			this->radioButton5->Size = System::Drawing::Size(122, 22);
			this->radioButton5->TabIndex = 1;
			this->radioButton5->Text = L"Position Control";
			this->radioButton5->UseVisualStyleBackColor = true;
			// 
			// radioButton6
			// 
			this->radioButton6->AutoSize = true;
			this->radioButton6->Checked = true;
			this->radioButton6->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton6->ForeColor = System::Drawing::Color::Black;
			this->radioButton6->Location = System::Drawing::Point(15, 33);
			this->radioButton6->Name = L"radioButton6";
			this->radioButton6->Size = System::Drawing::Size(107, 22);
			this->radioButton6->TabIndex = 0;
			this->radioButton6->TabStop = true;
			this->radioButton6->Text = L"Speed Control";
			this->radioButton6->UseVisualStyleBackColor = true;
			// 
			// numericUpDown2
			// 
			this->numericUpDown2->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {50, 0, 0, 0});
			this->numericUpDown2->Location = System::Drawing::Point(119, 75);
			this->numericUpDown2->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->numericUpDown2->Name = L"numericUpDown2";
			this->numericUpDown2->Size = System::Drawing::Size(96, 20);
			this->numericUpDown2->TabIndex = 13;
			this->numericUpDown2->ThousandsSeparator = true;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label16->Location = System::Drawing::Point(6, 77);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(70, 13);
			this->label16->TabIndex = 12;
			this->label16->Text = L"Deceleration:";
			// 
			// button5
			// 
			this->button5->FlatAppearance->BorderColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), 
				static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->button5->Font = (gcnew System::Drawing::Font(L"Nina", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button5->ForeColor = System::Drawing::Color::DarkGreen;
			this->button5->Location = System::Drawing::Point(25, 352);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(107, 25);
			this->button5->TabIndex = 11;
			this->button5->Text = L"TRIGGER ON";
			this->button5->UseVisualStyleBackColor = true;
			// 
			// numericUpDown3
			// 
			this->numericUpDown3->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {50, 0, 0, 0});
			this->numericUpDown3->Location = System::Drawing::Point(119, 54);
			this->numericUpDown3->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->numericUpDown3->Name = L"numericUpDown3";
			this->numericUpDown3->Size = System::Drawing::Size(96, 20);
			this->numericUpDown3->TabIndex = 10;
			this->numericUpDown3->ThousandsSeparator = true;
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label17->Location = System::Drawing::Point(5, 56);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(69, 13);
			this->label17->TabIndex = 9;
			this->label17->Text = L"Acceleration:";
			// 
			// numericUpDown4
			// 
			this->numericUpDown4->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {500, 0, 0, 0});
			this->numericUpDown4->Location = System::Drawing::Point(92, 12);
			this->numericUpDown4->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {32000000, 0, 0, 0});
			this->numericUpDown4->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {32000000, 0, 0, System::Int32::MinValue});
			this->numericUpDown4->Name = L"numericUpDown4";
			this->numericUpDown4->Size = System::Drawing::Size(124, 20);
			this->numericUpDown4->TabIndex = 8;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label18->Location = System::Drawing::Point(6, 12);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(80, 13);
			this->label18->TabIndex = 6;
			this->label18->Text = L"Stpes Number: ";
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->radioButton7);
			this->groupBox7->Controls->Add(this->radioButton8);
			this->groupBox7->Controls->Add(this->radioButton9);
			this->groupBox7->Controls->Add(this->radioButton10);
			this->groupBox7->Controls->Add(this->radioButton11);
			this->groupBox7->Controls->Add(this->radioButton12);
			this->groupBox7->Controls->Add(this->radioButton13);
			this->groupBox7->Controls->Add(this->radioButton14);
			this->groupBox7->Font = (gcnew System::Drawing::Font(L"Georgia", 11, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox7->ForeColor = System::Drawing::Color::DarkOliveGreen;
			this->groupBox7->Location = System::Drawing::Point(343, 93);
			this->groupBox7->Name = L"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(369, 120);
			this->groupBox7->TabIndex = 5;
			this->groupBox7->TabStop = false;
			this->groupBox7->Text = L"Step Resolution ";
			// 
			// radioButton7
			// 
			this->radioButton7->AutoSize = true;
			this->radioButton7->Enabled = false;
			this->radioButton7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton7->ForeColor = System::Drawing::Color::Black;
			this->radioButton7->Location = System::Drawing::Point(128, 87);
			this->radioButton7->Name = L"radioButton7";
			this->radioButton7->Size = System::Drawing::Size(99, 21);
			this->radioButton7->TabIndex = 7;
			this->radioButton7->TabStop = true;
			this->radioButton7->Text = L"1/128  Step";
			this->radioButton7->UseVisualStyleBackColor = true;
			// 
			// radioButton8
			// 
			this->radioButton8->AutoSize = true;
			this->radioButton8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton8->ForeColor = System::Drawing::Color::Black;
			this->radioButton8->Location = System::Drawing::Point(22, 87);
			this->radioButton8->Name = L"radioButton8";
			this->radioButton8->Size = System::Drawing::Size(91, 21);
			this->radioButton8->TabIndex = 6;
			this->radioButton8->Text = L"1/64  Step";
			this->radioButton8->UseVisualStyleBackColor = true;
			// 
			// radioButton9
			// 
			this->radioButton9->AutoSize = true;
			this->radioButton9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton9->ForeColor = System::Drawing::Color::Black;
			this->radioButton9->Location = System::Drawing::Point(230, 60);
			this->radioButton9->Name = L"radioButton9";
			this->radioButton9->Size = System::Drawing::Size(91, 21);
			this->radioButton9->TabIndex = 5;
			this->radioButton9->TabStop = true;
			this->radioButton9->Text = L"1/32  Step";
			this->radioButton9->UseVisualStyleBackColor = true;
			// 
			// radioButton10
			// 
			this->radioButton10->AutoSize = true;
			this->radioButton10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton10->ForeColor = System::Drawing::Color::Black;
			this->radioButton10->Location = System::Drawing::Point(128, 60);
			this->radioButton10->Name = L"radioButton10";
			this->radioButton10->Size = System::Drawing::Size(91, 21);
			this->radioButton10->TabIndex = 4;
			this->radioButton10->TabStop = true;
			this->radioButton10->Text = L"1/16  Step";
			this->radioButton10->UseVisualStyleBackColor = true;
			// 
			// radioButton11
			// 
			this->radioButton11->AutoSize = true;
			this->radioButton11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton11->ForeColor = System::Drawing::Color::Black;
			this->radioButton11->Location = System::Drawing::Point(22, 60);
			this->radioButton11->Name = L"radioButton11";
			this->radioButton11->Size = System::Drawing::Size(83, 21);
			this->radioButton11->TabIndex = 3;
			this->radioButton11->TabStop = true;
			this->radioButton11->Text = L"1/8  Step";
			this->radioButton11->UseVisualStyleBackColor = true;
			// 
			// radioButton12
			// 
			this->radioButton12->AutoSize = true;
			this->radioButton12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton12->ForeColor = System::Drawing::Color::Black;
			this->radioButton12->Location = System::Drawing::Point(230, 33);
			this->radioButton12->Name = L"radioButton12";
			this->radioButton12->Size = System::Drawing::Size(83, 21);
			this->radioButton12->TabIndex = 2;
			this->radioButton12->TabStop = true;
			this->radioButton12->Text = L"1/4  Step";
			this->radioButton12->UseVisualStyleBackColor = true;
			// 
			// radioButton13
			// 
			this->radioButton13->AutoSize = true;
			this->radioButton13->Checked = true;
			this->radioButton13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton13->ForeColor = System::Drawing::Color::Black;
			this->radioButton13->Location = System::Drawing::Point(128, 33);
			this->radioButton13->Name = L"radioButton13";
			this->radioButton13->Size = System::Drawing::Size(84, 21);
			this->radioButton13->TabIndex = 1;
			this->radioButton13->TabStop = true;
			this->radioButton13->Text = L"Half Step";
			this->radioButton13->UseVisualStyleBackColor = true;
			// 
			// radioButton14
			// 
			this->radioButton14->AutoSize = true;
			this->radioButton14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->radioButton14->ForeColor = System::Drawing::Color::Black;
			this->radioButton14->Location = System::Drawing::Point(22, 33);
			this->radioButton14->Name = L"radioButton14";
			this->radioButton14->Size = System::Drawing::Size(81, 21);
			this->radioButton14->TabIndex = 0;
			this->radioButton14->Text = L"Full Step";
			this->radioButton14->UseVisualStyleBackColor = true;
			// 
			// groupBox8
			// 
			this->groupBox8->Controls->Add(this->radioButton15);
			this->groupBox8->Controls->Add(this->radioButton16);
			this->groupBox8->Controls->Add(this->radioButton17);
			this->groupBox8->Font = (gcnew System::Drawing::Font(L"Goudy Old Style", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->groupBox8->ForeColor = System::Drawing::Color::Maroon;
			this->groupBox8->Location = System::Drawing::Point(343, 18);
			this->groupBox8->Name = L"groupBox8";
			this->groupBox8->Size = System::Drawing::Size(366, 69);
			this->groupBox8->TabIndex = 4;
			this->groupBox8->TabStop = false;
			this->groupBox8->Text = L"Operating Mode ";
			// 
			// radioButton15
			// 
			this->radioButton15->AutoSize = true;
			this->radioButton15->ForeColor = System::Drawing::Color::Black;
			this->radioButton15->Location = System::Drawing::Point(253, 33);
			this->radioButton15->Name = L"radioButton15";
			this->radioButton15->Size = System::Drawing::Size(109, 25);
			this->radioButton15->TabIndex = 2;
			this->radioButton15->Text = L"Closed Loop";
			this->radioButton15->UseVisualStyleBackColor = true;
			// 
			// radioButton16
			// 
			this->radioButton16->AutoSize = true;
			this->radioButton16->Checked = true;
			this->radioButton16->ForeColor = System::Drawing::Color::Black;
			this->radioButton16->Location = System::Drawing::Point(131, 33);
			this->radioButton16->Name = L"radioButton16";
			this->radioButton16->Size = System::Drawing::Size(123, 25);
			this->radioButton16->TabIndex = 1;
			this->radioButton16->TabStop = true;
			this->radioButton16->Text = L"Current Mode";
			this->radioButton16->UseVisualStyleBackColor = true;
			// 
			// radioButton17
			// 
			this->radioButton17->AutoSize = true;
			this->radioButton17->ForeColor = System::Drawing::Color::Black;
			this->radioButton17->Location = System::Drawing::Point(15, 33);
			this->radioButton17->Name = L"radioButton17";
			this->radioButton17->Size = System::Drawing::Size(123, 25);
			this->radioButton17->TabIndex = 0;
			this->radioButton17->Text = L"Volatge Mode ";
			this->radioButton17->UseVisualStyleBackColor = true;
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label19->Location = System::Drawing::Point(6, 35);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(62, 13);
			this->label19->TabIndex = 1;
			this->label19->Text = L"Slew Rate :";
			// 
			// numericUpDown5
			// 
			this->numericUpDown5->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {20, 0, 0, 0});
			this->numericUpDown5->Location = System::Drawing::Point(119, 33);
			this->numericUpDown5->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {20000, 0, 0, 0});
			this->numericUpDown5->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {20000, 0, 0, System::Int32::MinValue});
			this->numericUpDown5->Name = L"numericUpDown5";
			this->numericUpDown5->Size = System::Drawing::Size(96, 20);
			this->numericUpDown5->TabIndex = 0;
			this->numericUpDown5->ThousandsSeparator = true;
			this->numericUpDown5->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {200, 0, 0, 0});
			// 
			// folderBrowserDialog1
			// 
			this->folderBrowserDialog1->SelectedPath = L"C:\\Users\\pepe1\\Desktop";
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->Title = L"ST600uNET Motion Buffer";
			// 
			// MotAddSelection
			// 
			this->MotAddSelection->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MotAddSelection->ForeColor = System::Drawing::Color::Maroon;
			this->MotAddSelection->FormattingEnabled = true;
			this->MotAddSelection->ItemHeight = 18;
			this->MotAddSelection->Items->AddRange(gcnew cli::array< System::Object^  >(5) {L"Axis0", L"Axis1", L"Axis2", L"Axis3", L"FULL"});
			this->MotAddSelection->Location = System::Drawing::Point(619, 48);
			this->MotAddSelection->Name = L"MotAddSelection";
			this->MotAddSelection->ScrollAlwaysVisible = true;
			this->MotAddSelection->Size = System::Drawing::Size(71, 22);
			this->MotAddSelection->TabIndex = 11;
			this->MotAddSelection->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::MotAddSelection_SelectedIndexChanged);
			// 
			// timer1
			// 
			this->timer1->Interval = 800;
			this->timer1->Tick += gcnew System::EventHandler(this, &Form1::timer1_Tick);
			// 
			// timer2
			// 
			this->timer2->Interval = 500;
			this->timer2->Tick += gcnew System::EventHandler(this, &Form1::timer2_Tick);
			// 
			// errorProvider1
			// 
			this->errorProvider1->ContainerControl = this;
			// 
			// timer3
			// 
			this->timer3->Interval = 300;
			this->timer3->Tick += gcnew System::EventHandler(this, &Form1::timer3_Tick);
			// 
			// timer4
			// 
			this->timer4->Interval = 250;
			this->timer4->Tick += gcnew System::EventHandler(this, &Form1::timer4_Tick);
			// 
			// timer5
			// 
			this->timer5->Interval = 250;
			this->timer5->Tick += gcnew System::EventHandler(this, &Form1::timer5_Tick);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSize = true;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(224)), static_cast<System::Int32>(static_cast<System::Byte>(224)), 
				static_cast<System::Int32>(static_cast<System::Byte>(224)));
			this->ClientSize = System::Drawing::Size(736, 656);
			this->Controls->Add(this->MotAddSelection);
			this->Controls->Add(this->MotAddress);
			this->Controls->Add(this->tabControl6);
			this->Controls->Add(this->mbDevAddr);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->CloseConnection);
			this->Controls->Add(this->mbSerialNumber);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->mbProductString);
			this->Controls->Add(this->OpenDev);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Name = L"Form1";
			this->Text = L"Demo ST600uNET  Ver: 7.11  \"RMV Motion Inc.\"";
			this->tabControl6->ResumeLayout(false);
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			this->groupBox10->ResumeLayout(false);
			this->groupBox10->PerformLayout();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->groupBox9->ResumeLayout(false);
			this->groupBox9->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->MControl1->ResumeLayout(false);
			this->MControl1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Decel1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Accel1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->SetpNum1))->EndInit();
			this->MResulution1->ResumeLayout(false);
			this->MResulution1->PerformLayout();
			this->MMode1->ResumeLayout(false);
			this->MMode1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Speed1))->EndInit();
			this->tabPage5->ResumeLayout(false);
			this->tabPage5->PerformLayout();
			this->panel6->ResumeLayout(false);
			this->panel6->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->tabPage6->ResumeLayout(false);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			this->tabPage3->ResumeLayout(false);
			this->tabPage3->PerformLayout();
			this->panel5->ResumeLayout(false);
			this->panel5->PerformLayout();
			this->panel4->ResumeLayout(false);
			this->panel4->PerformLayout();
			this->groupBox5->ResumeLayout(false);
			this->groupBox5->PerformLayout();
			this->groupBox6->ResumeLayout(false);
			this->groupBox6->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown4))->EndInit();
			this->groupBox7->ResumeLayout(false);
			this->groupBox7->PerformLayout();
			this->groupBox8->ResumeLayout(false);
			this->groupBox8->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->errorProvider1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		// Opoen Connection ww
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
                   
					 
				                         
				   SerialNumber[0]='\0';
				   ProductString[0]='\0';
				   switch (MotAddSelection->SelectedIndex::get() )
				   {
				     case 0 :  
                         motor_addr_mask = MOTOR1_ADDR_MASK ;
			         break;
				    case 1:  
                         motor_addr_mask = MOTOR2_ADDR_MASK ;
			        break; 
				    case 2:  
                         motor_addr_mask = MOTOR3_ADDR_MASK ;
			        break; 
				    case 3:  
                         motor_addr_mask = MOTOR4_ADDR_MASK ;
			        break; 
				    case 4:  
                         motor_addr_mask = ALL_MOTOR_ADDR_MASK;
			        break; 
				    default : 
                         motor_addr_mask = MOTOR1_ADDR_MASK ;

			       }
				         //Set deafult ADDR "0" 
			       String ^str; 
				   int status=0;
               	   if(!ST600uNet_Connect( & DeviceAddress,&ProductString[0], &SerialNumber[0] )){
                     str = marshal_as<String^>(SerialNumber); 			
				     mbSerialNumber->Text = str;
				     str =  marshal_as<String^>(ProductString);
				     mbProductString->Text = str;     
                     str  = System::Convert::ToString( DeviceAddress );
					 mbDevAddr->Text = str;
					 CloseConnection->Enabled=true;
				   } else  
				     { 
					     ST600uNet_GetError(Error);
					     str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error Open HID ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				     }
				 
			 }
	private: System::Void CloseConnection_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			       String ^str; 
				   int status=0;
 
				   if(!ST600uNet_Close(DeviceAddress,&SerialNumber[0] )){
                     SerialNumber[0]='\0';
				     ProductString[0]='\0';
				     str= "--";            
				     mbSerialNumber->Text = str;
				     str = "NO CONNECTED" ;
				     mbProductString->Text = str;     
                     str  = "--";
					 mbDevAddr->Text = str;
					 CloseConnection->Enabled=false;
				   }else  
				     { 
					     ST600uNet_GetError(Error);
					     str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error Close HID ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				        }
				 
			 
			 }
private: System::Void tabPage4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void tabPage1_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void tabPage2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Speed1_ValueChanged(System::Object^  sender, System::EventArgs^  e) { //Motor Speed 1 Change on the fly 
             String ^ str;
             unsigned short int Error_number =0;
			 // Static Variable
			 static int MotorSpeed_Bckp =0;
			 static unsigned short int  bytes_available=0;
            
/*                     Enable if speed= 0 is allowed 
  
			   if (SpeedCtrl1->Checked){ // Speed Control Real time speed change
				
				    MotorSpeed= (  int) Speed1->Value;
                    MotorSpeed_Bckp=MotorSpeed; 
					if (!MotorSpeed){ 
                     if(MessageBox::Show("Speed is ZERO, SPEED CONTROL Motion will be Completed, Do you want to continue ? " ," Speed motor control   ", 
						 MessageBoxButtons::YesNo ,MessageBoxIcon::Exclamation) == ::DialogResult::No)
						 return; 
					}

*/					
					
					// Enable if MotorSpeed is not allowed to be ZERO
				 
				 
				 if (Speed1->Value !=0) {
                    MotorSpeed= (  int) Speed1->Value;
                    MotorSpeed_Bckp=MotorSpeed; 
				 }		  
				 else {
					 if (MotorSpeed_Bckp >0) {
						 MotorSpeed_Bckp = - (int)Speed1->Increment;
						 MotorSpeed = MotorSpeed_Bckp;
						 Speed1->Value=MotorSpeed;
					 }else {
					     MotorSpeed_Bckp = (int)Speed1->Increment;
						 MotorSpeed = MotorSpeed_Bckp;  
						 Speed1->Value=MotorSpeed;
					 }
				 }
				  //MotorSpeed= (  int) Speed1->Value;
				  Acceleration= (unsigned  int) Accel1->Value;
				  Deceleration= (unsigned  int) Decel1->Value;
                  if  (  bytes_available <= MAX_BUFFER_SIZE_SPPOS_CNTRL )
				  {
			 	    if( ST600uNet_MotorSpeedControl(motor_addr_mask, SPEED_RATE  ,MotorSpeed,Acceleration, Deceleration, & bytes_available , & Error_number))
			  	    {
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		            } 
				  }else MessageBox::Show( "SPEED BUFFER IS FULL...... "," Please wait until buffer is empty.....  ", MessageBoxButtons::OK,MessageBoxIcon::Hand);
			 //}//else MessageBox::Show( "SPEED CONTROL NEEDS TO BE SELECTED"," Error Motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
		 }




private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {// Motor Trigger 1
            String ^ str;
			unsigned short int Error_number=0;
			 //if (Trigger[0]== DIRECT_TRIGGER_ON){
				// Trigger1->ForeColor =Color::Crimson;
                 //Trigger1->Text="TRIGGER OFF";   				 
				 if (FIFOEnable->Checked) Trigger[0] = DIRECT_TRIGGER_ALWAYS;
				 else   Trigger[0]=DIRECT_TRIGGER_ON;
/*                    
				 if (ST600uNet_Set_Motion_Delay(motor_addr_mask,1,100 ,& Error_number)){
                       ST600uNet_GetError(Error);
					   str =  marshal_as<String^>(Error);     
					   MessageBox::Show( str,"Error in Motor 1 Triggering ", MessageBoxButtons::OK,MessageBoxIcon::Hand);     
				 }
				 
*/				 
				 
				 if(ST600uNet_MotorTrigger(motor_addr_mask,Trigger[0],& Error_number)){
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in Motor Trigger ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		         }
			 
			/*}else if (Trigger[0]== DIRECT_TRIGGER_OFF){
                 Trigger1->ForeColor=Color::DarkGreen; 
            	 Trigger1->Text="TRIGGER ON";
                 Trigger[0] = 1;
   			     if(1!=ST600uNet_MotorTrigger(motor_addr_mask,Trigger[0])){
   	              ST600uNet_GetError(Error);
			      str =  marshal_as<String^>(Error);     
			      MessageBox::Show( str,"Error in Motor 1 Triggering ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		         }			 
			 }*/
		   	  
		 }// end Trigger 1
private: System::Void radioButton4_CheckedChanged(System::Object^  sender, System::EventArgs^  e) { // Set Speed control
  String ^str; 


			 if (SpeedCtrl1->Checked==true) { 
			 str = ""; 
			 LabMotB1->Text="Please Type  (cw or ccw) SR, A , and select  Sampling Rate and the Press <ADD to Motion Buffer>";
             LabMotB2->Text ="Slew Rate SR  CW(+) CCW (-) :";
			 LabMotB3->Text= "Acceleration (Step/sec^2) A :";
			 LabMotB4->Text= "";
			 LabMotB5->Text= "";
			 LabMotB6->Text= "";
			 str = "Example of Seed Control Motion : \r";
			 str +="1) Slew Rate     = 2 bytes ; -1000\r\n";
			 str +="2) Acceleration  = 2 bytes ;  400\r\n";
			 str +="3) Sampling Rate = 1 bytes ;  1 ms\r\n";
			 str +="4) Slew Rate     = 2 bytes ;  -700\r\n";
             str +="5) Acceleration  = 2 bytes ;  150\r\n"; 
			 str +="6) Sampling Rate = 1 bytes ;  1 ms\r\n\r\n";
			 str +="Note: Speed direction SR can be: CW(+) or CCW(-)";
			 str +="\r\n";
		     MotTrapeL->Text =str;
			 }       



		 }
private: System::Void Triggeroff1_Click(System::Object^  sender, System::EventArgs^  e) {
          String ^str;
          unsigned short int Error_number=0;
		          Trigger[0] = DIRECT_TRIGGER_OFF;
   			     if(ST600uNet_MotorTrigger(motor_addr_mask,Trigger[0], & Error_number)){
   	              ST600uNet_GetError(Error);
			      str =  marshal_as<String^>(Error);     
			      MessageBox::Show( str,"Error in Motor Trigger ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		         }	

		 }
		 ////////////////////////////////////////////////////////////////////////////////
private: System::Void MParam1_Click(System::Object^  sender, System::EventArgs^  e) { // Set Motor Parameters

             unsigned char bipolar_unipolar;
             String ^str;
             Decimal winding_resitance_in_Ohms = 0;
            float inductance_in_mH =0;
             unsigned char motor_power=0;
		     unsigned  int winding_current_in_mAmp=0;
             unsigned char step_angle=0;
             unsigned short int  Error_number=0;

  			 if (MBipolar1->Enabled) bipolar_unipolar =0;
			 else if (MUnipolar1->Enabled) bipolar_unipolar =1;
			 else    { MessageBox::Show( str,"Error in Motor Technology ", MessageBoxButtons::OK,MessageBoxIcon::Hand);      
			           return;
			 } 
				if (Degree1_8 ->Enabled) step_angle= 1;              //Use only two step anlge at this time ......
				else if(Degree0_9 ->Enabled) step_angle=2; 
				else if(Degree1_2 ->Enabled) step_angle=3; 
				else if(Degree0_72 ->Enabled) step_angle=4; 
				else if(Degree0_36 ->Enabled) step_angle=5; 
				else  {   MessageBox::Show( str,"Error in Motor Step Angle ", MessageBoxButtons::OK,MessageBoxIcon::Hand);      
                          return;    
				}
              	winding_resitance_in_Ohms = System::Convert::ToDecimal(MRes1->Text);
				inductance_in_mH = (float)(System::Convert::ToDouble(MInduct1->Text));         
				motor_power =(unsigned char ) System::Convert::ToInt16(MPower1->Text);
                
				winding_current_in_mAmp = (unsigned int) System::Convert::ToInt16 (MCurrt1->Text);

       if(1!= ST600uNet_SetMotorParameters(motor_addr_mask, winding_current_in_mAmp, (float) inductance_in_mH,
										  motor_power,bipolar_unipolar, (float ) winding_resitance_in_Ohms ,step_angle, &Error_number ))
	   {
            ST600uNet_GetError(Error);
		    str =  marshal_as<String^>(Error);     
		    MessageBox::Show( str,"Error in Motor Setting Parameters ", MessageBoxButtons::OK,MessageBoxIcon::Hand);                       


	   }
     
			


		 } //End Setting Parameters
private: System::Void MConfig1_Click(System::Object^  sender, System::EventArgs^  e) {         // Set Motion configuration 
             String ^str;
		     unsigned short int Error_number;
			 unsigned char sequential_motion;

			 if (mbVMode1->Checked)        OperatingMode_ADD0 =FIXED_VOLATAGE;
			 else if (mbCMode1->Checked)   OperatingMode_ADD0 =FIXED_CURRENT;
			 else if (mbCLMode1->Checked)  OperatingMode_ADD0 =CLOSED_LOOP;

			 if (StepRes0->Checked) StepResolution_ADD0       = ST_FULLSTEP; 
             else if (StepRes1->Checked) StepResolution_ADD0  = ST_HALFSTEP; 
             else if (StepRes2->Checked) StepResolution_ADD0  = ST_1_4STEP;
			 else if (StepRes3->Checked) StepResolution_ADD0  = ST_1_8STEP;
			 else if (StepRes4->Checked) StepResolution_ADD0  = ST_1_16STEP;
			 else if (StepRes5->Checked) StepResolution_ADD0  = ST_1_32STEP;
			 else if (StepRes6->Checked) StepResolution_ADD0  = ST_1_64STEP;

			 if (SpeedCtrl1->Checked)     ControlMode_ADD0 = SPEED_CONTROL;      
			 else  if (PosCtrl1->Checked) ControlMode_ADD0 = POSITION_CONTROL;
  		     else  if (TrapeCtrl1->Checked) ControlMode_ADD0 = TRAPEZOIDAL_CONTROL;
			   else  if (ProfTrapCtrl1->Checked) ControlMode_ADD0 = PROFILE_TRAPEZOIDAL_CONTROL;
        //     else  if (ScurveCtrl1->Checked) ControlMode_ADD0 = S_CURVE_CONTROL; 
             else  if (ProfSCtrl1->Checked) ControlMode_ADD0 = PROFILE_SPEED_CONTROL ;

          if (sampling_rate == SAMPLING_RATE_TWO_MSEC ) DeccelB->Text="2 mSec";
			 else if (sampling_rate == SAMPLING_RATE_ONE_MSEC ) DeccelB->Text="1 mSec";
			 else if(sampling_rate == SAMPLING_RATE_FIVE_MSEC ) DeccelB->Text="5 mSec"; 
 
			 if (FIFOEnable->Checked) fifo_enable=1;
			 else fifo_enable=0; 
			 if (SEQ_Event->Checked) {
				 sequential_motion =1;
                  
			 }
			 else {
				 sequential_motion =0;
                 seq_motion_controllers_enabled=0;
                  sequential_trigger_mask=0;
			 }
             motion_counter=0;                                 // Clear motion Counter

             // Clear al values in the desktop in order to Trigger a Motion with Value null
//			         SetpNum1->Value= 0;
///				     Speed1->Value=  50;
//				     Accel1->Value=0;
//				     Decel1->Value=0;
//				     StepRegister->Text= "0"; 


			 // Set Motion Configuration  
           if (ST600uNet_SetMotionConfig(motor_addr_mask, OperatingMode_ADD0, StepResolution_ADD0, ControlMode_ADD0,sampling_rate, fifo_enable,
			                             sequential_motion, seq_motion_controllers_enabled,sequential_trigger_mask ,&Error_number ))  
	       {
            ST600uNet_GetError(Error);
		    str =  marshal_as<String^>(Error);     
		    MessageBox::Show( str,"Error in Motor Config ...... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               

	        }

             

		 }
private: System::Void CtrlPos1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void MUnipolar1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void MRParam1_Click(System::Object^  sender, System::EventArgs^  e) {           /// Read Motor Parameters 

             String ^str;
             float winding_resitance_in_Ohms = 0;
             float inductance_in_mH =0;
             unsigned char motor_power=0;
		     unsigned  int winding_current_in_mAmp=0;
             unsigned int speed_open_loop=0;
             unsigned int motor_config =0;  
			 unsigned char step_angle =0;
             unsigned short int Error_number=0;

 
                    if ( ST600uNet_ReadMotorParameters(motor_addr_mask,&winding_current_in_mAmp, &inductance_in_mH,
													   &motor_power, &motor_config, &winding_resitance_in_Ohms,
													   &speed_open_loop,&step_angle, &Error_number))
					{
				    
				     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		              MessageBox::Show( str,"Error in Motor Setting Parameters ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               

                        	
					}else 
					{
						MCurrt1->Text =System::Convert::ToString ( winding_current_in_mAmp);
						if (motor_config & UNIPOLAR_BIPOLAR)MBipolar1->Checked = true;
						else MUnipolar1->Checked =true;
                        MInduct1->Text = System::Convert::ToString(inductance_in_mH);   					
                        MPower1->Text = System::Convert::ToString(motor_power);
                        MRes1->Text = System::Convert::ToString(winding_resitance_in_Ohms);
						MOLSpeed1->Text =  System::Convert::ToString(  speed_open_loop);
             	
                        	if(step_angle ==1)
								Degree1_8->Checked=true; 
							else if (step_angle ==2) 
								Degree0_9->Checked =true;            //Use only two step anlge at this time ......
							if (step_angle ==3) 
								Degree1_2->Checked =true;    
							if (step_angle ==4) 
								Degree0_72->Checked =true;   
							if (step_angle ==5) 
								Degree0_36->Checked =true;   
				}
     





		 }
private: System::Void Stop1_Click(System::Object^  sender, System::EventArgs^  e) {  // Motor STOP 
		
	          String ^str;
			  unsigned short int Error_number =0;
              unsigned char stop_parameters = STOP_MOTOR_ONLY;   
                
			  if ( ST600uNet_MotorSoftwareStop(motor_addr_mask,stop_parameters, &Error_number))
					{
				     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Motor Stop... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);                                      	
					}else 
					{
						// Add any code to indicate motor has been stoped
                        
					}
     
	 
		 
		 
		 }
private: System::Void mbVMode1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) { // Change Motor control 



		 }


private: System::Void OpeMode1_Click(System::Object^  sender, System::EventArgs^  e) {  //Set New Motor Operating Mode 
           
String ^str;
unsigned short int Error_number =0;
			 if (mbVMode1->Checked)        OperatingMode_ADD0 =FIXED_VOLATAGE;
			 else if (mbCMode1->Checked)   OperatingMode_ADD0 =FIXED_CURRENT;
			 else if (mbCLMode1->Checked)  OperatingMode_ADD0 =CLOSED_LOOP;

			  if ( ST600uNet_SetMotionOperationMode(motor_addr_mask,OperatingMode_ADD0, &Error_number))
					{
				    
				     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Motor Operation Mode... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               

                        	
					}

		 }
private: System::Void StepResol1_Click(System::Object^  sender, System::EventArgs^  e) { // Set Step Resolution 

String ^str;

			 if (StepRes0->Checked) StepResolution_ADD0       = ST_FULLSTEP; 
             else if (StepRes1->Checked) StepResolution_ADD0  = ST_HALFSTEP; 
             else if (StepRes2->Checked) StepResolution_ADD0  = ST_1_4STEP;
			 else if (StepRes3->Checked) StepResolution_ADD0  = ST_1_8STEP;
			 else if (StepRes4->Checked) StepResolution_ADD0  = ST_1_16STEP;
			 else if (StepRes5->Checked) StepResolution_ADD0  = ST_1_32STEP;
			 else if (StepRes6->Checked) StepResolution_ADD0  = ST_1_64STEP;
             else if (StepRes7->Checked) StepResolution_ADD0  = ST_1_128STEP;

			  if ( ST600uNet_SetStepResolution(motor_addr_mask,StepResolution_ADD0))
					{
				    
				     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Changing Step resolution... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               

                        	
					}else 
					{
						
                        
					}
     


		 }
private: System::Void tabPage6_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void radioButton1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }

         void Process_Array(String ^ str ){


		 }

private: System::Void button1_Click_2(System::Object^  sender, System::EventArgs^  e) {// Open File 
  
  String ^ Line;
  String ^ str;
  bool speed_control = false;
  bool trapezoidal_control =false;
  short int SInt16;
  long LInt32;
  

// Displays an OpenFileDialog so the user can select a Cursor.
      OpenFileDialog ^ openFileDialog1 = gcnew OpenFileDialog();
      openFileDialog1->Filter = "RMV Motion Files|*.txt";
      openFileDialog1->Title = "Select a Motion File";
      openFileDialog1->FilterIndex = 2;
      openFileDialog1->RestoreDirectory = true;
      // Show the Dialog.
      // If the user clicked OK in the dialog and
      // a .CUR file was selected, open it.
	  if (openFileDialog1->ShowDialog() == ::DialogResult::OK)
      {
         // Assign the cursor in the Stream to
         // the Form's Cursor property.
        // this->Cursor = gcnew
        //    System::Windows::Forms::Cursor(openFileDialog1->OpenFile());
		
         String ^ path = openFileDialog1->FileName;  
         if (!File::Exists(path))
	     {
		   str =  "Invalid filename!";     
           MessageBox::Show( str,"Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
    	   return ;
	      }

	 try
	 {
		FileStream ^fs = gcnew FileStream(path, System::IO::FileMode::Open);
		StreamReader ^sr = gcnew StreamReader(fs);
          Indx_buffer=0;                       // init pointer 
		  motion_counter=0;                   //init motion counter
	  

	  /////-----------------------------	
		do 
		{
		 Line = sr->ReadLine();
		 if (!Line->Contains("*"))
		 {        // Begin to find out which files 
              if  ( Line->Contains("PROFILE_SPEED_CONTROL")) speed_control = true;
			  if  ( Line->Contains("PROFILE_TRAPEZOIDAL_CONTROL")) trapezoidal_control = true; 	
		      //...............................add more 
		      // -------------speed control--------------------
			  if (speed_control)
			  {   

				  ProfSCtrl1->Checked=true;           //Enable the Checked File
				  tabControl6_SelectedIndexChanged(sender,e);         // Update clase
				  do{
					   Line = sr->ReadLine();
					   if (Line == nullptr) break; 
					   if (Line->Contains("END"))
					   {   speed_control=false;
						   break;
					   }
					   str=Line->ToString();
					   if (Line == nullptr) break; 
					   if( str->Contains("SR"))
			           {
                          Line = sr->ReadLine();                 //read another line 
					      if (Line == nullptr) return; 
						  str=Line->ToString();
						  SInt16= (short int) System::Convert::ToInt16(str); 
			              buffer_data[Indx_buffer++] =  SPEED_RATE;  
                          buffer_data[Indx_buffer++] =  SInt16;                     
                          // Read acceleration parameter
					   } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					          }
                           
						  Line = sr->ReadLine();                 //read another line 
					      if (Line == nullptr) break; 
						  str=Line->ToString();
						  if(str->Contains("A"))
						  { 
                            Line = sr->ReadLine();                 //read another line 
	 	   			        if (Line == nullptr) return; 
						    str=Line->ToString();
							SInt16= (short int) System::Convert::ToInt16(str); 
			                buffer_data[Indx_buffer++]  = ACCELERATION;
					        buffer_data[Indx_buffer++] =  SInt16 ;                                // In SPEDD control ACCEL can + ot - 
                          } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					            }             
                          Line = sr->ReadLine();                 //read another line 
					      if (Line == nullptr) break; 
						  str=Line->ToString();
						  if(str->Contains("n"))
						  { 
                            Line = sr->ReadLine();                 //read another line 
	 	   			        if (Line == nullptr) return; 
						    str=Line->ToString();
							LInt32= (short int) System::Convert::ToInt32(str); 
			                buffer_data[Indx_buffer++]  = STEPS_FROM_SLEW_TO_DECEL;
                            buffer_data[Indx_buffer++] =  (unsigned short int)(LInt32 & 0x0000FFFF) ;             //MAx in one time steps numbers = 2^24
                            buffer_data[Indx_buffer++] =  (unsigned short int)((LInt32 & 0xFFFF0000)>>16) ;						   
						    } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					            } 

						 
						  motion_counter++;	
						  MotCounter->Text = System::Convert::ToString(motion_counter);  
                          ArrayLenght->Text = System::Convert::ToString(Indx_buffer);  
			    }while (Line != nullptr);
			  }//------------ End SPEED_CONTROL---------------------

              // --------------TRAPEZIODAL CONTROL------------------
			  if (trapezoidal_control)
			  {  
				  
					ProfTrapCtrl1->Checked = true; 
			        tabControl6_SelectedIndexChanged(sender,e);         // Update clase
				  do{
					   Line = sr->ReadLine();
					   if (Line == nullptr) break; 
					   if (Line->Contains("END"))
					   {   speed_control=false;
						   break;
					   }
					   str=Line->ToString();
					  
					   if( str->Contains("N"))
			           {
                          Line = sr->ReadLine();                 //read another line 
					      if (Line == nullptr) return; 
						  str=Line->ToString();
						  LInt32= (short int) System::Convert::ToInt32(str); 
			               buffer_data[Indx_buffer++]= SET_NUMBER_OF_STEPS; 
                           buffer_data[Indx_buffer++] =  (unsigned short int)(LInt32 & 0x0000FFFF) ;             //MAx in one time steps numbers = 2^24
                           buffer_data[Indx_buffer++] =  (unsigned short int)((LInt32 & 0xFFFF0000)>>16) ;		       
                                      
                          // Read acceleration parameter
					   } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					          }
                           
						  Line = sr->ReadLine();                 //read another line 
					      if (Line == nullptr) break; 
						  str=Line->ToString();
						  if(str->Contains("A"))
						  { 
                            Line = sr->ReadLine();                 //read another line 
	 	   			        if (Line == nullptr) return; 
						    str=Line->ToString();
							SInt16= (short int) System::Convert::ToInt16(str); 
			                buffer_data[Indx_buffer++]  = ACCELERATION;
					        buffer_data[Indx_buffer++] =  SInt16 ;                                // In SPEDD control ACCEL can + ot - 
                          } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					            } 
                           Line = sr->ReadLine();                 //read another line 
					      if (Line == nullptr) break; 
						  str=Line->ToString();
						  if(str->Contains("D"))
						  { 
                            Line = sr->ReadLine();                 //read another line 
	 	   			        if (Line == nullptr) return; 
						    str=Line->ToString();
							SInt16= (short int) System::Convert::ToInt16(str); 
			                buffer_data[Indx_buffer++]  = DECELERATION;
					        buffer_data[Indx_buffer++] =  SInt16 ;                                // In SPEDD control ACCEL can + ot - 
                          } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					            } 
                           Line = sr->ReadLine();                 //read another line 
					       if (Line == nullptr) break; 
						   str=Line->ToString();
						   if( str->Contains("SR"))
			               {
                            Line = sr->ReadLine();                 //read another line 
					        if (Line == nullptr) return; 
						    str=Line->ToString();
						    SInt16= (short int) System::Convert::ToInt16(str); 
			                buffer_data[Indx_buffer++] =  SPEED_RATE;  
                            buffer_data[Indx_buffer++] =  SInt16;                     
                          // Read acceleration parameter
					      } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					          }
                           /*
						   Line = sr->ReadLine();                 //read another line 
					       if (Line == nullptr) break; 
						   str=Line->ToString();
                           if( str=="SI")
			               {
                            Line = sr->ReadLine();                 //read another line 
					        if (Line == nullptr) return; 
						    str=Line->ToString();
						    SInt16= (short int) System::Convert::ToInt16(str); 
			                buffer_data[Indx_buffer++] =  SPEED_INITIAL;  
                            buffer_data[Indx_buffer++] =  SInt16;                     
                          // Read acceleration parameter
					      } else {
                                 MessageBox::Show( "Error in scripting format...","Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
								 return;
					          }
                          */
						  motion_counter++;	
						  MotCounter->Text = System::Convert::ToString(motion_counter);  
                          ArrayLenght->Text = System::Convert::ToString(Indx_buffer);    		   
				     }while (Line != nullptr);


			  }//---------------------------- End TRAPEZOIDAL CONTROL
              //------------------------------------------------------------
		    if (Line->Contains("END"))
			{   speed_control=false;
				break;
			}
		 } // End compare if its a comment -->'*'
		 
		}while (Line != nullptr);            // end reading script file
		
		sr->Close();                         // close file   
	}
	catch(System::Exception ^pe)
	{
      MessageBox::Show(pe->Message ,"Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);  	
	} 


       

   }// END process and read motion file 


		 }
private: System::Void richTextBox5_TextChanged(System::Object^  sender, System::EventArgs^  e) { // Process the data is
		 }

private: System::Void panel1_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
		 }
private: System::Void tabControl6_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {// Load Mpotion TAB
                
			 String ^ str;

			 if (ProfSCtrl1->Checked) {
            // Set Profile Speed control  
                                              // Command  'SR'  (signed)       2 bytes   'SR'
                                              // Slew Rate:  (signed)          2 bytes ; SR=+2000 (signed)
                                              // Command  'A'                  2 bytes   'A'
                                              // Acceleration                  2 bytes ; A=10000 
                                              // Command  'D'                  2 bytes
                                              // Deceleration                  2 bytes  ;D=5000    
                                              // Command  'n'                  2 byes    
                                              // Number os Steps               2 bytes   ;n=850
                                            //                              _________   
                                         //  TOTAL                             16  bytes  



 
			  str = ""; 
			  LabMotB1->Text="Please Type Slew Rate, Acceleration, Step Numbers:\r\n 'n' CW(+), CWW(-)to Slew ratesteps, in Motion Tab\r\n and then Press <ADD to Motion Buffer>";
             LabMotB2->Text ="Slew Rate SR  0.01(rad/sec^1)     :";
			 LabMotB3->Text= "Acceleration A 0.01(rad/sec^2)    :";
			 LabMotB4->Text= "Slew_Rate Steps Number    n       :";
			 str = "Example of Seed Control Motion  : \r";
			 str +="1) Slew Rate       = 2 bytes ; 1000\r\n";
			 str +="2) Acceleration    = 2 bytes ; 10000\r\n";
			 str +="3) SRate Steps Num = 4 bytes; 1500\r\n\r\n"; 
			 str +="Note: Speed direction: CCW= -n or CW= +n";
			 str +="\r\n";
		     MotTrapeL->Text =str;
             SlewRateB->Text="";
			 FirstRateB->Text="";
             SlewRateB->Text="";
			 FirstRateB->Text="";
			 DeccelB->Text ="";
   

			 
			 }else 
				 if (SpeedCtrl1->Checked==true) {   // Speed Control is selected 
 				  /*
			 Speed control  Motion :
            1) Slew Rate      = 2 bytes ; SR20000
            2) Acceleration   = 2 bytes  ; A1000
            3) Smapling Rate  = 1 byte1 ;  D1500
            
           Note:  Steps Numbers can be CW(+) or CCW
	       Label 1: Please Type  "N"," A" , "D" and "SR" and then  press <ADD to Buffer>
		   Label 2: 
		   */
			  
			  str = ""; 
			 LabMotB1->Text="Please Type Slew Rate +SR or -SR, Acceleration, Sampling Rate is selected \r\n in Motion Tab and then Press <ADD to Motion Buffer>";
             LabMotB2->Text ="Slew Rate SR  CW(+) CCW (-)    :";
			 LabMotB3->Text= "Acceleration (Step/sec^2) A    :";
			 LabMotB4->Text= "Sampling Rate 2,1, and 5 mSec  :";
			 LabMotB5->Text= "";
			 LabMotB6->Text= "";
			 str = "Example of Seed Control Motion : \r";
			 str +="1) Slew Rate     = 2 bytes ; -1000\r\n";
			 str +="2) Acceleration  = 2 bytes ;  1000\r\n";
			 str +="3) Slew Rate     = 2 bytes ;   750\r\n";
			 str +="4) Acceleration  = 2 bytes ;   250\r\n";
             str +="5) Slew Rate     = 2 bytes ;  1500\r\n"; 
			 str +="6) Acceleration  = 2 bytes ;  100\r\n\r\n";
			 str +="Note: Speed direction: CCW= -SR or CW= +SR";
			 str +="\r\n";
		     MotTrapeL->Text =str;
             SlewRateB->Text="";
			 FirstRateB->Text="";
             SlewRateB->Enabled=false;
			 FirstRateB->Enabled=false;
			 DeccelB->Enabled =false;
   
			 
			 if (sampling_rate == SAMPLING_RATE_TWO_MSEC ) DeccelB->Text="2 mSec";
			 else if (sampling_rate == SAMPLING_RATE_ONE_MSEC ) DeccelB->Text="1 mSec";
			 else if(sampling_rate == SAMPLING_RATE_FIVE_MSEC ) DeccelB->Text="5 mSec"; 
			 } else       

			 /*
			 Trapezoidal Motion :
              1) Steps Numbers  =4 bytes ; N-20000
              2) Acceleration      =2 bytes  ; A1000
              3) Decelaration      =2 bytes ;  D1500
              4) Slew Rate           =2 bytes  ; SR1400

             Note:  Steps Numbers can be CW(+) or CCW
	         Label 1: Please Type  "N"," A" , "D" and "SR" and then  press <ADD to Buffer>
		     Label 2: 
		   */
              
			 if (ProfTrapCtrl1->Checked==true) { 
			 str = ""; 
			 LabMotB1->Text="Please Type  N , A , D , and  SR, then  press <ADD to Motion Buffer>";
             LabMotB2->Text ="Steps Number  N   CW(+) CCW (-) :";
			 LabMotB3->Text= "Acceleration ((0.01)rad/sec^2) A :";
			 LabMotB4->Text= "Deceleration ((0.01)rad/sec^2) D :";
			 LabMotB5->Text= "Slew Rate  ((0.01)rad/sec^1)  SR :";
			 //LabMotB6->Text= "Initial Rate (Step/sec)  SI :";
			 str = "Example of Trapezoidal Motion : \r";
			 str +="1) Steps Numbers= 4 bytes ; -20000\r\n";
			 str +="2) Acceleration = 2 bytes ;  1000\r\n";
			 str +="3) Decelaration = 2 bytes ;  1500\r\n";
			 str +="4) Slew Rate    = 2 bytes ;  1400\r\n";
             //str +="4) Initial Rate = 2 bytes ;  400\r\n"; 
			 str +="\r\n";
			 str +="Note: Steps Number can be: CW(+) or CCW(-)";
			 str +="\r\n";
		     MotTrapeL->Text =str;
			 SlewRateB->Enabled=true;
			 FirstRateB->Enabled=true;
			 DeccelB->Enabled =true;
			 DeccelB->Text="0";
   
			 }       

		 }
private: System::Void SendData_Click(System::Object^  sender, System::EventArgs^  e) { //  Motion Buffer Send Data to RMVuST857
           
      unsigned short int fifo_command =0;
      unsigned short int fifo_data_avalable=0;
	  String ^ str;
      short int rounds;
	  short int rest=0;
       unsigned short int Indx=0;
	   unsigned short int Indx1=0;
       unsigned short int max_data_lenght;
       
	   // the control is done in bytes, for that reason we times by 2  

	   if (ProfSCtrl1->Checked){      
		   fifo_command = FIFO_PROFILE_SPEED_CONTROL;
           max_data_lenght  = SPEED_CONTROL_ONE_SET_WORD *SPEED_CONTROL_MAX_ITERATIONS;
		   rounds = Indx_buffer / max_data_lenght   ;
     	   rest =   Indx_buffer % max_data_lenght  ;
	   }
	   else if (ProfTrapCtrl1->Checked) {
		     fifo_command = FIFO_PROFILE_TRAPEZOIDAL_CONTROL;                        // by 2  we need bytes
			 max_data_lenght    =TRAPEZOIDAL_ONE_SET_WORD*TRAPEZOIDAL_CONTROL_MAX_ITERATIONS;
			 rounds = Indx_buffer / max_data_lenght ;
	         rest =   (Indx_buffer) %max_data_lenght ;
	   }
	   else if (PosCtrl1->Checked)    fifo_command = FIFO_BUFFER_POSITION_CONTROL;

	 //  else if (ScurveCtrl1->Checked) fifo_command = FIFO_SCURVE_CONTROL ;
//	   else if (ProfCtrl1->Checked)   fifo_command = FIFO_BUFFER_TABLED_PROFILE;
	   else {
		      str =  " Wrong Motion Command ......"  ;    
		       MessageBox::Show( str,"Error in writting motion array ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);     
			 }
           for (int i = 0; i < Indx_buffer; i++)
		   {
                 buffer_data_bckup[i]= buffer_data[i];
		   }

		   if (!FIFOEnable->Checked){
               str =  " FIFO Flag needs to be Enabled and call the function -ST600uNet_SetMotionConfig- later......"  ;    
		       MessageBox::Show( str,"FIFO Flags Not Enabled... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);     
			   return ; 
		   }
		   if ((Indx_buffer) > max_data_lenght )
		   {
           	
				 do 
				 {
                  if (rounds) 
				  {	  Indx += max_data_lenght;
				      rounds--;
				 }else if (rest){
				    	  Indx = Indx_buffer - Indx;
					      rest=0;
				  } 
				  if(ST600uNet_FIFOWriteMotion(motor_addr_mask, & buffer_data_bckup[Indx1], Indx,	fifo_command, &fifo_data_avalable ))
		          {
		           ST600uNet_GetError(Error);
		           str =  marshal_as<String^>(Error);     
		           MessageBox::Show( str,"Error in FIFO writting motion array ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               	  
		           FifoSpace->Text=System::Convert::ToString(0);         // Display Motion Counter textbox 	
				   // leave 
				   break;
		          }else FifoSpace->Text=System::Convert::ToString(fifo_data_avalable) ;         // Display Motion Counter textbox 	

                  Indx1 =Indx;                                                        // Copy Value to start next round 
                
				 }while((rounds !=0)|| (rest !=0)); 
 
		   } else {
		   
                 if(ST600uNet_FIFOWriteMotion(motor_addr_mask, & buffer_data_bckup[0], Indx_buffer,	fifo_command, &fifo_data_avalable ))
		         {
		          ST600uNet_GetError(Error);
		          str =  marshal_as<String^>(Error);     
		          MessageBox::Show( str,"Error in FIFO writting motion array ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               	  
		          FifoSpace->Text=System::Convert::ToString(0) ;         // Display Motion Counter textbox 	
		         }else FifoSpace->Text=System::Convert::ToString(fifo_data_avalable) ;         // Display Motion Counter textbox 	
		   }


}



private: System::Void label23_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label26_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void AddBuffer_Click(System::Object^  sender, System::EventArgs^  e) {// Add to Buffer data and Build buffer array
       

			 String ^ str;
             long steps_number =0;
			 bool status =true;  
			 short unsigned int acceleration=0;
			 short unsigned int deceleration=0;
			 short int slew_rate=0;
			 short unsigned int initial_speed=0;
			 long slew_steps=0;

  			 if (ProfSCtrl1->Checked)
			 {
                // Set Speed control   // Set Profile Speed control  
                                              // Command  'SR'  (unsigned)     2 bytes   'SR'
                                              // Slew Rate:  (unsigned)        2 bytes ; SR=+2000 (unsigned )
                                              // Command  'A' (unsigned)       2 bytes   'A'
                                              // Acceleration                  2 bytes ; A=10000 
                                              // Command  'n'  (signed)        2 byes    
                                              // Number os Steps               4 bytes   ;n=850
                                            //                              _________   
                                         //  TOTAL                             16  bytes  
                                         //
                  if(( StepNumB->Text!="")&& (AccelB->Text!="") )
			      {
                       slew_rate= (short int) System::Convert::ToInt16(StepNumB->Text); 
			           buffer_data[Indx_buffer++] =  SPEED_RATE;   
                       buffer_data[Indx_buffer++] =  slew_rate;                     
                       buffer_data[Indx_buffer++]  = ACCELERATION;
					   acceleration = System::Convert::ToUInt16(AccelB->Text); 
				       buffer_data[Indx_buffer++] =  acceleration ;                                // In SPEDD control ACCEL can + ot - 
                       buffer_data[Indx_buffer++] = STEPS_FROM_SLEW_TO_DECEL;
					   slew_steps= System::Convert::ToUInt32(DeccelB->Text); 
                       buffer_data[Indx_buffer++] =  (unsigned short int)(steps_number & 0x0000FFFF) ;             //MAx in one time steps numbers = 2^24
                       buffer_data[Indx_buffer++] =  (unsigned short int)((steps_number & 0xFFFF0000)>>16) ;                       
					   motion_counter++;
					   MotCounter->Text = System::Convert::ToString(motion_counter);  
                       ArrayLenght->Text = System::Convert::ToString(Indx_buffer);    

			      } else {
						      str =  " A Profile Control field is empty ......"  ;    
		                      MessageBox::Show( str,"Error in writting motion array ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);     
				   	   }
			 }

                   if (TrapeCtrl1->Checked==true) 
				   { 
				    //  Command : 'N'       2 byte
                                            // Total Steps Number:  4 bytes (signed)
                                            //  Command : 'A'       2 bytes           
                                            // Accel :              2 bytes
                                            // Command : 'D'        2 bytes
                                            // Decel :              2 bytes
                                            // Command  'SR'        2 bytes 
                                            // Slew Rate:           2 bytes
                                           
                                           //                    ____________
                                          // Total                18 bytes
					   if(( StepNumB->Text!="")&& (AccelB->Text!="") && (DeccelB->Text!="") && (SlewRateB->Text!="") && (FirstRateB->Text!="")) 
					   {	   
				           steps_number= (long)System::Convert::ToInt32(StepNumB->Text); 
                           buffer_data[Indx_buffer++]= SET_NUMBER_OF_STEPS; 
                           buffer_data[Indx_buffer++] =  (unsigned short int)(steps_number & 0x0000FFFF) ;             //MAx in one time steps numbers = 2^24
                           buffer_data[Indx_buffer++] =  (unsigned short int)((steps_number & 0xFFFF0000)>>16) ;		       
                           buffer_data[Indx_buffer++]  = ACCELERATION;
						   acceleration = System::Convert::ToUInt16(AccelB->Text); 
				           buffer_data[Indx_buffer++] =  acceleration ;
                           buffer_data[Indx_buffer++] = DECELERATION;
						   deceleration = System::Convert::ToUInt16(DeccelB->Text); 
                           buffer_data[Indx_buffer++] =  deceleration ;
				           buffer_data[Indx_buffer++] =  SPEED_RATE;   
						   slew_rate = System::Convert::ToUInt16(SlewRateB->Text); 
                           buffer_data[Indx_buffer++] =  slew_rate ;
				          // buffer_data[Indx_buffer++] = SPEED_INITIAL;
						  // initial_speed = System::Convert::ToUInt16(FirstRateB->Text); 
			              //  buffer_data[Indx_buffer++] = initial_speed;
						   motion_counter++;
						   MotCounter->Text = System::Convert::ToString(motion_counter);  
                           ArrayLenght->Text = System::Convert::ToString(Indx_buffer);   

					   }else {
						      str =  " A Trapezoidal motion field is empty ......"  ;    
		                      MessageBox::Show( str,"Error in writting motion array ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);     
					   }

				   }    


		 }
private: System::Void MotAddSelection_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {// Changing Addrees 
		
                int  Aux0;
                 Aux0 = MotAddSelection->SelectedIndex::get();
				 switch (Aux0)          //Set deafult ADDR "0
			     {
				 case 0 :  
                         motor_addr_mask = MOTOR1_ADDR_MASK ;
			     break;
				 case 1:  
                         motor_addr_mask = MOTOR2_ADDR_MASK ;
			     break; 
				 case 2:  
                         motor_addr_mask = MOTOR3_ADDR_MASK ;
			     break; 
				 case 3:  
                         motor_addr_mask = MOTOR4_ADDR_MASK ;
			     break; 
				 case 4:  
                         motor_addr_mask = ALL_MOTOR_ADDR_MASK;
			     break; 
				 default : 
                         motor_addr_mask = MOTOR1_ADDR_MASK ;

			   }
		 
		 }
private: System::Void FIFOfreespace_Click(System::Object^  sender, System::EventArgs^  e) {// Read FIFO bytes available

           unsigned short int fifo_data_avalable =0;
           String ^ str;
 			
		
		       if (ST600uNet_FIFOGetFreeSpace(motor_addr_mask, &fifo_data_avalable ))
					{
				     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in FIFO reading free space... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
                     FifoSpace->Text=System::Convert::ToString(0) ;         // Display Motion Counter textbox 	
					}  
		       FifoSpace->Text=System::Convert::ToString(fifo_data_avalable) ;         // Display Motion Counter textbox

		 }
private: System::Void AccelB_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void tabPage3_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void TrapeCtrl1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {// Trapezoidal Motion

 String ^ str;

			  /*
			 Trapezoidal Motion :
            1) Steps Numbers  =4 bytes ; N-20000
            2) Acceleration      =2 bytes  ; A1000
            3) Decelaration      =2 bytes ;  D1500
            4) Slew Rate           =2 bytes  ; SR1400

           Note:  Steps Numbers can be CW(+) or CCW
	       Label 1: Please Type  "N"," A" , "D" and "SR" and then  press <ADD to Buffer>
		   Label 2: 
		   */
          if (TrapeCtrl1->Checked )
					{
                        TrapeziodalPrameters ^ form = gcnew TrapeziodalPrameters ;
                       form->ShowDialog();
					}

			 if (TrapeCtrl1->Checked==true) { 
			 str = ""; 
			 LabMotB1->Text="Please Type  N , A , D , SI and  SR, then  press <ADD to Motion Buffer>";
             LabMotB2->Text ="Steps Number  N   CW(+) CCW (-) :";
			 LabMotB3->Text= "Acceleration ((0.01)rad/sec^2) A :";
			 LabMotB4->Text= "Deceleration ((0.01)rad/sec^2) D :";
			 LabMotB5->Text= "Slew Rate  ((o.01)rad/sec^1)  SR :";
			// LabMotB6->Text= "Initial Rate (Step/sec)  SI :";
			 str = "Example of Trapezoidal Motion : \r";
			 str +="1) Steps Numbers= 4 bytes ; -20000\r\n";
			 str +="2) Acceleration = 2 bytes ;  1000\r\n";
			 str +="3) Decelaration = 2 bytes ;  1500\r\n";
			 str +="4) Slew Rate    = 2 bytes ;  1400\r\n";
            // str +="4) Initial Rate = 2 bytes ;  400\r\n"; 
			 str +="\r\n";
			 str +="Note: Steps Number can be: CW(+) or CCW(-)";
			 str +="\r\n";
		     MotTrapeL->Text =str;
			 }  
		 }
private: System::Void SampleR_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {//Select Samplingg Rate 

			 int  Aux0;

                 Aux0 = SampleR->SelectedIndex::get();
                 switch (Aux0)
				 {
                   case 0 :  
                         sampling_rate = SAMPLING_RATE_TWO_MSEC ;
			         break;
				 case 1:  
                         sampling_rate = SAMPLING_RATE_ONE_MSEC ;
			     break; 
				 case 2:  
                         sampling_rate = SAMPLING_RATE_FIVE_MSEC ;
			     break; 
				 
				 default : 
                        sampling_rate = SAMPLING_RATE_TWO_MSEC ;
			   }

             
	
		 }
private: System::Void ProfCtrl1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) { // Linked 


		 }
private: System::Void button1_Click_3(System::Object^  sender, System::EventArgs^  e) {// Delete FIFO Data and Working Buffer

          unsigned short int fifo_data_avalable=0;
          String ^str; 
            
            if (ST600uNet_FIFO_DELETE(motor_addr_mask, &fifo_data_avalable ))
					{
				     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in FIFO reading free space... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
                     FifoSpace->Text=System::Convert::ToString(0) ;         // Display Motion Counter textbox 	
					} 
			else {
				    FifoSpace->Text="";  
                    FifoSpace->Text = System::Convert::ToString(fifo_data_avalable);
			}

		 }
		 /*
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {// This Function is strong recommended to not call this function 

            
          String ^str; 
          float voltage_ref ;
		     
		  unsigned int dac_value=255;
		  voltage_ref= (float)1.65;
		  voltage_ref = System::Convert::ToSingle(Vref1->Text);
          dac_value = (unsigned  int) DAC1->Value;
		  if (ST600uNet_PWM_Modulation(motor_addr_mask, 1,40200,voltage_ref,(unsigned short)dac_value ))
		  {
           		     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Setting PWM Kernel ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		  }	 
		

		 }
		 */
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void MSAveParam1_Click(System::Object^  sender, System::EventArgs^  e) { // Save all Motor and Motion parameters to Internal Flash

            String ^str; 
			unsigned short int Error_number=0;
			unsigned short int what_to_save =1;

			MessageBox::Show("Saving Motor Parameters, may take longer than normal functions..... ", "Save data to internal FLASH ", MessageBoxButtons::OK,MessageBoxIcon::Information);
              

		  if (ST600uNet_SAVE_ParametersToInternal_FLASH(motor_addr_mask,what_to_save, & Error_number))
		  {
           		     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Saving Motor Parameters ..... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		  }	 
		 


		 }
private: System::Void notifyIcon1_MouseDoubleClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		 }
private: System::Void VREF_Click(System::Object^  sender, System::EventArgs^  e) {  //Volatge Reference
/*
			     String ^str; 
				

                unsigned short int duty_cycle_divisor;
				 short int command=3;
				 int voltage_reffA,voltage_reffB, voltage_reffC,voltage_reffD=0;
				 //using namespace System::Runtime::InteropServices; // for class Marshal

	           
				 str =Password->Text;
				 const char* pass = (char*)(void*)Marshal::StringToHGlobalAnsi(str);
				// pin_ptr<const char> pass = PtrToStringChars(str);                 //convert to Wchar
			duty_cycle_divisor = (unsigned short int) DIV_DAC->Value;
              if (ST600uNet_Zero_RefVolatge(motor_addr_mask, command, &voltage_reffA, &voltage_reffB, &voltage_reffC, &voltage_reffD,duty_cycle_divisor, (const char*)&pass[0] ))
               {
           		     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Reading Volt Reference  ..... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		       }else
	
			  {
				  Disp1->Text=System::Convert::ToString(voltage_reffA);  
				  Disp2->Text=System::Convert::ToString(voltage_reffB);  
				  Disp3->Text=System::Convert::ToString(voltage_reffC);  
				  Disp4->Text=System::Convert::ToString(voltage_reffD);  

			   }
*/
		 }
private: System::Void VrefON_CheckedChanged(System::Object^  sender, System::EventArgs^  e) { //Turn ON OFF VREF checquing 
 /*
			String ^str; 	
			 short int command=0;
				 int voltage_reffA,voltage_reffB, voltage_reffC,voltage_reffD=0;
				 unsigned short int duty_cycle_divisor;

			     str =Password->Text;
				 const char* pass = (char*)(void*)Marshal::StringToHGlobalAnsi(str);
				// pin_ptr<const char> pass = PtrToStringChars(str);                 //convert to Wchar
				 if ( ENTIMER->Checked ) {timer1->Enabled =true;}
				 if (VrefON->Checked){
					 command =1;
					
				 }
				 else{ 
					  command =2;
					  timer1->Enabled =false;
				 }
                duty_cycle_divisor = (unsigned short int) DIV_DAC->Value;
               if (ST600uNet_Zero_RefVolatge(motor_addr_mask, command, &voltage_reffA, &voltage_reffB, &voltage_reffC, &voltage_reffD,duty_cycle_divisor, (const char*)&pass[0] ))
               {
           		     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Reading Volt Reference  ..... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
			   }   else {
                         if (VrefON->Checked){
				       	     timer1->Enabled =true;
						 }
			   }
*/
		 }
private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {// timer1 

/*
             String ^str; 
				
			 short int command=3;
			 unsigned short int duty_cycle_divisor;
				 int voltage_reffA,voltage_reffB, voltage_reffC,voltage_reffD=0;
				
			     str =Password->Text;
				 const char* pass = (char*)(void*)Marshal::StringToHGlobalAnsi(str);
				// pin_ptr<const char> pass = PtrToStringChars(str);                 //convert to Wchar
				 duty_cycle_divisor = (unsigned short int) DIV_DAC->Value;
               if (ST600uNet_Zero_RefVolatge(motor_addr_mask, command, &voltage_reffA, &voltage_reffB, &voltage_reffC, &voltage_reffD,duty_cycle_divisor, (const char*)&pass[0] ))
               {
           		     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Reading Volt Reference  ..... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);   
					 timer1->Enabled=false;
		       }  else
	
			  {
				  Disp1->Text=System::Convert::ToString((short int)voltage_reffA);  
				  Disp2->Text=System::Convert::ToString((short int)voltage_reffB);  
				  Disp3->Text=System::Convert::ToString((short int)voltage_reffC);  
				  Disp4->Text=System::Convert::ToString((short int)voltage_reffD);  

			   }
*/
		 }
private: System::Void richTextBox5_TextChanged_1(System::Object^  sender, System::EventArgs^  e) {
		 }

private: System::Void button6_Click_1(System::Object^  sender, System::EventArgs^  e) {
  /*
          String ^str; 
          float dac_gain;   
		 // unsigned int dac_value=255;
		  unsigned char dac_time_2;
		  unsigned short int winding_current_in_mAmp;
         

		   dac_gain = (float)0.60;  
		   dac_gain = System::Convert::ToSingle(Vref1->Text);
          // dac_value = (unsigned  int) DAC1->Value;
                
		   if (Ring1->Checked ) dac_time_2 = 1;
		   else dac_time_2 = 0;
		    str =Password->Text;
			const char* pass = (char*)(void*)Marshal::StringToHGlobalAnsi(str);

             winding_current_in_mAmp = (unsigned int) System::Convert::ToInt16 (MCurrt1->Text);
			

		  if (ST600uNet_PWM_Modulation(motor_addr_mask, 1,40200,dac_gain,dac_time_2,winding_current_in_mAmp,(const char*)&pass[0]))
		  {
           		     ST600uNet_GetError(Error);
		             str =  marshal_as<String^>(Error);     
		             MessageBox::Show( str,"Error in Setting PWM Kernel ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		  }	 
		
*/

		 }
/*		 
private: System::Void ST600uNet_DAC_VREF_Adjust(System::Object^  sender, System::EventArgs^  e) {

           String ^str;  
		   float voltage_ref =0.00;
           unsigned char times_by_two =0;
           unsigned short int dac_value;     

		   const char* pass = (char*)(void*)Marshal::StringToHGlobalAnsi(str);
           dac_value = (unsigned  int) DAC1__ValueChanged->Value;
           voltage_ref = System::Convert::ToSingle(Vref1->Text);
		 if (ST600uNet_DAC_VREF_Adjust(motor_addr_mask,times_by_two,dac_value, voltage_ref,(const char*)&pass[0]))
		 {
		  ST600uNet_GetError(Error);
		  str =  marshal_as<String^>(Error);     
		  MessageBox::Show( str,"Error in Setting DAC Kernel ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		 
		 }

		 }
		 */
private: System::Void DIV_DAC_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void DAC1_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
/*		
			 String ^str;  
		   float voltage_ref =0.00;
           unsigned char times_by_two =0;
           unsigned short int dac_value;
		   unsigned short int testing_flags=0;
           unsigned short int which_chopper=0;

           if(TCAC->Checked)         which_chopper=1;   
		   else if (TCBD->Checked)   which_chopper=2;
		   else if (TCACBD->Checked) which_chopper=4;
		   else which_chopper=0;

		   str =Password->Text;
		   const char* pass = (char*)(void*)Marshal::StringToHGlobalAnsi(str);
           dac_value = (unsigned  int) DAC1__ValueChanged->Value;
           voltage_ref = System::Convert::ToSingle(Vref1->Text);

		   testing_flags = (unsigned short int ) System::Convert::ToDecimal(KFlagsT->Text);

		 if (ST600uNet_DAC_VREF_Adjust(motor_addr_mask,times_by_two,dac_value, voltage_ref,testing_flags,which_chopper,(const char*)&pass[0]))
		 {
		  ST600uNet_GetError(Error);
		  str =  marshal_as<String^>(Error);     
		  MessageBox::Show( str,"Error in Setting DAC Kernel ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		 
		 }
		 */
		 }
private: System::Void tabPage5_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void richTextBox5_TextChanged_2(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label27_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void AdjustMIN_Click(System::Object^  sender, System::EventArgs^  e) {// Adjust to Zero Voltage 

           String ^str;  
		   unsigned short int adjust_by_zero_or_max=ADJUST_CURRENT_BY_ZERO;
            progressBar1->Value =0;		  
		   unsigned short int max_current=(unsigned short int) System::Convert::ToInt16 (MCurrt1->Text);
           unsigned short int Error_number=0;

           if ( ST600uNet_Adjust_Current( motor_addr_mask, adjust_by_zero_or_max,max_current,&Error_number))
            {
		      ST600uNet_GetError(Error);
		       str =  marshal_as<String^>(Error);     
		     MessageBox::Show( str,"Error in Adjusting current to a minimum ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		 
		   }else{  
               MessageBox::Show( "Adjusting driver to minimum motor power ... ","Adjusting chopper driver current .... ", MessageBoxButtons::OK,MessageBoxIcon::Exclamation);			
			   timer2->Enabled= true;
			   AdjustMiddle->Enabled = true; 
			   //AdjustMAX->Enabled= true;

		   }
		 }
private: System::Void AdjustMAX_Click(System::Object^  sender, System::EventArgs^  e) {// Adjust to MAX Voltage
            String ^str;  
		           
          
           unsigned short int adjust_by_zero_or_max=ADJUST_CURRENT_BY_MAXIMUM ;
		     unsigned short int max_current=(unsigned short int) max_current=(unsigned short int) System::Convert::ToInt16 (MCurrt1->Text);
		   unsigned short int Error_number=0;
			 progressBar1->Value =0;		  
		  
         
           if (ST600uNet_Adjust_Current(motor_addr_mask, adjust_by_zero_or_max, max_current,&Error_number))
            {
		      ST600uNet_GetError(Error);
		       str =  marshal_as<String^>(Error);     
		     MessageBox::Show( str,"Error in Adjusting driver to a maximum ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
		   }else{  
                MessageBox::Show( "Adjusting driver to maximum motor power ...","Adjusting chopper driver current ...", MessageBoxButtons::OK,MessageBoxIcon::Exclamation);  
			   timer2->Enabled= true;
			   //AdjustMIN->Enabled =true;
		   }

		 }
private: System::Void timer2_Tick(System::Object^  sender, System::EventArgs^  e) { //timer 2


			 if (progressBar1->Value ==100){
				 timer2->Enabled=false;
				 AdjustMAX->Enabled= true;
				 AdjustMIN->Enabled =true;
				 AdjustMiddle->Enabled = true; 
             }
			 else{ 
				 progressBar1->Value +=10; 
				 AdjustMAX->Enabled= false;
				 AdjustMIN->Enabled =false; 
				  AdjustMiddle->Enabled = false; 
			 }

		 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) { // Adjaust Curent by Zero

			// std::string str;
			 String ^ str2;
              unsigned short int Error_number =0;            
			 unsigned short int current_driver_flags;
			 unsigned short int what_kind_of_report=ADJUST_CURRENT_BY_ZERO;
			// str = "<>";
			
			if (ST600uNet_Get_Internal_Report(motor_addr_mask,& current_driver_flags, what_kind_of_report ,&Error_number))
			 {
                 ST600uNet_GetError(Error);
		         str2 =  marshal_as<String^>(Error);     
		         MessageBox::Show( str2,"Error in reading current report  ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);  

			 }else{           // no error 
/*			
				 if (current_driver_flags & CURRENT_PARAMETERS_SAVED)   CurrentParaSaved->Checked = true; 
				 else CurrentParaSaved->Checked = false; 
				 if (current_driver_flags & DRIVER_ZERO_CURRENT_ADJUSTED ) ZeroCurrAdj->Checked =true;
				 else ZeroCurrAdj->Checked =false;
				 if (current_driver_flags & DRIVER_MAX_CURRENT_ADJUSTED) MaxCurrAdj->Checked =true;
				 else MaxCurrAdj->Checked = false;
				  String^ str3 = gcnew String(str.c_str());
				 Status->Text=  str3 ;
			
*/			  
				 if (current_driver_flags & CURRENT_PARAMETERS_SAVED){
					   CurrentParaSaved->Checked = true; 
				       str2 = " Current Parameters Saved, ";
				 }else {
					 CurrentParaSaved->Checked = false; 
				     str2 =" Current Parameters Not Saved, ";
				 }	 
			     if (current_driver_flags & DRIVER_ZERO_CURRENT_ADJUSTED ) ZeroCurrAdj->Checked =true;
				 else ZeroCurrAdj->Checked =false;
				 if (current_driver_flags & DRIVER_MAX_CURRENT_ADJUSTED) MaxCurrAdj->Checked =true;
				 else MaxCurrAdj->Checked = false;
                 if (current_driver_flags & DRIVER_HALF_CURRENT_ADJUSTED ) MiddleCurrAdj->Checked =true;
				 else MiddleCurrAdj->Checked = false; 
                 if ((ZeroCurrAdj->Checked) &&(MaxCurrAdj->Checked))
                  str2 +="Driver Min.& Max. Current are Calibrated" ;
				 else str2 += " Chopper Driver is not -Calibrated-"; 
				 if (current_driver_flags & CHOPER_DRIVER_CAN_NOT_SET_MAX_MIN ) str2 = "CHOPPER DRIVER ERROR...";
				 
				 //  String^ str3 = gcnew String(str.c_str());
				 Status->Text=  str2 ;

			 
			 
			 
			 
			 }


		 }
private: System::Void CurrentSave_Click(System::Object^  sender, System::EventArgs^  e) { //Save Current Paramteres to FLASH

             unsigned short int what_to_save=SAVE_CURRENT_PARAMETERS_TO_FLASH;
			 unsigned short Error_number=0;
             std::string str;
			 String ^ str2;
             
    		 if (ST600uNet_SAVE_ParametersToInternal_FLASH(motor_addr_mask,what_to_save ,&Error_number))
            {
		      ST600uNet_GetError(Error);
		      str2 =  marshal_as<String^>(Error);     
		      MessageBox::Show( str2,"Error in saving data to flash memory ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
			 }else{
				 
                String^ str3 = gcnew String(str.c_str());
  			    Status->Text=  str3 ;
			 }



		 }
private: System::Void button6_Click_2(System::Object^  sender, System::EventArgs^  e) {// READ an HEX File 

//  String ^ Line;
  String ^ str;
  std::string str1;
 
  

// Displays an OpenFileDialog so the user can select a Cursor.
      OpenFileDialog ^ openFileDialog1 = gcnew OpenFileDialog();
      openFileDialog1->Filter = "ST600uNET firmware update|*.HEX";
      openFileDialog1->Title = "Select ST600uNet new firmware ";
      openFileDialog1->FilterIndex = 2;
      openFileDialog1->RestoreDirectory = true;
      // Show the Dialog.
      // If the user clicked OK in the dialog and
      // a .CUR file was selected, open it.
	  if (openFileDialog1->ShowDialog() == ::DialogResult::OK)
      {
         // Assign the cursor in the Stream to
         // the Form's Cursor property.
        // this->Cursor = gcnew
        //    System::Windows::Forms::Cursor(openFileDialog1->OpenFile());
		
       //  String ^ path = openFileDialog1->FileName;  
		 
		    String^ path= gcnew String(str1.c_str());
           path= openFileDialog1->FileName;  
         if (!File::Exists(path))
	     {
		   str =  "Invalid filename!";     
           MessageBox::Show( str,"Error in reading firmware upgrade File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
    	   return ;
	      }
		 Address->Text =path;

/*
	 try
	 {
		FileStream ^fs = gcnew FileStream(path, System::IO::FileMode::Open);
		StreamReader ^sr = gcnew StreamReader(fs);
        Indx_buffer=0;                       // init pointer 
	     motion_counter=0;                   //init motion counter
	    
	  /////-----------------------------	
		do 
		{
		 Line = sr->ReadLine();
		 
		 
		}while (Line != nullptr);            // end reading script file
		
		sr->Close();                         // close file   
	 }
	catch(System::Exception ^pe)
	{
      MessageBox::Show(pe->Message ,"Error in reading File ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);  	
	} 
    
	*/
		 Error_number=0;
	   const  char* address_of_the_file = (char*)(void*)Marshal::StringToHGlobalAnsi(path);
         if(ST600uNet_Bootloader_Load_HexFile(motor_addr_mask,address_of_the_file,(unsigned short int)strlen(address_of_the_file),&Error_number))
		 {
                 ST600uNet_GetError(Error);
		         str =  marshal_as<String^>(Error);     
		         MessageBox::Show( str,"Error in reading current report  ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);  

		 }else {
                 FlashStatus->Text = "The New Firmware file has been read with <NO ERROR>"  ;
				 //ProgramFlash->Enabled =true;
		 }

	  } // End of Dialog    




}

private: System::Void BootLoader_Click(System::Object^  sender, System::EventArgs^  e) {// Enter in Boot loader mode

	             
			 String ^ str2;
            
             Error_number=0;
 
               MessageBox::Show( "All firmaware Update has been Disabled in this version Demo" ,"No BooLoader Flash Memory functions are Enabled ....", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
               return ;

    		 if( ST600uNet_Run_Bootloader(motor_addr_mask, & Error_number))
				
             {
		      ST600uNet_GetError(Error);
		      str2 =  marshal_as<String^>(Error);     
		      MessageBox::Show( str2,"Error in enter to bootloader mode .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
			 }
               else{
               ReadHex->Enabled = true;
			   BootLoaderInfo->Enabled =true;
			   EraseF->Enabled =true;
			  
  			    FlashStatus->Text =  " In Bootloader Mode ..........." ;
			 }
		 }
private: System::Void label37_Click(System::Object^  sender, System::EventArgs^  e) {
		 }


private: System::Void BootLoaderInfo_Click(System::Object^  sender, System::EventArgs^  e) {// Bootloader Get VErsion 
            String ^ str2,^str1;
             
             unsigned char major_ver=0;
			 unsigned char minor_ver=0;
               Error_number=0;
    		 if(ST600uNet_Bootloader_Version(motor_addr_mask,&major_ver ,&minor_ver,& Error_number))
				
             {
		      ST600uNet_GetError(Error);
		      str2 =  marshal_as<String^>(Error);     
		      MessageBox::Show( str2,"Error in enter to bootloader mode .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
			 }
               else{
				   str1 = "   VER =  ";
				   str2 = " . ";
                   BootL->Text = str1  +System::Convert::ToString(major_ver) +str2 + System::Convert::ToString(minor_ver);
			 }

		 }
private: System::Void ProgramFlash_Click(System::Object^  sender, System::EventArgs^  e) {// Program Flash 

			 String   ^str1;
              Error_number=0;
		
			FlashProgresBar->Value = 0;
    		 if( ST600uNet_Bootloader_ProgramFlash( motor_addr_mask,& Error_number))				
             {
			  timer3->Enabled =false;
		      ST600uNet_GetError(Error);
		      str1 =  marshal_as<String^>(Error);     
		      MessageBox::Show( str1,"Error in programing the Flash .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    	     
			 }
               else{
				 //  timer3->Enabled = false;
				   str1 = "   Programming Flash memory , please wait until it is finished...... ";
				   	 timer3->Enabled =true;
				   FlashStatus->Text = str1;
				   VerifyF->Enabled =false;
				   ProgramFlash->Enabled =false;
				   ReadHex->Enabled = false;
			       BootLoaderInfo->Enabled =false;
			       EraseF->Enabled =false;
				   RUN_APP->Enabled =false;
			 }

		//


		 }
private: System::Void button6_Click_3(System::Object^  sender, System::EventArgs^  e) { //verify program
			 
                String ^str2;
           
            Error_number=0;
    		 if( ST600uNet_Bootloader_VerifyFlash( motor_addr_mask,& Error_number))
				
             {
		      ST600uNet_GetError(Error);
		      str2 =  marshal_as<String^>(Error);     
		      MessageBox::Show( str2,"Error in verifying the Flash Memory.... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
			 }
               else{
				   str2 = "   Verifying Flash Memory , please wait until all memory is deleteaded ....   ";
				  
                   FlashStatus->Text = str2;
				   MessageBox::Show( "Flash Memory has been successful verified .... ","Flash Memory Verify ", MessageBoxButtons::OK,MessageBoxIcon::Asterisk);    
			 }

		 }
private: System::Void button7_Click_1(System::Object^  sender, System::EventArgs^  e) {// Erase Flash memory

                String ^str2;
           
            
			   str2 = "   Erasing Flash Memory , please wait until all memory is deleteaded ....   ";
				Error_number=0;  
               FlashStatus->Text = str2;
    		 if( ST600uNet_Bootloader_EraseFlash( motor_addr_mask,& Error_number))
				
             {
		      ST600uNet_GetError(Error);
		      str2 =  marshal_as<String^>(Error);     
		      MessageBox::Show( str2,"Error in programing the Flash .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
			 }
               else{
				   str2 = "   !!Flash Memory, has been erased successfully .....   ";
				  
                   FlashStatus->Text = str2;
				    ProgramFlash->Enabled =true;
			 }


		 }
private: System::Void timer3_Tick(System::Object^  sender, System::EventArgs^  e) { //timer 3 

			 String ^str2;
			 unsigned int actual_record=0;
			 unsigned  int total_records=0;
			
                 
                if( ( ST600uNet_Bootloader_Progress(motor_addr_mask,& actual_record,& total_records,& Error_number )) || (Error_number !=0))
				{
				  timer3->Enabled = false;
                  ST600uNet_GetError(Error);
		          str2 =  marshal_as<String^>(Error);     
		          MessageBox::Show( str2," Timer Error in programing the Flash .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     

				}else{
                  
					if (actual_record ==total_records){
						str2 = " FlashProgrammed: 100%";
						BootL->Text =str2;
						timer3->Enabled = false;
						VerifyF->Enabled =true;
				        ProgramFlash->Enabled =true;
				        ReadHex->Enabled = true;
			            BootLoaderInfo->Enabled =true;
			            EraseF->Enabled =true;
				        RUN_APP->Enabled =true;

					}else if (actual_record < total_records){
						   BootL->Text=""; 
						   str2 = " Flash Programmed:";
						   FlashProgresBar->Value = (int)((actual_record *100)/total_records);
						   str2 += System::Convert::ToString(((int)(actual_record *100)/total_records));
						   str2 += " %";
						   BootL->Text =str2;
					}
				}


		 }
private: System::Void RUN_APP_Click(System::Object^  sender, System::EventArgs^  e) { //Run Applcation 


                String ^str2;
           
            
			   str2 = "   Erasing Flash Memory , please wait until all memory is deleteaded ....   ";
				Error_number=0;  
               FlashStatus->Text = str2;

             if (ST600uNet_Bootloader_RunApplication( motor_addr_mask,& Error_number ))			
             {
		      ST600uNet_GetError(Error);
		      str2 =  marshal_as<String^>(Error);     
		      MessageBox::Show( str2,"Error in programing the Flash .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
			 }
               else{
				   str2 = "   !!Application is running successfully .....   ";
				  
                   FlashStatus->Text = str2;

				        timer3->Enabled = false;
						VerifyF->Enabled =false;
				        ProgramFlash->Enabled =false;
				        ReadHex->Enabled = false;
			            BootLoaderInfo->Enabled =false;
			            EraseF->Enabled =false;
				        RUN_APP->Enabled =false;
						BootLoader->Enabled=true;
				    
			 }



		 }
private: System::Void button6_Click_4(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button6_Click_5(System::Object^  sender, System::EventArgs^  e) { // Pause Motion  

		 }
private: System::Void SEQ_Event_CheckedChanged(System::Object^  sender, System::EventArgs^  e) { // Enable Sequential Event Table 
//                String ^ str;     
			 unsigned short int Error_number =0;

		 if (SEQ_Event->Checked )
		 {         //Open the SEQ window
            Sequential_Trigger  ^ form = gcnew Sequential_Trigger ;
            form->ShowDialog();

		 }// If the the following commnents are disabled please delete this braquet 
		   /*
			  if (ST600uNet_Set_Sequential_Motion(motor_addr_mask,seq_motion_controllers_enabled ,pivot_controllers_mask, & Error_number))
			  {
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);   
						  return;
		      }// No Error Set up the Mask   
			  else if  ( ST600uNet_Sequential_Motion_Interrupt_MASK(motor_addr_mask, sequential_trigger_mask ,& Error_number))         
			  {
					 ST600uNet_GetError(Error);
				     str =  marshal_as<String^>(Error);     
				     MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);	
			  }			
		  }else     //Sequential Motion flag Disable
					{
                       if( ST600uNet_Disable_Sequential_Motion(motor_addr_mask, &Error_number))
					   {
				  	     ST600uNet_GetError(Error);
				         str =  marshal_as<String^>(Error);     
				         MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);	
					   }
					}// End SEQ Disable
					*/
			
		 }
private: System::Void ControlMode_Click(System::Object^  sender, System::EventArgs^  e) { // Set control mode Only 
            

		 }
private: System::Void SetpNum1_ValueChanged(System::Object^  sender, System::EventArgs^  e) {//Change position on the fly 
			 
			   String ^ str;
               unsigned short int Error_number;
               long step_numbers=0;  
               short int MotorSpeed;
			   unsigned short int Acceleration, Deceleration;

			 if (PosCtrl1->Checked){ // Position  Control Real time speed change
                 step_numbers= (int) (SetpNum1->Value);
			      MotorSpeed= (  int) Speed1->Value;
				  Acceleration= (unsigned  int) Accel1->Value;
				  Deceleration= (unsigned  int) Decel1->Value;


				  if (ST600uNet_Set_StepNumbersControl(motor_addr_mask,STEP_NUM_POSITION_CNTRL, step_numbers,MotorSpeed, Acceleration ,Deceleration,&Error_number ))
				  {
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		            }  
			 }//else MessageBox::Show( "POSITION CONTROL NEEDS TO BE SELECTED"," Error Motor Position Control ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 

		 }
private: System::Void groupBox9_Enter(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void SetHoldingTorque_Click(System::Object^  sender, System::EventArgs^  e) {// Set Holding torque

			  String ^ str;
               unsigned short int Error_number;
              unsigned short int which_holding_current=0;
                
			  if (HoldingCF->Checked) which_holding_current= HOLDING_TORQUE1;
			  else if (HoldingC25->Checked) which_holding_current=HOLDING_TORQUE2; 
              else if (HoldingC50->Checked) which_holding_current=HOLDING_TORQUE3;    
			//  else (HoldingC75->Checked) which_holding_current=HOLDING_TORQUE4;  Not implemented in this version demo 
			      if ( ST600uNet_Set_HoldingTorque(motor_addr_mask,which_holding_current,& Error_number ))
				   {
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		            }  

		 }
private: System::Void CW_Click(System::Object^  sender, System::EventArgs^  e) {// Move motor CW 
               String ^ str;
               unsigned short int Error_number;
               long step_numbers=0;  
               short int MotorSpeed;
			   unsigned short int Acceleration, Deceleration;

			 if (TrapeCtrl1->Checked){ // Trapezoidal Control Real time speed change
                  step_numbers= (int) (SetpNum1->Value);
				  if (step_numbers <0)step_numbers *=-1;           // In CW step_numbers must be + 
			      MotorSpeed= (  int) Speed1->Value;
				  Acceleration= (unsigned  int) Accel1->Value;
				  Deceleration= (unsigned  int) Decel1->Value;
				  StepRegister->Text= "0"; 
                     long step_counter=0;  
               		
				  if (ST600uNet_MotorStepsMove(motor_addr_mask,step_numbers, MotorSpeed, Acceleration,Deceleration,  &Error_number ))
				  {
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				  }else timer4->Enabled =true;
				  
			 }else MessageBox::Show( "TRAPEZOIDAL CONTROL NEEDS TO BE SELECTED FIRST"," Error Motor in CW Function ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 


		 }
private: System::Void CCW_Click(System::Object^  sender, System::EventArgs^  e) {// Move motor CCW 
               String ^ str;
               unsigned short int Error_number;
               long step_numbers=0;  
               short int MotorSpeed;
			   unsigned short int Acceleration, Deceleration;

			 if (TrapeCtrl1->Checked){ // Trapezoidal Control Real time speed change
                  step_numbers= (int) (SetpNum1->Value);
				  if (step_numbers >0)step_numbers *=-1;           // In CW step_numbers must be -
			      MotorSpeed= (  int) Speed1->Value;
				  Acceleration= (unsigned  int) Accel1->Value;
				  Deceleration= (unsigned  int) Decel1->Value;
				  StepRegister->Text= "0"; 


                  if (ST600uNet_MotorStepsMove(motor_addr_mask,step_numbers, MotorSpeed, Acceleration,Deceleration,  &Error_number ))
				  {
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		            }else  timer4->Enabled=true;             // Enable timmer   
			 }else MessageBox::Show( "TRAPEZOIDAL CONTROL NEEDS TO BE SELECTED FIRST"," Error Motor in CCW Function ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 


		 }
private: System::Void timer4_Tick(System::Object^  sender, System::EventArgs^  e) { //Timer 4 Read Motor Report Compleated
                String ^ str;
               unsigned short int Error_number;
               long step_counter=0;  
               unsigned short int motor_internal_flags_1;
			   unsigned short int motor_internal_flags_2;
			   unsigned short int over_current_counter;
			   unsigned short int over_temperature_counter;

			 if (ST600uNet_Get_StepsCounter_MotorF_Report( motor_addr_mask,&motor_internal_flags_1,&motor_internal_flags_2, &step_counter ,
				                  &over_current_counter, &over_temperature_counter,&Error_number))
			 {
				  timer4->Enabled=false; 
	              ST600uNet_GetError(Error);
				  str =  marshal_as<String^>(Error);     
				  MessageBox::Show( str,"Error in Timer Step Counter Read ", MessageBoxButtons::OK,MessageBoxIcon::Hand);           
			 }else {
                   // Add here all events will STOP the timer
				 if ((motor_internal_flags_1 & MOTION_COMPLEATED) /*|| (motor_internal_flags_1 & MOTOR_STOPPED) */){
					  MCompleated->Checked =true;
					  timer4->Enabled=false;
				 } else MCompleated->Checked = false;
                 if ( motor_internal_flags_2 &CHOPPER_OVER_CURRENT_UNDERVOLT)  // Over Current FAULT Flag
					 Fault_F->Checked = true;
				 else Fault_F->Checked = false;
                     if ( motor_internal_flags_2 &CHOPPER_OVER_TEMPERATURE)  // Over Current FAULT Flag
					 OTW_F->Checked = true;
				 else OTW_F->Checked = false;
                  
               if ( motor_internal_flags_1 &LSW_RIGHT)  // Over Current FAULT Flag
					  LSW_Right->Checked = true;
				 else LSW_Right->Checked = false;
                     if ( motor_internal_flags_1 &LSW_LEFT)  // Over Current FAULT Flag
					  LSW_Left->Checked = true;
				 else  LSW_Left->Checked = false;
              


				 StepRegister->Text= System::Convert::ToString(step_counter);
				 Error_Counter->Text = "F:" + System::Convert::ToString(over_current_counter)+"--T:" + System::Convert::ToString(over_temperature_counter);
			 }


		 }

private: System::Void Accel1_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Output_0_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label56_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void SOutPut_Click(System::Object^  sender, System::EventArgs^  e) {// Digital IO's 

               String ^ str;
               unsigned short int Error_number;
               unsigned char output_value=0;  
               unsigned char input_value=0;
			   switch (motor_addr_mask)			   {
			   case 1:{
				      if (Output_0->Checked) output_value=1;
                      if (Output_1->Checked) output_value |=2;    
					  }
				   break;
			   case 2:{
				      if (Output_2->Checked) output_value=1;
                      if (Output_3->Checked) output_value |=2;    
					  }
				   break;
                case 3:{
				      if (Output_4->Checked) output_value=1;
                      }
					   break;
                    case 4:{
				      if (Output_5->Checked) output_value=1; 
					  }
				   break;
			   }
                  if (ST600uNet_Digital_Input_Output(motor_addr_mask,output_value, &input_value, & Error_number))
                   {
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in setting motor speed ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				  }else {
					     switch (motor_addr_mask)
					 {
			           case 1:
						   if (input_value) Input_0->Checked = true;
                       break;
			          case 2:
						 if (input_value) Input_1->Checked = true;
				       break;
                       case 3:
				        if (input_value) Input_2->Checked = true;;
					    break;
                       case 4:
						 if (input_value) Input_3->Checked = true;;
				       break;
			         }

				  }
			



		 }
private: System::Void Reset_Click(System::Object^  sender, System::EventArgs^  e) { //Reset
           
             String ^ str;  
			 unsigned short int what_to_reset;
             unsigned short int  Error_number=0;

			 // We have a FULL reset

			 what_to_reset=RESET_RMV858_CONTROLLER;

			      if (ST600uNet_Reset( motor_addr_mask,what_to_reset, &Error_number)){
                  
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in resetting RMV858... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				  }else MessageBox::Show( "RESET RMV858 HAS BEEN RESETTED ....."," Controller Reset .... ", MessageBoxButtons::OK,MessageBoxIcon::Exclamation); 


		 }
private: System::Void button6_Click_6(System::Object^  sender, System::EventArgs^  e) {//  Change system Gain

              String ^ str;  
			
              unsigned short int  Error_number=0;
              unsigned short int new_system_gain;
              unsigned short int  actual_gain;
			
              unsigned char set_or_read_sytem_gain=WRITE_SYSTEM_GAIN  ;

			      new_system_gain = System::Convert::ToInt16(KFlagsT->Text);
                  KFlagsT->Text ="";
			      if (ST600uNet_Change_SystemGAIN(motor_addr_mask, set_or_read_sytem_gain, new_system_gain,&actual_gain, & Error_number)){
                  
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in Changing System Gain.. ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				  }else{ 
					  str = System::Convert::ToString(actual_gain);                            
					  KFlagsT->Text = str;
				  }


		 }
private: System::Void ErrorClear_Click(System::Object^  sender, System::EventArgs^  e) { // Clear Error Flags
            String ^ str;  
			
              unsigned short int  Error_number=0;
              
            
			      if (ST600uNet_Reset_RMV858_Internal_Errors(motor_addr_mask,& Error_number)){
                  
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in Changing System Gain.. ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				  }
		 }
private: System::Void Jog_Click_2(System::Object^  sender, System::EventArgs^  e) {// JOG Function 
String ^ str;  
			
              unsigned short int  Error_number=0;
              static unsigned short int bytes_available=0;
              short int Speed ;
               
			  if (!SpeedCtrl1->Checked) MessageBox::Show( "Error in JOG Function" ," Speed Control Motion needs to be Enabled first.... ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
		 
				 if (Speed1->Value !=0) {
                    Speed= ( short int) Speed1->Value;
                    
				 }		  
				 else {
					 MessageBox::Show( "Error in JOG Function" ," JOG Speed is Zero .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
				 }


			      if (ST600uNet_MotorJOG( motor_addr_mask,  Speed, &bytes_available ,&Error_number)){
                  
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in Changing System Gain.. ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				  }

		 }
private: System::Void RdReport_Click(System::Object^  sender, System::EventArgs^  e) {// Read A Compleated Report 


               String ^ str;
               unsigned short int Error_number=0;
               long step_counter=0;  
               unsigned short int motor_internal_flags_1;
			   unsigned short int motor_internal_flags_2;
			   unsigned short int over_current_counter;
			   unsigned short int over_temperature_counter;
                 timer4->Enabled=false;         //Disable Timer4 just in case

			 if (ST600uNet_Get_StepsCounter_MotorF_Report( motor_addr_mask,&motor_internal_flags_1,&motor_internal_flags_2, &step_counter ,
				                  &over_current_counter, &over_temperature_counter,&Error_number))
			 {
				  
	              ST600uNet_GetError(Error);
				  str =  marshal_as<String^>(Error);     
				  MessageBox::Show( str,"Error in Reading Report  ", MessageBoxButtons::OK,MessageBoxIcon::Hand);           
			 }else {
                   // Add here all events will STOP the timer
				 if ((motor_internal_flags_1 & MOTION_COMPLEATED) /*|| (motor_internal_flags_1 & MOTOR_STOPPED) */){
					  MCompleated->Checked =true;
					  timer4->Enabled=false;
				 } else MCompleated->Checked = false;
                 if ( motor_internal_flags_2 &CHOPPER_OVER_CURRENT_UNDERVOLT)  // Over Current FAULT Flag
					 Fault_F->Checked = true;
				 else Fault_F->Checked = false;
                     if ( motor_internal_flags_2 &CHOPPER_OVER_TEMPERATURE)  // Over Current FAULT Flag
					 OTW_F->Checked = true;
				 else OTW_F->Checked = false;
                  
               if ( motor_internal_flags_2 &LSW_RIGHT)  // Over Current FAULT Flag
					  LSW_Right->Checked = true;
				 else LSW_Right->Checked = false;
                     if ( motor_internal_flags_2 &LSW_LEFT)  // Over Current FAULT Flag
					  LSW_Left->Checked = true;
				 else  LSW_Left->Checked = false;
              


				 StepRegister->Text= System::Convert::ToString(step_counter);
				 Error_Counter->Text = "F:" + System::Convert::ToString(over_current_counter)+"--T:" + System::Convert::ToString(over_temperature_counter);
			 }



		 }
private: System::Void SeekH_ccw_Click(System::Object^  sender, System::EventArgs^  e) {// SEEK Home CCW


               String ^ str;
               unsigned short int Error_number=0;
               

                timer4->Enabled=false;         //Disable Timer4 just in case		
				timer5->Enabled= false;
				if (SpeedCtrl1->Checked ==false){
                  MessageBox::Show( "Speed Control Flag needs to be Enabled First...." ,"Error in Seeking Home....  ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
			      return ;
				}

				// First we send the command to load direction and speed
			if (ST600uNet_Motor_SEEK_HOME(motor_addr_mask,  -200, &Error_number))
			 { 
	              ST600uNet_GetError(Error);
				  str =  marshal_as<String^>(Error);     
				  MessageBox::Show( str,"Error in Seeking Home....  ", MessageBoxButtons::OK,MessageBoxIcon::Hand);   
				  return;
			 }


                   // We Trigger before we enanble Timer5
			 				 
				 if (FIFOEnable->Checked) Trigger[0] = DIRECT_TRIGGER_ALWAYS;
				 else   Trigger[0]=DIRECT_TRIGGER_ON;
				 
				 
				 if(ST600uNet_MotorTrigger(motor_addr_mask,Trigger[0],& Error_number)){
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in Motor Trigger ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		         }else timer5->Enabled=true;




		 }
private: System::Void SeekH_cw_Click(System::Object^  sender, System::EventArgs^  e) {// SEEK Home CW
             
               String ^ str;
               unsigned short int Error_number=0;
               
             timer4->Enabled=false;         //Disable Timer4 just in case		
			 timer5->Enabled= false; 
			 if (SpeedCtrl1->Checked==false){
             MessageBox::Show( "Speed Control Flag needs to be Enabled First...." ,"Error in Seeking Home....  ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
             return ;
			 }
			 if (ST600uNet_Motor_SEEK_HOME(motor_addr_mask,  200, &Error_number))
			 { 
	              ST600uNet_GetError(Error);
				  str =  marshal_as<String^>(Error);     
				  MessageBox::Show( str,"Error in Seeking Home....  ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
				  return;
			 } 


                // We Trigger before we enanble Timer5
			 				 
				 if (FIFOEnable->Checked) Trigger[0] = DIRECT_TRIGGER_ALWAYS;
				 else   Trigger[0]=DIRECT_TRIGGER_ON;
				 
				 
				 if(ST600uNet_MotorTrigger(motor_addr_mask,Trigger[0],& Error_number)){
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in Motor Trigger ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		         }else timer5->Enabled=true;




		 }
private: System::Void timer5_Tick(System::Object^  sender, System::EventArgs^  e) { // Timer 5
		  
			   String ^ str;
               unsigned short int Error_number;
               long step_counter=0;  
               unsigned short int motor_internal_flags_1;
			   unsigned short int motor_internal_flags_2;
			   unsigned short int over_current_counter;
			   unsigned short int over_temperature_counter;

			 if (ST600uNet_Get_StepsCounter_MotorF_Report( motor_addr_mask,&motor_internal_flags_1,&motor_internal_flags_2, &step_counter ,
				                  &over_current_counter, &over_temperature_counter,&Error_number))
			 {
				  timer5->Enabled=false; 
	              ST600uNet_GetError(Error);
				  str =  marshal_as<String^>(Error);     
				  MessageBox::Show( str,"Error in Timer Step Counter Read ", MessageBoxButtons::OK,MessageBoxIcon::Hand);           
			 }else {
                   // Add here all events will STOP the timer
				 if ((motor_internal_flags_1 & MOTION_COMPLEATED) /*|| (motor_internal_flags_1 & MOTOR_STOPPED) */){
					  MCompleated->Checked =true;
					  timer5->Enabled=false;
				 } else MCompleated->Checked = false;

                  if ((motor_internal_flags_1 & AT_HOME) /*|| (motor_internal_flags_1 & MOTOR_STOPPED) */){
					 Athome->Checked =true;
					  timer5->Enabled=false;
				 } else Athome->Checked = false;

				  if ( motor_internal_flags_2 &CHOPPER_OVER_CURRENT_UNDERVOLT) { // Over Current FAULT Flag
					 Fault_F->Checked = true;
                     timer5->Enabled=false;			
				  }else Fault_F->Checked = false;
				  if ( motor_internal_flags_2 &CHOPPER_OVER_TEMPERATURE) { // Over Current FAULT Flag
					 OTW_F->Checked = true;
				     timer5->Enabled=false;
				  }else OTW_F->Checked = false;
                  
				 if ( motor_internal_flags_1 &LSW_RIGHT){  // Over Current FAULT Flag
					  LSW_Right->Checked = true;
					  SW_Right->Checked = true;
				      timer5->Enabled=false;
				 }else{
					 LSW_Right->Checked = false;
                      SW_Right->Checked = false;
				      
				 }
				 if ( motor_internal_flags_1 &LSW_LEFT) { // Over Current FAULT Flag
					     LSW_Left->Checked = true;
				        timer5->Enabled=false;
						SW_Right->Enabled =true;
				 }else  { 
					       LSW_Left->Checked = false;
                           SW_Right->Enabled =false;
				 }

				 Password->Text= System::Convert::ToString(step_counter);
				 Status->Text = "F:" + System::Convert::ToString(over_current_counter)+"--T:" + System::Convert::ToString(over_temperature_counter);
			 }
		 
		 
		 
		 }
private: System::Void LimitSW_CCW_Click(System::Object^  sender, System::EventArgs^  e) {//Move CCW or CW from Limit switch 


			   String ^ str;
               String  ^str1;
			   unsigned short int Error_number=0;
			   short int number_of_steps =0;
               unsigned short int kernel_error=0;
               unsigned short int  last_command=0;

             timer4->Enabled=false;         //Disable Timer4 just in case		
			 timer5->Enabled= false;

       
			 number_of_steps = System::Convert::ToInt16(NumSteppRL_SW->Text);

			 
			 if (TrapeCtrl1->Checked==false){
             MessageBox::Show( " -Trapeziodal Control Flag- needs to be Enabled First before calling this function...." ,"Error in Moving axis from Limit Switch ....  ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
             return ;
			 }


			 if (number_of_steps==0){
             MessageBox::Show( " Limit Switch Function Step number can not be Zero....." ,"Error in Moving axis from Limit Switch .... ", MessageBoxButtons::OK,MessageBoxIcon::Hand); 
             return ;
			 }


           
			 if (ST600uNet_Motor_Move_From_Limit_SW(motor_addr_mask,  number_of_steps, & Error_number))
			 { 
	              ST600uNet_GetError(Error);
				  str =  marshal_as<String^>(Error); 
				  ST600uNet_Get_RMV858_Kernel_LastError(motor_addr_mask, &kernel_error, & last_command, & Error_number );
				  str1=  "Internal Kernel Error: "+ System::Convert::ToString(kernel_error)+ " Last Command: " + System::Convert::ToString(last_command);
				  MessageBox::Show( str,str1/*"Error in Moving axis from Limit Switch ...  "*/, MessageBoxButtons::OK,MessageBoxIcon::Hand);    
				  return;
			 } else timer5->Enabled=true;
             
/*
                // We Trigger before we enanble Timer5
			 				 
				 if (FIFOEnable->Checked) Trigger[0] = DIRECT_TRIGGER_ALWAYS;
				 else   Trigger[0]=DIRECT_TRIGGER_ON;
				 
				 
				 if(ST600uNet_MotorTrigger(motor_addr_mask,Trigger[0],& Error_number)){
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in Motor Trigger ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
		         }else timer5->Enabled=true;
*/
             

		 }
private: System::Void SW_Right_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 
			  if ((SW_Right->Checked) == true)
                timer5->Enabled =true;
               
			  if ((SW_Right->Checked) == false)
                timer5->Enabled =false;
		 }
private: System::Void SW_Left_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {

			 if ((SW_Left->Checked) == true)
                timer5->Enabled =true;
               
			  if ((SW_Left->Checked) == false)
                timer5->Enabled =false;
		 }
private: System::Void ReadRp_Click(System::Object^  sender, System::EventArgs^  e) { //Read Report in Move axis from SWL

			 
			   String ^ str;
               unsigned short int Error_number=0;
			   unsigned short int motor_internal_flags_1;
			   unsigned short int motor_internal_flags_2;
			   unsigned short int over_current_counter;
			   unsigned short int over_temperature_counter;
               long step_counter=0;

             
			   timer4->Enabled=false;         //Disable Timer4 just in case		
   			   timer5->Enabled= false;


               if (ST600uNet_Get_StepsCounter_MotorF_Report( motor_addr_mask,&motor_internal_flags_1,&motor_internal_flags_2, &step_counter ,
				                  &over_current_counter, &over_temperature_counter,&Error_number))
			 {
				  timer5->Enabled=false; 
	              ST600uNet_GetError(Error);
				  str =  marshal_as<String^>(Error);     
				  MessageBox::Show( str,"Error in Timer Step Counter Read ", MessageBoxButtons::OK,MessageBoxIcon::Hand);           
			 }else {
                   // Add here all events will STOP the timer
				 if ((motor_internal_flags_1 & MOTION_COMPLEATED) /*|| (motor_internal_flags_1 & MOTOR_STOPPED) */){
					  MCompleated->Checked =true;
					  
				 } else MCompleated->Checked = false;

                  if ((motor_internal_flags_1 & AT_HOME) /*|| (motor_internal_flags_1 & MOTOR_STOPPED) */){
					 Athome->Checked =true;
					  
				 } else Athome->Checked = false;

				  if ( motor_internal_flags_2 &CHOPPER_OVER_CURRENT_UNDERVOLT) { // Over Current FAULT Flag
					 Fault_F->Checked = true;
                     	
				  }else Fault_F->Checked = false;
				  if ( motor_internal_flags_2 &CHOPPER_OVER_TEMPERATURE) { // Over Current FAULT Flag
					 OTW_F->Checked = true;
				    
				  }else OTW_F->Checked = false;
                  
				 if ( motor_internal_flags_1 &LSW_RIGHT){  // Over Current FAULT Flag
					  LSW_Right->Checked = true;
					  SW_Right->Checked = true;
				     
				 }else{
					 LSW_Right->Checked = false;
					 SW_Right->Checked = false;
				 }
				 if ( motor_internal_flags_1 &LSW_LEFT) { // Over Current FAULT Flag
					    LSW_Left->Checked = true;     
						SW_Left->Checked=true;
				 }else {
					     LSW_Left->Checked = false;
                         SW_Left->Checked  = false;
				 }
				 if ((!SW_Right->Checked) && (!LSW_Left->Checked)){
					 MessageBox::Show( "The axis is Not at any Limit Switch..... "," The axis can be moved normally ......  ", MessageBoxButtons::OK,MessageBoxIcon::Information);   
					 return;
				 }
			}




		 }
private: System::Void label34_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void AdjustMiddle_Click(System::Object^  sender, System::EventArgs^  e) {// ADjust Chopper Driver to Middle Point 
			 String ^ str;
			 unsigned short int adjust_by_zero_or_max=ADJUST_CURRENT_BY_MIDDLE ;
		     unsigned short int max_current=(unsigned short int) max_current=(unsigned short int) System::Convert::ToInt16 (MCurrt1->Text);
		     unsigned short int Error_number=0;
			 progressBar1->Value =0;		  
		  
         
           if (ST600uNet_Adjust_Current(motor_addr_mask, adjust_by_zero_or_max, max_current,&Error_number))
            {
		      ST600uNet_GetError(Error);
		       str =  marshal_as<String^>(Error);     
		     MessageBox::Show( str,"Error in Adjusting driver to a maximum ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
		   }else{  
                MessageBox::Show( "Adjusting driver to maximum motor power ...","Adjusting chopper driver current ...", MessageBoxButtons::OK,MessageBoxIcon::Exclamation);  
			   timer2->Enabled= true;
			   AdjustMAX->Enabled= true;
		   }



		 }
private: System::Void ProfTrapCtrl1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {// Profile Trapeziodal Motion 

			  if (ProfTrapCtrl1->Checked )
					{
                        TrapeziodalPrameters ^ form = gcnew TrapeziodalPrameters ;
                       form->ShowDialog();
					}
		 }
private: System::Void ReadAnalog_Click(System::Object^  sender, System::EventArgs^  e) {// Read analog channels 

             String ^ str;
			 float adc_channel =0.00;
		     unsigned short int Error_number=0;
			 progressBar1->Value =0;		  
		   ATemp->Text="";
		   A4_20mA->Text="";
		   A5V->Text="";
         if (ST600uNet_Analog_Input(motor_addr_mask,& adc_channel, & Error_number))
            {
		      ST600uNet_GetError(Error);
		       str =  marshal_as<String^>(Error);     
		       MessageBox::Show( str,"Error in reading ADC channel ... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);    
		     
		   }else{  
			   if (motor_addr_mask ==2){  
				   str =  System::Convert::ToString(adc_channel) ;    
				   str += "  �C"; 
				   ATemp->Text= str;
			   }else if (motor_addr_mask ==4){
                   str =  System::Convert::ToString(adc_channel) ;            			  
				   A4_20mA->Text= str;

			   }else if (motor_addr_mask ==8){
                   str =  System::Convert::ToString(adc_channel) ;            			  
				   A5V->Text= str;
            
			   }
               
		 }


		 }
private: System::Void ResetCounters_Click(System::Object^  sender, System::EventArgs^  e) {

			    String ^ str;  
			    unsigned short int what_to_reset;
                unsigned short int  Error_number=0;

			 // We have a FULL reset

			   what_to_reset=RESET_MOTION_REGISTERS ;

			      if (ST600uNet_Reset( motor_addr_mask,what_to_reset, &Error_number)){
                  
		   	              ST600uNet_GetError(Error);
					      str =  marshal_as<String^>(Error);     
					      MessageBox::Show( str,"Error in resetting internal registers from RMV858... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);               
				  }else MessageBox::Show( "RESET RMV858 INTERNAL COUNTERS-REGISTERSHAS BEEN INITIALIZED ....."," Controller Reset .... ", MessageBoxButtons::OK,MessageBoxIcon::Exclamation); 

		 }
};//END


