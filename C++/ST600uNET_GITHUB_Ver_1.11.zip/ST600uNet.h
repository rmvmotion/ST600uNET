


/////////////////////////////////////////////////////////////////////////////
//                    RMV Motion Inc. 
//                    ST600uNEt.h
//                    St600uNET.dll version 11.65
//                    Author: Albert Tello
/////////////////////////////////////////////////////////////////////////////




#ifndef ST600UNET_H
#define ST600UNET_H

#include "windows.h"
#include "string.h"
#include <iostream>
//using namespace std;

// Version: 11.65
#define ST600_VERSION_MAJOR				0x11
#define ST600_VERSION_MINOR				0x65

typedef unsigned char BYTE;
//typedef unsigned int WORD;
typedef unsigned long DWORD;

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with theST600NT_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// ST600UNET_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.


#ifdef  ST600UNET_EXPORTS //                       ST600NT_EXPORTS
#define HID_TO_SMBUS_API __declspec(dllexport)
#else
#define HID_TO_SMBUS_API __declspec(dllimport)
#endif //ST600NT_EXPORTS



#ifdef  _BUILD_DLL //                       ST600NT_EXPORTS
 #define ST600UNET_API __declspec(dllexport)
#else
#define ST600UNET_API __declspec(dllimport)
#endif //BUILD_DLL




//////////////////////////////////////////////////////////////////////////
//       RMV858 Commands Definitions
//////////////////////////////////////////////////////////////////////////
//#define SPEED                 'M'     // 0x49 Speed control 
#define TRIGGER               'T'     // Motor Trigger
#define MOTION_CONFIG_CMPLT   'C'     // Motion Config : Set all inetrnal parmeters fpor    
#define SET_STEP_RESOLUTION   'R'     // 0x52 Chan step size 
#define MOTION_STOP           'P'     // 0x53 Motion Stop , :  Stop  present motion  
#define MOTOR_SET_PARAMETERS  'Z'     // 0x5A    // Set Motor paramteters
#define MOTION_OPERATING_MODE 'O'     // 0x4F    // Set operatinmg Mode can be sent when motor is running 
// ------------Step Numbers
#define SET_NUMBER_OF_STEPS             'N'     // Set the number of steps  
#define STEPS_FROM_SLEW_TO_DECEL        'n'    // Set number of SLEW_RATE steps, before Decel begin  
//------------------------------               
#define ACCELERATION          'A'     // Acceleration
#define DECELERATION          'D'     // Deceleration
//#define SAMPLING_RATE         'G'     // Set Sampling Rate when at rate need to chage speed or possition   
#define MOTION_DELAY          'Y'     // Delay in mSec or uSec (software selection) 1 to 65535 mSec or uSec
#define MOTION_MOVE_STEPS     'G'     // Move trapeziodal number of steps, speed, ACCEL, DECEL     

#define MOTOR_JOG           'J'      // Motor JOG 

     

// Double byte commands
#define SPEED_RATE            'SR'      // Change motor Speed or Slew Rate  
#define SPEED_INITIAL         'SI'     // Initial Speed 
#define SPEED_FINAL           'SF'     // Final speed in linked motion

//-------Holding Torque-----------------------------------------
#define HOLDING_TORQUE1    'H1'    // Full Holding torque 
#define HOLDING_TORQUE2    'H2'    // 25% Holding torque
#define HOLDING_TORQUE3    'H3'    // 50% Holding torque
#define HOLDING_TORQUE4    'H4'    // 75% Holding torque
//--------------------------------------------------------------

//-------------------IO's----------------------  
#define IO_DIGITAL_READ_WRITE       'ID'            
#define IO_ANALOG_READ               'IA' 
//---------------------------------------------
/*
------DIGITAL ---------------
 Motor Address 0: INPUT_0
                  OUTPUT_0 
                  OUTPUT_1    

Motor Address 1:  INPUT_1
                  OUTPUT_2 
                  OUTPUT_3

Motor Address 2:  INPUT_2
                  OUTPUT_4 

Motor Address 3:  INPUT_3
                  OUTPUT_5 

 -----ANALOG INPUTS---------
 Motor Address 1 : TEMPERATURE         
 Motor Address 2 : 4-20 mA
 Motor Address 3 : 0-5V

*/
//--------------End IO's ----------------------
//-----Sequential Motion ----------------------
#define SEQUENTIAL_MOTION_CONTROL_INIT          'BI'      // Initialize Sequential Motion: Seletect contollers involved , Pivot controller   
                                                          //
                                                          // 'BI' command wil be accepted only when Motor is Not running, the Sequential Mask Register will be initialized to "0" 
 
#define SEQUENTIAL_MOTION_CONTROL_SET_INT_MASK  'BM'      // Set a new motion Compelted Mask , this command will be accepted when motor is running               
                                                         // No Controllers can be Enabled or Disabled.
#define DISABLE_SEQUENTIAL_MOTION_CONTROL      'BD'     // Disable SEQUENTIAL Motion Trigger for the address which the command is sent. 


/*  
        
       Motor Running          : "0" Activated by Zero
	   Motot Motion Completd  : "1" Activated bye One

 
      ADDR0 TABLE: bit 0: Motion completed ADDR0,  Always Enable in SEQ Motion Trigger
	               bit 1: Motion completed ADDR1,   "1" select the address "0" Deselect"
				   bit 2: Motion completed ADDR2
				   bit 3: Motion completed ADDR3
              
      ADDR1 TABLE: bit 0: Motion completed ADDR1,  Always Enable in SEQ Motion Trigger
	               bit 1: Motion completed ADDR0,   "1" select the address "0" Deselect"
				   bit 2: Motion completed ADDR2,
				   bit 3: Motion completed ADDR3   
     
	  ADDR2 TABLE: bit 0: Motion completed ADDR2, Always Enable in SEQ Motion Trigger
	               bit 1: Motion completed ADDR0,  "1" select the address "0" Deselect"
				   bit 2: Motion completed ADDR1,
				   bit 3: Motion completed ADDR3

      ADDR3 TABLE: bit 0: Motion completed ADDR3, Always Enable in SEQ Motion Trigger
	               bit 1: Motion completed ADDR0, "1" select the address "0" Deselect"
				   bit 2: Motion completed ADDR1,
				   bit 3: Motion completed ADDR2   
For exmaple  Motor Address 0
                   ADDR3,ADDR2,ADDR1, ADDR0
   Enable            1    0      1      1 ( Due to we are setting SEQ Mot for ADDR0 always is enabled)
                         ADDR2 always will be checked as 0, due t ois not enabled
   MASK              1    0      0      1        ( this combination will trigger Motor ADDR0 ) 
                                Motor ADDR1 needs to be running in order to have "0", 
								ADDR0 and ADDR3 motion need to be compleated.   
   
   */



//////////////////////////////////////////////////////////////////////////
//      FIFO Defines
//////////////////////////////////////////////////////////////////////////
//------- FIFO Sub-Commands

#define FIFO_MAX_SIZE_ONE_TIME    28     // Maximum data words lenght to be sent in one call  
#define FIFO_MAX_BUFFER_LENGHT    700     // Maximum FIFO Buffer capacity in words   

#define FIFO_READ_FROM_TO         'FR'      // FIFO  Read Data from ADDR to ADDR 
#define FIFO_DELETE_CONTENTS      'FD'     // FIFO  Delete buffer tail and head 
#define FIFO_GET_SPACE_AVAILABLE  'FS'     // Get FIFO FREE space    

#define FIFO_PROFILE_TRAPEZOIDAL_CONTROL   'FT'     
                          // MANDATORY COMMANDS:              
                                           //  Command : 'N'        2 bytes
                                            // Total Steps Number:  4 bytes (signed)
                                            //  Command : 'A'       2 bytes           
                                            // Accel :              2 bytes
                                            // Command : 'D'        2 bytes
                                            // Decel :              2 bytes
                                            // Command  'SR'        2 bytes 
                                            // Slew Rate:           2 bytes                                          
                                            //                    ____________
                                          // Total               18 bytes; 9 = words

                       // NONE MANDATORY COMMANDS: 
                       /*   MOTION_TABLE_DELAY 'Y' :   2 bytes       ; wait between 1 to 65535 msec
                                          Delay        2 bytes  
                            

					   */
#define TRAPEZOIDAL_ONE_SET_WORD     9    // 18      
#define TRAPEZOIDAL_CONTROL_MAX_ITERATIONS    3            // Numbers of motions per time to RMV858 FIFO                                        

//--------   
#define FIFO_BUFFER_PROFILE_LINKED 'FT'   // Step Number:   2 bytes
                                          // Initial Speed: 2 bytes  
                                          // Accel :        2 bytes
                                          // Decel :        2 bytes
                                          // Final Speed:    2 bytes



#define FIFO_BUFFER_TABLED_PROFILE 'FQ'   //   

#define FIFO_BUFFER_POSITION_CONTROL 'FP'

#define FIFO_SCURVE_CONTROL          'FC'

#define FIFO_PROFILE_SPEED_CONTROL     'FE'   // Set Profile Speed control  
                                              // Command  'SR' (unsigned)      2 bytes  ; 'SR'
                                              // Slew Rate:  (unsigned)        2 bytes  ; SR=1000 
                                              // Command  'A'                  2 bytes  ; 'A'
                                              // Acceleration                  2 bytes  ; A=10000 
                                              // Command  'n'                  2 byes   ; 'n' 
                                              // Number os Steps (signed)      4 bytes  ; n=18500 CW(+), CCW(-)
                                              //                              _________   
                                              //  TOTAL                       14 bytes  = 7 words
                                              //
#define SPEED_CONTROL_ONE_SET_WORD      7             
#define SPEED_CONTROL_MAX_ITERATIONS    4             // Numbers of motions per time to RMV858 FIFO                                        
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
//-----------------------------
#define TRIGGER             'T'      // Motor Trigger
#define MOTION_CONFIG_CMPLT 'C'      // Motion Config : Set all inetrnal parmeters fpor         
#define MOTOR_PARAMETERS    'Z'      // Set Motor paramteters
#define SEEK_HOME           'M'      // Seek home switch , if Speed is pos move CW, otherwise CCW 

// ----------Limit Switch functions ----------------------------------
#define LIMIT_SWITCH        'WM'     // Move the axis from a Limit Switch certain steps


//-------------------------------------------------
//////////////////////////////////////////////////
#define  STEP_NUM_POSITION_CNTRL          'NP'      //Set step numbers in position control mode
//#define  STEP_NUM_TRAPEZIODAL_CNTRL       'NT'      //Set step numbers in Trapeziodal contorl mode

//////////////RESET COMMANDS//////////////////////////////////

#define RESET_MOTION_REGISTERS          'QR'          // Reset All mpotion paramameters : Buffer , ACCEL, DECEL, Step Numbers, Slew Rate, and Motor Flags
#define RESET_RMV858_CONTROLLER         'QF'          // FULL Reset CONTROLLER     

//#define RMV858_KERNEL_ERROR_LAST            'ER'            // GET the last Error from last command sent to RMV858 Controller, 
#define RMV858_KERNEL_ERROR_CHOPPER         'EH'            // GET the Error from the current driver and the number faulted, and find is 
                                                            // RMV858 Kernel is in a state= STATE_ERROR
#define RMV858_KERNEL_CLEAR_INTERNAL_ERROR  'EC'            // Clear All Internal Errors and I nitialize the Kernel 

//////////////////////////////////////////////////////////////////////////
//       RMV858 Commands Extended 
////////////////////////////////////////////////////////////////////////////
 
#define READ_MOTOR_PARAMETERS               0x80      // Read Munufacturer Motor parametrs   

#define SAVE_INTERNAL_PARAMETERS_TO_FLASH      0x81      
#define SAVE_MOTOR_PARAMETERS_TO_FLASH         1     // Save all motor inetrnal parameters (winding resistance, inductace, system power, winding resistance, etc._)       
#define SAVE_CURRENT_PARAMETERS_TO_FLASH       2      // Save motor Current Control parameters    


#define ADJUST_MIN_MAX_CHOPPER_CURRENT      0x83      //  
#define ADJUST_CURRENT_BY_ZERO               1
#define ADJUST_CURRENT_BY_MAXIMUM            2
#define ADJUST_CURRENT_BY_MIDDLE             3


//////////////////////////////////////////////////////////////////////////
//          Changing system gian command
/////////////////////////////////////////////////////////////////////////
#define ADJUST_SYSTEM_GAIN                   0x86
#define READ_SYSTEM_GAIN                     1
#define WRITE_SYSTEM_GAIN                    2

//////////////////////////////////////////////////////////////////////////
//          Reports Request command
/////////////////////////////////////////////////////////////////////////
#define GET_INTERNAL_REPORT                   0x84             // Command Read internal reports
#define CHOPPER_DRIVER_CURRENT_REPORT          1               // Report request for all motor current driver parameters 
//---- Chopper driver Report flags---------------
//#define CURRENT_PARAMETERS_SAVED            1
//#define DRIVER_ZERO_CURRENT_ADJUSTED        2
//#define DRIVER_MAX_CURRENT_ADJUSTED         4
//#define CHOPER_DRIVER_ERROR                 8

 // -------Motor internal  FLAGS  I  ---------------------

 
 

 #define   DIGITAL_INPUT_REPORT            0x0001          //Digital Input
 #define   MOTOR_RUNNING                   0x0002          //Motor is running
 #define   MOTION_COMPLEATED               0x0004          //Motor Motion has been fininalizaded 
 #define   MOTOR_STOPPED                   0x0008          // STOP Command was sent to RMV858 Controller
 #define   LSW_RIGHT	                   0x0010         // Limit Switch Right Input  Process INT Real time
 #define   LSW_LEFT	                       0x0020         // Limit Switch Left Input   Process INT Real time
 #define   HARDWARE_STOP 	               0x0040         // HARDWARE STOP 
 #define   AT_HOME 	                       0x0080         // HOME switch
 #define   EXT_TRIGGER                     0x0100         // Extern Trigger done an external Switch
 #define   RMV_TASKER_TRIGGER 	           0x0200         // TRIGGER By RMV_Tasker OS Module




//-------Motor internal  FLAGS  II  -------------------
  #define   CURRENT_PARAMETERS_SAVED        0x0001                     // Paramters Saved
  #define   DRIVER_ZERO_CURRENT_ADJUSTED    0x0002                    //Zero volatge calibration has been done
  #define   DRIVER_MAX_CURRENT_ADJUSTED     0x0004                    //MAximum Current calibration has been done
  #define   MOTOR_PARAM_SAVED               0x0008
  #define   CHOPER_DRIVER_CAN_NOT_SET_MAX_MIN             0x0010     // Set when the current coulnot be adjusted and the coubter expaired
  #define   CHOPPER_OVER_TEMPERATURE        0x0020                    //Over Temperature Flag
  #define   CHOPPER_OVER_CURRENT_UNDERVOLT  0x0040                    // Over Current FAULT Flag
  #define   DRIVER_HALF_CURRENT_ADJUSTED    0x0080                   


//----End chopper driver report------------

//-----Motor Counter and Motor Internal Report------
#define GET_STEPS_COUNTER_MFLAGS          0x85

/////////End MFLAGS and Counter Report--------------

/////////////////////////////////////////////////////////////////////////
//            Boot loader Firmware Upgrade
/////////////////////////////////////////////////////////////////////////
#define ENTER_BOOTLAODER_MODE                0xA0             //Invoque the boot loader code

//////////////////////////////////////////////////////////////////////////
//      Motion Control Mode
//////////////////////////////////////////////////////////////////////////
#define    SPEED_CONTROL                       1
#define    POSITION_CONTROL                    2
#define    PROFILE_SPEED_CONTROL               3                   
#define    S_CURVE_CONTROL                     4
#define    TRAPEZOIDAL_CONTROL                 5
#define    PROFILE_TRAPEZOIDAL_CONTROL         6   


#define MAX_ACCELERATION      (unsigned int )20000
#define MAX_DECELERATION      (unsigned int )20000 
#define MAX_SPEED             (unsigned int )25000 


//////////////////////////////////////////////////////////////////////////
//      STOP Parameters
//////////////////////////////////////////////////////////////////////////
#define STOP_MOTOR_ONLY            1
#define STOP_MOTOR_RESET_CMDS      2
#define STOP_MOTOR_RESET_FIFO      3 


//////////////////////////////////////////////////////////////////////////
//      SPEED CONTROL  Parameters
//////////////////////////////////////////////////////////////////////////
#define SAMPLING_RATE_TWO_MSEC       2
#define SAMPLING_RATE_ONE_MSEC       1
#define SAMPLING_RATE_FIVE_MSEC      5



//////////////////////////////////////////////////////////////////////////
//       SPEED     ACCELERATION DECELERATION  Parameters
//////////////////////////////////////////////////////////////////////////
#define MAXIMUM_ACCEL        20000
#define MAXIMUM_DECEL        20000
#define MINIMUM_ACCEL_DECEL   1             
//--------------------------------Motion defines 
#define MAXIMUM_SPEED           20000
#define MINIMUM_SPEED            2

#define LSW_MAX_STEPS            1000
#define LSW_MIN_STEPS             1

//////////////////////////////////////////////////////////////////////////
//            END FIFO DEFINITIONS 
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//      Motor Operation Mode
//////////////////////////////////////////////////////////////////////////
#define    FIXED_VOLATAGE          0
#define    FIXED_CURRENT           1
#define    CLOSED_LOOP             3

//////////////////////////////////////////////////////////////////////////
//      Step Size Resolution 
//////////////////////////////////////////////////////////////////////////
 #define ST_FULLSTEP             0               //possible values for stepSize variable
 #define ST_HALFSTEP             1
 #define ST_1_4STEP              2
 #define ST_1_8STEP              3
 #define ST_1_16STEP             4
 #define ST_1_32STEP             5
 #define ST_1_64STEP             6
 #define ST_1_128STEP            7
 #define ST_1_256STEP            8

///////////////////////////////////////////////////////////////////////////////
//             Table for Events: Motion Completed, Delay_motion,  Position Compare 
///////////////////////////////////////////////////////////////////////////////
#define MOTION_COMPLT0      0x0001         //Set Pulse Event to address 0 when Motion is compelted         
#define MOTION_COMPLT1      0x0002         //Set Pulse Event to address 0 when Motion is compelted         
#define MOTION_COMPLT2      0x0004         //Set Pulse Event to address 0 when Motion is compelted         
#define MOTION_COMPLT3      0x0008         //Set Pulse Event to address 0 when Motion is compelted         
#define MOTION_DELAY0       0x0010         //Set Pulse Event to address 0 when Delay is compelted         
#define MOTION_DELAY1       0x0020         //Set Pulse Event to address 0 when Delay is compelted         
#define MOTION_DELAY2       0x0040         //Set Pulse Event to address 0 when Delay is compelted         
#define MOTION_DELAY3       0x0080         //Set Pulse Event to address 0 when Delay is compelted         


#define MAX_STEP_RESOLUTION     ST_1_256STEP      //minimum step size
 
#define MAX_STEP_ANGLE       5                 //:1.8 , 0.9, 1.2, 0.72, 0.36       
//////////////////////////////////////////////////////////////////////////
//      RMV858 KERNEL CONFIGURATION FLAGS 
//////////////////////////////////////////////////////////////////////////
#define UNIPOLAR_BIPOLAR     1      // "1" Motor running as bipolar
                                    // "0" Motor running as unipolar 
//////////////////////////////////////////////////////////////////////////
//------------------------Buffer Motion--------------
#define     MAX_BUFFER_SIZE_SPPOS_CNTRL            10
////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////
//      Different TRIGGERS
//////////////////////////////////////////////////////////////////////////
#define DIRECT_TRIGGER_ON      1
#define DIRECT_TRIGGER_OFF     0
#define SEQ_TRIGGER_ON         2
#define SEQ_TRIGGER_OFF        3
#define DIRECT_TRIGGER_ALWAYS  4


////////////////////////////////////////////////////////////////////////
//            Delay Motion 
///////////////////////////////////////////////////////////////////////
#define  DELAY_IN_MSEC             1
#define  DELAY_IN_USEC             2

/////////////////////////////////////////////////////////////////////////////
// Return Code Definitions
/////////////////////////////////////////////////////////////////////////////

// ST600_MBUS_STATUS
typedef int ST600_STATUS;

// ST600_MBUS_STATUS Return Codes
#define ST600_MBUS_SUCCESS							    0x00
#define	ST600_MBUS_DEVICE_NOT_FOUND					    0x01
#define ST600_MBUS_INVALID_HANDLE					    0x02
#define	ST600_MBUS_INVALID_DEVICE_OBJECT				0x03
#define	ST600_MBUS_INVALID_PARAMETER					0x04
#define	ST600_MBUS_INVALID_REQUEST_LENGTH			    0x05

#define	ST600_MBUS_READ_ERROR						0x10
#define	ST600_MBUS_WRITE_ERROR						0x11
#define	ST600_MBUS_READ_TIMED_OUT					0x12
#define	ST600_MBUS_WRITE_TIMED_OUT					0x13
#define	ST600_MBUS_DEVICE_IO_FAILED					0x14
#define ST600_MBUS_DEVICE_ACCESS_ERROR				0x15
#define ST600_MBUS_DEVICE_NOT_SUPPORTED				0x16

#define ST600_MBUS_UNKNOWN_ERROR						0xFF

// ST600_MBUS_TRANSFER_S0
typedef BYTE ST600_MBUS_S0;

#define ST600_MBUS_S0_IDLE							0x00
#define ST600_MBUS_S0_BUSY							0x01
#define ST600_MBUS_S0_COMPLETE						0x02
#define ST600_MBUS_S0_ERROR							0x03

// ST600_MBUS_TRANSFER_S1
typedef BYTE ST600_MBUS_S1;

// ST600_MBUS_TRANSFER_S0 = ST600_MBUS_S0_BUSY
#define ST600_MBUS_S1_BUSY_ADDRESS_ACKED				0x00
#define ST600_MBUS_S1_BUSY_ADDRESS_NACKED			0x01
#define ST600_MBUS_S1_BUSY_READING					0x02
#define ST600_MBUS_S1_BUSY_WRITING					0x03

// ST600_MBUS_TRANSFER_S0 = ST600_MBUS_S0_ERROR
#define ST600_MBUS_S1_ERROR_TIMEOUT_NACK				0x00
#define ST600_MBUS_S1_ERROR_TIMEOUT_BUS_NOT_FREE		0x01
#define ST600_MBUS_S1_ERROR_ARB_LOST					0x02
#define ST600_MBUS_S1_ERROR_READ_INCOMPLETE			0x03
#define ST600_MBUS_S1_ERROR_WRITE_INCOMPLETE			0x04
#define ST600_MBUS_S1_ERROR_SUCCESS_AFTER_RETRY		0x05

/// ST600uNet Errors
#define  ST600_MOTOR_POWER                   0x30             
#define  ST600_MOTOR_WINCURR                 0x31   
#define  ST600_MOTOR_STEP_ANGLE              0x32
#define  ST600_MOTOR_SPEED                   0x33  
#define  ST600_MOTOR_FIFO_CMD                0x34
#define  ST600_MOTOR_FIFO_BUF                0x35
#define ST600_FIFO_WRONG_BUFFER_DATA         0x36
#define WRONG_POINTER_AS_PARAMETER           0x37 
#define HEX_FILE_LOADING_FAILED              0x38
#define BOOTLOADER_NEEDS_TO_BE_RUN           0x39
#define NO_COMMAND_ACKNOWLEDGE_RECIVED       0x3A
#define FLASH_MEMORY_WRONG_VERIFICATION      0x3B 
#define WRONG_FUNCTION_PARAMETERS            0x3C  
#define ERROR_SAVING_PARAMETERS_TO_FLASH     0x3D
#define NO_STEPS_TO_MOVE                     0x3E
#define WRONG_SEQUENTIAL_MOTION_PARAMETERS   0x3F
#define WRONG_STEPS_TO_MOVE                  0x40
#define ERROR_IN_ADJUSTING_CHOPPER_CURRENT   0x41
/////////////////////////////////////////////////////////////////////////////
// String Definitions
/////////////////////////////////////////////////////////////////////////////

// Product String Types
#define ST600_MBUS_GET_VID_STR						0x01
#define ST600_MBUS_GET_PID_STR						0x02
#define ST600_MBUS_GET_PATH_STR						0x03
#define ST600_MBUS_GET_SERIAL_STR					0x04
#define ST600_MBUS_GET_MANUFACTURER_STR				0x05
#define ST600_MBUS_GET_PRODUCT_STR					0x06

// String Lengths
#define ST600_MBUS_DEVICE_STRLEN						260

// ST600_MBUS_DEVICE_STR
typedef char ST600_MBUS_DEVICE_STR[ST600_MBUS_DEVICE_STRLEN];





/*

/////////////////////////////////////////////////////////////////////////////
// SMBUS Definitions
/////////////////////////////////////////////////////////////////////////////

// SMbus Configuration Limits
#define ST600_MBUS_MIN_BIT_RATE						1
#define ST600_MBUS_MIN_TIMEOUT						0
#define ST600_MBUS_MAX_TIMEOUT						1000
#define ST600_MBUS_MAX_RETRIES						1000
#define ST600_MBUS_MIN_ADDRESS						0x02
#define ST600_MBUS_MAX_ADDRESS						0xFE

// Read/Write Limits
#define ST600_MBUS_MIN_READ_REQUEST_SIZE				1
#define ST600_MBUS_MAX_READ_REQUEST_SIZE				512
#define ST600_MBUS_MIN_TARGET_ADDRESS_SIZE			1
#define ST600_MBUS_MAX_TARGET_ADDRESS_SIZE			16
#define ST600_MBUS_MAX_READ_RESPONSE_SIZE			61
#define ST600_MBUS_MIN_WRITE_REQUEST_SIZE			1
#define ST600_MBUS_MAX_WRITE_REQUEST_SIZE			61

*/

//--------------------ST600 Motor Address Mask------------------------------------ 
#define MOTOR1_ADDR_MASK        1
#define MOTOR2_ADDR_MASK        2
#define MOTOR3_ADDR_MASK        4
#define MOTOR4_ADDR_MASK        8
#define ALL_MOTOR_ADDR_MASK     0  


/////////////////////////////////////////////////////////////////////////////
// GPIO Definitions
/////////////////////////////////////////////////////////////////////////////

// GPIO Pin Direction Bit Value
#define ST600_MBUS_DIRECTION_INPUT					0
#define ST600_MBUS_DIRECTION_OUTPUT					1

// GPIO Pin Mode Bit Value
#define ST600_MBUS_MODE_OPEN_DRAIN					0
#define ST600_MBUS_MODE_PUSH_PULL					1

// GPIO Function Bitmask
#define ST600_MBUS_MASK_FUNCTION_GPIO_7_CLK			0x01
#define ST600_MBUS_MASK_FUNCTION_GPIO_0_TXT			0x02
#define ST600_MBUS_MASK_FUNCTION_GPIO_1_RXT			0x04

// GPIO Function Bit Value
#define ST600_MBUS_GPIO_FUNCTION						0
#define ST600_MBUS_SPECIAL_FUNCTION					1

// GPIO Pin Bitmask
#define ST600_MBUS_MASK_GPIO_0						0x01
#define ST600_MBUS_MASK_GPIO_1						0x02
#define ST600_MBUS_MASK_GPIO_2						0x04
#define ST600_MBUS_MASK_GPIO_3						0x08
#define ST600_MBUS_MASK_GPIO_4						0x10
#define ST600_MBUS_MASK_GPIO_5						0x20
#define ST600_MBUS_MASK_GPIO_6						0x40
#define ST600_MBUS_MASK_GPIO_7						0x80

/////////////////////////////////////////////////////////////////////////////
// Part Number Definitions
/////////////////////////////////////////////////////////////////////////////

// Part Numbers
#define ST600_MBUS_PART_CP2112						0x0C

/////////////////////////////////////////////////////////////////////////////
// User Customization Definitions
/////////////////////////////////////////////////////////////////////////////

// User-Customizable Field Lock Bitmasks
#define ST600_MBUS_LOCK_VID							0x01
#define ST600_MBUS_LOCK_PID							0x02
#define ST600_MBUS_LOCK_POWER						0x04
#define ST600_MBUS_LOCK_POWER_MODE					0x08
#define ST600_MBUS_LOCK_RELEASE_VERSION				0x10
#define ST600_MBUS_LOCK_MFG_STR						0x20
#define ST600_MBUS_LOCK_PRODUCT_STR					0x40
#define ST600_MBUS_LOCK_SERIAL_STR					0x80

// Field Lock Bit Values
#define ST600_MBUS_LOCK_UNLOCKED						1
#define ST600_MBUS_LOCK_LOCKED						0

// Power Max Value (500 mA)
#define ST600_MBUS_BUS_POWER_MAX						0xFA

// Power Modes
#define ST600_MBUS_BUS_POWER							0x00
#define ST600_MBUS_SELF_POWER_VREG_DIS				0x01
#define ST600_MBUS_SELF_POWER_VREG_EN				0x02

// USB Config Bitmasks
#define ST600_MBUS_SET_VID							0x01
#define ST600_MBUS_SET_PID							0x02
#define ST600_MBUS_SET_POWER							0x04
#define ST600_MBUS_SET_POWER_MODE					0x08
#define ST600_MBUS_SET_RELEASE_VERSION				0x10

// USB Config Bit Values
#define ST600_MBUS_SET_IGNORE						0
#define ST600_MBUS_SET_PROGRAM						1

// String Lengths
#define ST600_MBUS_CP2112_MFG_STRLEN					30
#define ST600_MBUS_CP2112_PRODUCT_STRLEN				30
#define ST600_MBUS_CP2112_SERIAL_STRLEN				30

// ST600_MBUS_MFG_STR
typedef char ST600_MBUS_CP2112_MFG_STR[ST600_MBUS_CP2112_MFG_STRLEN];

// ST600_MBUS_PRODUCT_STR
typedef char ST600_MBUS_CP2112_PRODUCT_STR[ST600_MBUS_CP2112_PRODUCT_STRLEN];

// ST600_MBUS_SERIAL_STR
typedef char ST600_MBUS_CP2112_SERIAL_STR[ST600_MBUS_CP2112_SERIAL_STRLEN];

/////////////////////////////////////////////////////////////////////////////
// Typedefs
/////////////////////////////////////////////////////////////////////////////

typedef void* HID_SMBUS_DEVICE;

/////////////////////////////////////////////////////////////////////////////
// Exported Library Functions
/////////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

// ST_Connect
ST600UNET_API int WINAPI ST600uNet_Connect(unsigned char *  DeviceAddress ,char *ProductString, char * SerialNumber );
// ST_Close
ST600UNET_API int WINAPI ST600uNet_Close(unsigned char DeviceAddress, char * SerialNumber);
//--------------------  Errors Functions-----------------------------
ST600UNET_API int WINAPI ST600uNet_GetError(char * Error);
ST600UNET_API int WINAPI ST600uNet_Get_RMV858_Kernel_LastError(unsigned char motor_addr_mask, unsigned short int *kernel_error, unsigned short int * last_command, unsigned short int *Error_number );
ST600UNET_API int WINAPI ST600uNet_Get_RMV858_Kernel_Chopper_Error(unsigned char motor_address_mask,unsigned short int * kernel_error, unsigned short int * state_status,
																   unsigned short int *OverCurrent_counter, unsigned short int *OverTemp_counter, unsigned short int *Error_number);

ST600UNET_API int WINAPI ST600uNet_Reset_RMV858_Internal_Errors(unsigned char motor_address_mask,unsigned short int * Error_number);
//------------------------------------------------------------------------------------------------------------------------
//---------------JOG Function------------------------------------------------------------------
ST600UNET_API int WINAPI ST600uNet_MotorJOG(unsigned char motor_address_mask,  short int Speed, unsigned short int *bytes_available ,unsigned short int *Error_number);
///-------------------------------------------------------------------------------------------
//---------------EXTERNAL LIMIT Switch Functions------------------------------------------------------------------
ST600UNET_API int WINAPI ST600uNet_Motor_SEEK_HOME(unsigned char motor_address_mask,  short int Speed, unsigned short int *Error_number);
ST600UNET_API int WINAPI ST600uNet_Motor_Move_From_Limit_SW(unsigned char motor_address_mask,  short int number_of_steps, unsigned short int *Error_number);
/*
    1 < short int number_of_steps <=  1000 steps 
	if number_of_steps > 0 ==> Motion move CW
    if number_of_steps < 0 ==> Motion move CCW
	Note: in order to move the axis from a Limit switch , the direction must be inverse from the previous one. 
 
*/
//---------------------------------------------------------------------------------------------------------------

// Motion related Functions
ST600UNET_API int WINAPI ST600uNet_MotorSpeedControl(unsigned char motor_address_mask,  short int speed_kind , short int Speed, unsigned short int Acceleration,unsigned short int Deceleration,unsigned short int * bytes_available,unsigned short int *Error_number);
// Motor Trigger Direct and Sequential
ST600UNET_API int WINAPI ST600uNet_MotorTrigger(unsigned char motor_address_mask, unsigned char  triggerflag, unsigned short int * Error_number);


// Motor Set Parameters 
ST600UNET_API int WINAPI ST600uNet_SetMotorParameters(unsigned char motor_address_mask, unsigned int winding_current_in_mAmp, float inductance_in_mH,
													  unsigned char motor_power, unsigned char bipolar_unipolar, float winding_resitance_in_Ohms,unsigned char step_angle, unsigned short int * Error_number );


////////////////////////////////////Motion Configuration///////////////////////////////////////////////////////////////////////////////// 
// Set Motion Configuration  
ST600UNET_API int WINAPI ST600uNet_SetMotionConfig(unsigned char motor_address_mask, unsigned char operating_mode, unsigned char step_resolution,
													  unsigned char control_mode , unsigned char sampling_rate, unsigned char enable_fifo,unsigned char sequential_motion,
													  unsigned char seq_motion_controllers_enabled,unsigned char sequential_trigger_mask ,unsigned short int* Error_number );
// Set Motion Operation Mode  
ST600UNET_API int WINAPI ST600uNet_SetMotionOperationMode(unsigned char motor_address_masks, unsigned char operating_mode, unsigned short int * Error_number);
// Set Step Resolution Mode  
ST600UNET_API int WINAPI ST600uNet_SetStepResolution(unsigned char motor_address_masks, unsigned char step_resolution);


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// ----------------Read Functions 
ST600UNET_API int WINAPI ST600uNet_ReadMotorParameters(unsigned char motor_address_mask,unsigned int *winding_current_in_mAmp, float *inductance_in_mH,
													  unsigned char *motor_power, unsigned int *motor_config, float *winding_resitance_in_Ohms,
													  unsigned int *speed_open_loop, unsigned char* step_angle, unsigned short int *Error_number);

//-----------------------Motion Move function -----------------------------------------------
ST600UNET_API int WINAPI ST600uNet_MotorStepsMove(unsigned char motor_addr_mask, long step_numbers, short int speed, unsigned short int acceleration, 
												  unsigned short int deceleration,  unsigned short int * Error_number );
// --------------------Control Functions --------------------------------------------------
ST600UNET_API int WINAPI ST600uNet_MotorSoftwareStop(unsigned char motor_address_mask,unsigned char stop_parameters, unsigned short int *Error_number);


//--------------- FIFO Functions--------------------------------------------------
ST600UNET_API int WINAPI ST600uNet_FIFOWriteMotion(unsigned char motor_address_mask,unsigned short int *buffer, unsigned short int buffer_size,
										unsigned short int fifo_command, unsigned short int *fifo_data_avalable );

ST600UNET_API int WINAPI ST600uNet_FIFOGetFreeSpace(unsigned char motor_address_mask, unsigned short int *fifo_data_avalable );

ST600UNET_API int WINAPI ST600uNet_FIFO_DELETE(unsigned char motor_address_mask,unsigned  short int *fifo_data_avalable );

//--------------------------------FLASH Function-------------------------------------------------
ST600UNET_API int WINAPI  ST600uNet_SAVE_ParametersToInternal_FLASH(unsigned char motor_addr_mask,unsigned short int what_to_save ,unsigned short int* Error_number );

//---------------------------------------------------------------------------------------------
//--------------------------------Current Functions and system GAIN -----------------------------
ST600UNET_API int WINAPI  ST600uNet_Adjust_Current(unsigned char motor_addr_mask, unsigned short int flag_zero_or_maximum_current, unsigned short int winding_max_current,unsigned short int *Error_number);

ST600UNET_API int WINAPI  ST600uNet_Change_SystemGAIN(unsigned char motor_addr_mask, unsigned char set_or_read_sytem_gain,unsigned short int new_system_gain,unsigned short int * actual_gain, unsigned short int* Error_number);
//----------------------------End Current System Gain Functions-------------------------------------------------


//----------------------------------------------------------------------

//-----------------------------------------Report Functions-----------------------------------------------
ST600UNET_API int WINAPI  ST600uNet_Get_Internal_Report(unsigned char motor_addr_mask,unsigned short int *current_driver_flags,unsigned short int what_kind_of_report ,unsigned short int* Error_number);

ST600UNET_API int WINAPI  ST600uNet_Get_StepsCounter_MotorF_Report(unsigned char motor_addr_mask,unsigned short int *motor_internal_flags_1,unsigned short int *motor_internal_flags_2, long *step_counter ,
																   unsigned short int *over_current_counter, unsigned short int *over_temperature_counter,unsigned short int* Error_number);

//----------------------------------------Set Step Numbers for Different Control mode
ST600UNET_API int WINAPI  ST600uNet_Set_StepNumbersControl(unsigned char motor_addr_mask,unsigned short int which_mode, long step_numbers ,
													  short int speed, unsigned  short int acceleration , unsigned short int deceleration,unsigned short int * Error_number );
//--------------------------------------Set holding Torque----------------------------------------------
ST600UNET_API int WINAPI  ST600uNet_Set_HoldingTorque(unsigned char motor_addr_mask,unsigned short int which_holding_current, unsigned	short int * Error_number );

//--------------------------------------Bootlaoder Functions ------------------------------------------
ST600UNET_API int WINAPI  ST600uNet_Run_Bootloader(unsigned char motor_addr_mask,unsigned short int* Error_number);
ST600UNET_API int WINAPI  ST600uNet_Bootloader_Load_HexFile(unsigned char motor_addr_mask,const char * address_of_the_file,unsigned short int array_size,unsigned short int* Error_number);
ST600UNET_API int WINAPI  ST600uNet_Bootloader_Version(unsigned char motor_addr_mask,unsigned char * major_ver ,unsigned char *minor_ver,unsigned short int* Error_number);
ST600UNET_API int WINAPI  ST600uNet_Bootloader_ProgramFlash(unsigned char motor_addr_mask,unsigned short int* Error_number);
ST600UNET_API int WINAPI  ST600uNet_Bootloader_EraseFlash(unsigned char motor_addr_mask,unsigned short int* Error_number);
ST600UNET_API int WINAPI  ST600uNet_Bootloader_VerifyFlash(unsigned char motor_addr_mask,unsigned short int* Error_number);
ST600UNET_API int WINAPI  ST600uNet_Bootloader_Progress(unsigned char motor_addr_mask,unsigned int *actual_record,unsigned int *total_records,unsigned short int* Error_number );
ST600UNET_API int WINAPI  ST600uNet_Bootloader_RunApplication(unsigned char motor_addr_mask,unsigned short int* Error_number );

//-----------------End Firmaware Upgrade funtions------------------------------------------------------

//------------------------Delay Motion Function------------------------------------------------------- 
ST600UNET_API int WINAPI  ST600uNet_Set_Motion_Delay(unsigned char motor_addr_mask,unsigned char select_msec_or_usec,unsigned short int delay ,unsigned short int* Error_number);
//-----------------------------------------------------------------------------------------------------

// -------------SET SEQUENTIAL MOTION functions-------------------------------  
ST600UNET_API int WINAPI  ST600uNet_Set_Sequential_Motion(unsigned char motor_addr_mask,unsigned char sequential_controllers_enable_addr,
															unsigned char pivot_controller, unsigned short int* Error_number);
/*
 This function will initializate "The Sequestial Motion" to the controller address which the command is sent, must be sent at the bigining of the sequential motion session.
 If a new sequence is needed, this function need to be called agian.   
 Parameters:  
             Controllers Enabled: sequential_controllers_enable_addr, ON = "1", OFF = "0"; 
			 Pivot controller : this will be trigger by himself (trough a Trigger Command) and MASK Interrupt is identical to the mask programmed   
*/
ST600UNET_API int WINAPI  ST600uNet_Sequential_Motion_Interrupt_MASK(unsigned char motor_addr_mask, unsigned char matching_kte  ,unsigned short int* Error_number);
/*
This function control the real time sequestial MASK trigger interrupt. 
Also different sequential masks can be re-programmed sending a new "matching_kte" to RMV858 controller.      
*/
ST600UNET_API int WINAPI  ST600uNet_Disable_Sequential_Motion(unsigned char motor_addr_mask, unsigned short int* Error_number);


//-------------------------End Table Event------------------------------------------------------------
//-----------------------Analog Digital Inputs--------------------------------------------------------
ST600UNET_API int WINAPI  ST600uNet_Digital_Input_Output(unsigned char motor_addr_mask,unsigned char output_value, unsigned char * input_value, unsigned short int* Error_number);
ST600UNET_API int WINAPI  ST600uNet_Analog_Input(unsigned char motor_addr_mask,float * adc_channel, unsigned short int* Error_number);


//-------------------------End Analog -Digital Functions ---------------------------------------------

//----------------------Reset Motion Parameters and Full RESET----------------------------------------
ST600UNET_API int WINAPI  ST600uNet_Reset(unsigned char motor_addr_mask,unsigned short int what_to_reset, unsigned short int* Error_number);
//----------------------------End Reset Functions----------------------------------------------------



#ifdef __cplusplus
}
#endif // __cplusplus

#endif // SLAB_CP2112_H
