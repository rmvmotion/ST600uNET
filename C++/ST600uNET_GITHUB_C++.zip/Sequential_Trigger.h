/********************************************************************
* � 2017 RMV Motion Inc.
*
* SOFTWARE LICENSE AGREEMENT:
* RMV Motion Incorporated ("RMV") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with RMV's
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY RMV "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH RMV'S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL RMV BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF RMV HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, RMV'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO RMV SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  RMV has no obligation to modify, test, 
* certify, or support the code.
*
*******************************************************************************/

/////////////////////////////////////////////////////////////////////////////
//                    RMV Motion Inc. 
//                    ST600uNEt.h
//                    ST600uNET_APP Version Ver: 7.11
//                    Author: Albert Tello
///////////////////////////////////////////////////////////////////////////////

#pragma once
#include "ST600uNet.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
	using namespace System::Runtime::InteropServices; // for class Marshal
    using namespace std;
//	using namespace msclr::interop;





extern unsigned char motor_addr_mask ;
extern unsigned char sequential_trigger_mask;
extern unsigned char seq_motion_controllers_enabled;
extern unsigned char pivot_controllers_mask;
extern char Error[255];
namespace APP_ST600uNet {

	/// <summary>
	/// Summary for Sequential_Trigger
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class Sequential_Trigger : public System::Windows::Forms::Form
	{
	public:
		Sequential_Trigger(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			// Pivot controllers setup
           if (motor_addr_mask==1)
		   {
			   STAddr0->Checked=true;
			   STAddr0->AutoCheck=false;   
		       MC_AD0->Checked=true;
			   MC_AD0->AutoCheck=false;
			   MR_AD0->AutoCheck=false;
			 sequential_trigger_mask |= 0x01;
		   }else  if (motor_addr_mask==2)
		   {    STAddr1->Checked=true;
		        STAddr1->AutoCheck=false;   
		        MC_AD1->Checked=true;
                MC_AD1->AutoCheck=false;
			    MR_AD1->AutoCheck=false;
			 sequential_trigger_mask |= 0x02;
		   }else if (motor_addr_mask==4)
		   {
               STAddr2->Checked=true;
			   STAddr2->AutoCheck=false;
			   MC_AD2->Checked=true;
			   MC_AD2->AutoCheck=false;
			   MR_AD2->AutoCheck=false;
			   sequential_trigger_mask |= 0x04;
		   }else if (motor_addr_mask==8)
		   {
              STAddr3->Checked=true;
			  STAddr3->AutoCheck=false;
			  MC_AD3->Checked=true;
			  MC_AD3->AutoCheck=false;
			  MR_AD3->AutoCheck=false;
			  sequential_trigger_mask |= 0x08;
			  
		   }else MessageBox::Show( "Sequential Trigger Address are wrong... ","Error in setting sequestial trigger address.... ", MessageBoxButtons::OK,MessageBoxIcon::Hand);  

		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Sequential_Trigger()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Close22;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::CheckBox^  STAddr0;
	private: System::Windows::Forms::CheckBox^  STAddr3;
	private: System::Windows::Forms::CheckBox^  STAddr2;
	private: System::Windows::Forms::CheckBox^  STAddr1;












	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Panel^  panel3;




	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  STA_0;





	private: System::Windows::Forms::Label^  STA_3;
	private: System::Windows::Forms::Label^  STA_2;
	private: System::Windows::Forms::Label^  STA_1;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Panel^  panel2;
	private: System::Windows::Forms::RadioButton^  MC_AD0;

	private: System::Windows::Forms::RadioButton^  MR_AD0;
	private: System::Windows::Forms::Panel^  panel4;
	private: System::Windows::Forms::RadioButton^  MC_AD1;

	private: System::Windows::Forms::RadioButton^  MR_AD1;
	private: System::Windows::Forms::Panel^  panel5;
	private: System::Windows::Forms::RadioButton^  MC_AD2;
	private: System::Windows::Forms::RadioButton^  MR_AD2;
	private: System::Windows::Forms::Panel^  panel6;
	private: System::Windows::Forms::RadioButton^  MC_AD3;
	private: System::Windows::Forms::RadioButton^  MR_AD3;
	private: System::Windows::Forms::Button^  Mask;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  MaskT;

	private: System::Windows::Forms::TextBox^  CEnabled;
	private: System::Windows::Forms::Label^  label9;

private: System::Windows::Forms::Label^  label10;
private: System::Windows::Forms::Label^  label12;
private: System::Windows::Forms::Panel^  panel7;



private: System::Windows::Forms::Label^  label13;
private: System::Windows::Forms::RadioButton^  Pivot0;

private: System::Windows::Forms::Label^  label11;
private: System::Windows::Forms::Label^  label14;
private: System::Windows::Forms::Label^  label15;
private: System::Windows::Forms::RadioButton^  Pivot3;
private: System::Windows::Forms::RadioButton^  Pivot2;
private: System::Windows::Forms::RadioButton^  Pivot1;
private: System::Windows::Forms::TextBox^  PivotC;

private: System::Windows::Forms::Label^  label16;
private: System::Windows::Forms::Label^  label17;
private: System::Windows::Forms::Label^  label18;
private: System::Windows::Forms::Label^  label19;
private: System::Windows::Forms::Label^  label20;
private: System::Windows::Forms::Label^  label21;
private: System::Windows::Forms::Label^  label22;
private: System::Windows::Forms::Label^  label23;
private: System::Windows::Forms::Label^  label25;
private: System::Windows::Forms::Label^  label24;
private: System::Windows::Forms::Button^  DisableSEQM;
private: System::Windows::Forms::Button^  SEQMask;
private: System::Windows::Forms::Label^  label26;
private: System::Windows::Forms::Label^  label27;
private: System::Windows::Forms::Label^  label29;
private: System::Windows::Forms::Label^  label28;





	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Close22 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->STAddr3 = (gcnew System::Windows::Forms::CheckBox());
			this->STAddr2 = (gcnew System::Windows::Forms::CheckBox());
			this->STAddr1 = (gcnew System::Windows::Forms::CheckBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->STAddr0 = (gcnew System::Windows::Forms::CheckBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->SEQMask = (gcnew System::Windows::Forms::Button());
			this->DisableSEQM = (gcnew System::Windows::Forms::Button());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->PivotC = (gcnew System::Windows::Forms::TextBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->MaskT = (gcnew System::Windows::Forms::TextBox());
			this->CEnabled = (gcnew System::Windows::Forms::TextBox());
			this->Mask = (gcnew System::Windows::Forms::Button());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->MC_AD3 = (gcnew System::Windows::Forms::RadioButton());
			this->MR_AD3 = (gcnew System::Windows::Forms::RadioButton());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->MC_AD2 = (gcnew System::Windows::Forms::RadioButton());
			this->MR_AD2 = (gcnew System::Windows::Forms::RadioButton());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->MC_AD1 = (gcnew System::Windows::Forms::RadioButton());
			this->MR_AD1 = (gcnew System::Windows::Forms::RadioButton());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->MC_AD0 = (gcnew System::Windows::Forms::RadioButton());
			this->MR_AD0 = (gcnew System::Windows::Forms::RadioButton());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->STA_3 = (gcnew System::Windows::Forms::Label());
			this->STA_2 = (gcnew System::Windows::Forms::Label());
			this->STA_1 = (gcnew System::Windows::Forms::Label());
			this->STA_0 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->panel7 = (gcnew System::Windows::Forms::Panel());
			this->Pivot3 = (gcnew System::Windows::Forms::RadioButton());
			this->Pivot2 = (gcnew System::Windows::Forms::RadioButton());
			this->Pivot1 = (gcnew System::Windows::Forms::RadioButton());
			this->Pivot0 = (gcnew System::Windows::Forms::RadioButton());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->panel1->SuspendLayout();
			this->panel3->SuspendLayout();
			this->panel6->SuspendLayout();
			this->panel5->SuspendLayout();
			this->panel4->SuspendLayout();
			this->panel2->SuspendLayout();
			this->panel7->SuspendLayout();
			this->SuspendLayout();
			// 
			// Close22
			// 
			this->Close22->BackColor = System::Drawing::Color::Gainsboro;
			this->Close22->Font = (gcnew System::Drawing::Font(L"Calibri", 11, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Close22->ForeColor = System::Drawing::Color::Red;
			this->Close22->Location = System::Drawing::Point(686, 345);
			this->Close22->Name = L"Close22";
			this->Close22->Size = System::Drawing::Size(119, 32);
			this->Close22->TabIndex = 100;
			this->Close22->Text = L"&EXIT";
			this->Close22->UseVisualStyleBackColor = false;
			this->Close22->Click += gcnew System::EventHandler(this, &Sequential_Trigger::Close22_Click);
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::SystemColors::ControlLight;
			this->panel1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel1->Controls->Add(this->STAddr3);
			this->panel1->Controls->Add(this->STAddr2);
			this->panel1->Controls->Add(this->STAddr1);
			this->panel1->Controls->Add(this->label1);
			this->panel1->Controls->Add(this->STAddr0);
			this->panel1->Location = System::Drawing::Point(27, 12);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(407, 66);
			this->panel1->TabIndex = 1;
			// 
			// STAddr3
			// 
			this->STAddr3->AutoSize = true;
			this->STAddr3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STAddr3->Location = System::Drawing::Point(315, 33);
			this->STAddr3->Name = L"STAddr3";
			this->STAddr3->Size = System::Drawing::Size(68, 17);
			this->STAddr3->TabIndex = 4;
			this->STAddr3->Text = L"ADDR3";
			this->STAddr3->UseVisualStyleBackColor = true;
			// 
			// STAddr2
			// 
			this->STAddr2->AutoSize = true;
			this->STAddr2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STAddr2->Location = System::Drawing::Point(203, 33);
			this->STAddr2->Name = L"STAddr2";
			this->STAddr2->Size = System::Drawing::Size(68, 17);
			this->STAddr2->TabIndex = 3;
			this->STAddr2->Text = L"ADDR2";
			this->STAddr2->UseVisualStyleBackColor = true;
			// 
			// STAddr1
			// 
			this->STAddr1->AutoSize = true;
			this->STAddr1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STAddr1->Location = System::Drawing::Point(98, 33);
			this->STAddr1->Name = L"STAddr1";
			this->STAddr1->Size = System::Drawing::Size(68, 17);
			this->STAddr1->TabIndex = 2;
			this->STAddr1->Text = L"ADDR1";
			this->STAddr1->UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::Green;
			this->label1->Location = System::Drawing::Point(18, 7);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(347, 18);
			this->label1->TabIndex = 1;
			this->label1->Text = L"Sequential  Motion RMV858 Address Enabled";
			// 
			// STAddr0
			// 
			this->STAddr0->AutoSize = true;
			this->STAddr0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STAddr0->Location = System::Drawing::Point(3, 33);
			this->STAddr0->Name = L"STAddr0";
			this->STAddr0->Size = System::Drawing::Size(68, 17);
			this->STAddr0->TabIndex = 0;
			this->STAddr0->Text = L"ADDR0";
			this->STAddr0->UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::Black;
			this->label3->Location = System::Drawing::Point(23, 100);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(430, 16);
			this->label3->TabIndex = 3;
			this->label3->Text = L"It is the address controller which hold the followings charateristics : ";
			this->label3->Click += gcnew System::EventHandler(this, &Sequential_Trigger::label3_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::Black;
			this->label4->Location = System::Drawing::Point(24, 115);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(691, 16);
			this->label4->TabIndex = 4;
			this->label4->Text = L"i) It needs to be trigger by a software command, �DIRECT_TRIGGER_ON� or �DIRECT_T" 
				L"RIGGER_ALWAYS�.";
			this->label4->Click += gcnew System::EventHandler(this, &Sequential_Trigger::label4_Click);
			// 
			// panel3
			// 
			this->panel3->BackColor = System::Drawing::SystemColors::ControlLight;
			this->panel3->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel3->Controls->Add(this->label29);
			this->panel3->Controls->Add(this->label28);
			this->panel3->Controls->Add(this->label27);
			this->panel3->Controls->Add(this->label26);
			this->panel3->Controls->Add(this->SEQMask);
			this->panel3->Controls->Add(this->DisableSEQM);
			this->panel3->Controls->Add(this->label25);
			this->panel3->Controls->Add(this->label24);
			this->panel3->Controls->Add(this->label23);
			this->panel3->Controls->Add(this->label22);
			this->panel3->Controls->Add(this->label21);
			this->panel3->Controls->Add(this->label20);
			this->panel3->Controls->Add(this->label19);
			this->panel3->Controls->Add(this->label18);
			this->panel3->Controls->Add(this->label16);
			this->panel3->Controls->Add(this->PivotC);
			this->panel3->Controls->Add(this->label10);
			this->panel3->Controls->Add(this->label9);
			this->panel3->Controls->Add(this->label2);
			this->panel3->Controls->Add(this->MaskT);
			this->panel3->Controls->Add(this->CEnabled);
			this->panel3->Controls->Add(this->Mask);
			this->panel3->Controls->Add(this->Close22);
			this->panel3->Controls->Add(this->panel6);
			this->panel3->Controls->Add(this->panel5);
			this->panel3->Controls->Add(this->panel4);
			this->panel3->Controls->Add(this->panel2);
			this->panel3->Controls->Add(this->label8);
			this->panel3->Controls->Add(this->STA_3);
			this->panel3->Controls->Add(this->STA_2);
			this->panel3->Controls->Add(this->STA_1);
			this->panel3->Controls->Add(this->STA_0);
			this->panel3->Controls->Add(this->label7);
			this->panel3->Controls->Add(this->label6);
			this->panel3->Controls->Add(this->label5);
			this->panel3->Location = System::Drawing::Point(26, 204);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(812, 384);
			this->panel3->TabIndex = 5;
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(516, 142);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(274, 13);
			this->label27->TabIndex = 114;
			this->label27->Text = L"---------------------------------------------------------------------------------" 
				L"--------";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(122, 142);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(274, 13);
			this->label26->TabIndex = 113;
			this->label26->Text = L"---------------------------------------------------------------------------------" 
				L"--------";
//			this->label26->Click += gcnew System::EventHandler(this, &Sequential_Trigger::label26_Click);
			// 
			// SEQMask
			// 
			this->SEQMask->Font = (gcnew System::Drawing::Font(L"Calibri", 11, System::Drawing::FontStyle::Bold));
			this->SEQMask->ForeColor = System::Drawing::Color::Navy;
			this->SEQMask->Location = System::Drawing::Point(279, 345);
			this->SEQMask->Name = L"SEQMask";
			this->SEQMask->Size = System::Drawing::Size(180, 32);
			this->SEQMask->TabIndex = 112;
			this->SEQMask->Text = L"Set Motion Tigger &Mask";
			this->SEQMask->UseVisualStyleBackColor = true;
			this->SEQMask->Click += gcnew System::EventHandler(this, &Sequential_Trigger::SEQMask_Click);
			// 
			// DisableSEQM
			// 
			this->DisableSEQM->Font = (gcnew System::Drawing::Font(L"Calibri", 11, System::Drawing::FontStyle::Bold));
			this->DisableSEQM->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)), 
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->DisableSEQM->Location = System::Drawing::Point(457, 345);
			this->DisableSEQM->Name = L"DisableSEQM";
			this->DisableSEQM->Size = System::Drawing::Size(223, 32);
			this->DisableSEQM->TabIndex = 111;
			this->DisableSEQM->Text = L"&Disable Sequential Motion";
			this->DisableSEQM->UseVisualStyleBackColor = true;
			this->DisableSEQM->Click += gcnew System::EventHandler(this, &Sequential_Trigger::DisableSEQM_Click);
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(12, 323);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(421, 13);
			this->label25->TabIndex = 110;
			this->label25->Text = L"Note 3: ADDR3 will be triggered when: ADDR3 is not running, and ADDR0 start runni" 
				L"ng";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(12, 310);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(771, 13);
			this->label24->TabIndex = 109;
			this->label24->Text = L"Note 2: ADDR0 will be triggered when: ADDR3 is not running, and ADDR0 receive the" 
				L" command: �DIRECT_TRIGGER_ON�, or �DIRECT_TRIGGER_ALWAYS�.";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(177, 293);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(552, 13);
			this->label23->TabIndex = 108;
			this->label23->Text = L"\"ADDR3\" SEQ Trigger Mask Command = Motion Running 0   -ORED- Motion Completed 3, " 
				L"Vector Mask = 0x01;     ";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(177, 276);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(558, 13);
			this->label22->TabIndex = 107;
			this->label22->Text = L"\"ADDR0\" SEQ Trigger Mask Command = Motion completed 0  -ORED- Motion Completed 3," 
				L" Vector Mask = 0x09;     ";
//			this->label22->Click += gcnew System::EventHandler(this, &Sequential_Trigger::label22_Click);
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Font = (gcnew System::Drawing::Font(L"Century", 9.75F, System::Drawing::FontStyle::Underline, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label21->Location = System::Drawing::Point(75, 255);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(297, 16);
			this->label21->TabIndex = 106;
			this->label21->Text = L"Build SEQ Motion Mask for ADDR0 and ADDR3";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Font = (gcnew System::Drawing::Font(L"Century", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label20->Location = System::Drawing::Point(435, 255);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(281, 16);
			this->label20->TabIndex = 105;
			this->label20->Text = L"�Pivot Controller Address: � = ADDR1 = 0x01;";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Font = (gcnew System::Drawing::Font(L"Century", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label19->Location = System::Drawing::Point(67, 239);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(305, 16);
			this->label19->TabIndex = 104;
			this->label19->Text = L"�RMV858 Enabled �= 0x09, ADDR0=1,ADDR3=1; ";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Font = (gcnew System::Drawing::Font(L"Century", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label18->Location = System::Drawing::Point(7, 223);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(547, 16);
			this->label18->TabIndex = 103;
			this->label18->Text = L"Example : RMV858  Address Selected= �ADDR0� and �ADDR3�. Pivot controller=ADDR0; " 
				L" ";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label16->Location = System::Drawing::Point(544, 207);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(198, 13);
			this->label16->TabIndex = 102;
			this->label16->Text = L"Pivot Controller Address: (in HEX)";
			// 
			// PivotC
			// 
			this->PivotC->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->PivotC->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(64)), 
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->PivotC->Location = System::Drawing::Point(748, 197);
			this->PivotC->Name = L"PivotC";
			this->PivotC->Size = System::Drawing::Size(53, 23);
			this->PivotC->TabIndex = 101;
			this->PivotC->Text = L"0";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Calibri", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::Color::Black;
			this->label10->Location = System::Drawing::Point(3, 86);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(793, 17);
			this->label10->TabIndex = 23;
			this->label10->Text = L"Note 1: The address which the command will be sent,  \"RMV858 Address.\" and �MASK " 
				L"ADDRx Motion Completed Flag� MUST BE SELECTED.";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(255, 207);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(200, 13);
			this->label9->TabIndex = 22;
			this->label9->Text = L"Sequential Trigger Mask (in HEX):";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(7, 207);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(160, 13);
			this->label2->TabIndex = 21;
			this->label2->Text = L"RMV858 Enabled (in HEX):";
			// 
			// MaskT
			// 
			this->MaskT->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MaskT->ForeColor = System::Drawing::Color::ForestGreen;
			this->MaskT->Location = System::Drawing::Point(460, 197);
			this->MaskT->Name = L"MaskT";
			this->MaskT->Size = System::Drawing::Size(53, 23);
			this->MaskT->TabIndex = 20;
			this->MaskT->Text = L"0";
			// 
			// CEnabled
			// 
			this->CEnabled->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->CEnabled->ForeColor = System::Drawing::Color::SaddleBrown;
			this->CEnabled->Location = System::Drawing::Point(163, 197);
			this->CEnabled->Name = L"CEnabled";
			this->CEnabled->Size = System::Drawing::Size(55, 23);
			this->CEnabled->TabIndex = 19;
			this->CEnabled->Text = L"0";
			// 
			// Mask
			// 
			this->Mask->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Mask->ForeColor = System::Drawing::Color::DarkGreen;
			this->Mask->Location = System::Drawing::Point(3, 345);
			this->Mask->Name = L"Mask";
			this->Mask->Size = System::Drawing::Size(276, 32);
			this->Mask->TabIndex = 18;
			this->Mask->Text = L"&Initialization  Sequestial Motion ";
			this->Mask->UseVisualStyleBackColor = true;
			this->Mask->Click += gcnew System::EventHandler(this, &Sequential_Trigger::Mask_Click);
			// 
			// panel6
			// 
			this->panel6->Controls->Add(this->MC_AD3);
			this->panel6->Controls->Add(this->MR_AD3);
			this->panel6->Location = System::Drawing::Point(516, 161);
			this->panel6->Name = L"panel6";
			this->panel6->Size = System::Drawing::Size(287, 27);
			this->panel6->TabIndex = 17;
			// 
			// MC_AD3
			// 
			this->MC_AD3->AutoSize = true;
			this->MC_AD3->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold));
			this->MC_AD3->ForeColor = System::Drawing::Color::OliveDrab;
			this->MC_AD3->Location = System::Drawing::Point(138, 3);
			this->MC_AD3->Name = L"MC_AD3";
			this->MC_AD3->Size = System::Drawing::Size(138, 18);
			this->MC_AD3->TabIndex = 1;
			this->MC_AD3->TabStop = true;
			this->MC_AD3->Text = L"Motion Completed  3";
			this->MC_AD3->UseVisualStyleBackColor = true;
			// 
			// MR_AD3
			// 
			this->MR_AD3->AutoSize = true;
			this->MR_AD3->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MR_AD3->ForeColor = System::Drawing::Color::OliveDrab;
			this->MR_AD3->Location = System::Drawing::Point(3, 3);
			this->MR_AD3->Name = L"MR_AD3";
			this->MR_AD3->Size = System::Drawing::Size(119, 18);
			this->MR_AD3->TabIndex = 0;
			this->MR_AD3->TabStop = true;
			this->MR_AD3->Text = L"Motor Running  3";
			this->MR_AD3->UseVisualStyleBackColor = true;
			// 
			// panel5
			// 
			this->panel5->Controls->Add(this->MC_AD2);
			this->panel5->Controls->Add(this->MR_AD2);
			this->panel5->Location = System::Drawing::Point(516, 112);
			this->panel5->Name = L"panel5";
			this->panel5->Size = System::Drawing::Size(287, 27);
			this->panel5->TabIndex = 16;
			// 
			// MC_AD2
			// 
			this->MC_AD2->AutoSize = true;
			this->MC_AD2->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold));
			this->MC_AD2->ForeColor = System::Drawing::Color::OliveDrab;
			this->MC_AD2->Location = System::Drawing::Point(138, 3);
			this->MC_AD2->Name = L"MC_AD2";
			this->MC_AD2->Size = System::Drawing::Size(138, 18);
			this->MC_AD2->TabIndex = 1;
			this->MC_AD2->TabStop = true;
			this->MC_AD2->Text = L"Motion Completed  2";
			this->MC_AD2->UseVisualStyleBackColor = true;
			// 
			// MR_AD2
			// 
			this->MR_AD2->AutoSize = true;
			this->MR_AD2->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MR_AD2->ForeColor = System::Drawing::Color::OliveDrab;
			this->MR_AD2->Location = System::Drawing::Point(3, 3);
			this->MR_AD2->Name = L"MR_AD2";
			this->MR_AD2->Size = System::Drawing::Size(119, 18);
			this->MR_AD2->TabIndex = 0;
			this->MR_AD2->TabStop = true;
			this->MR_AD2->Text = L"Motor Running  2";
			this->MR_AD2->UseVisualStyleBackColor = true;
			// 
			// panel4
			// 
			this->panel4->Controls->Add(this->MC_AD1);
			this->panel4->Controls->Add(this->MR_AD1);
			this->panel4->Location = System::Drawing::Point(119, 161);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(277, 27);
			this->panel4->TabIndex = 15;
			// 
			// MC_AD1
			// 
			this->MC_AD1->AutoSize = true;
			this->MC_AD1->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold));
			this->MC_AD1->ForeColor = System::Drawing::Color::OliveDrab;
			this->MC_AD1->Location = System::Drawing::Point(138, 3);
			this->MC_AD1->Name = L"MC_AD1";
			this->MC_AD1->Size = System::Drawing::Size(138, 18);
			this->MC_AD1->TabIndex = 1;
			this->MC_AD1->TabStop = true;
			this->MC_AD1->Text = L"Motion Completed  1";
			this->MC_AD1->UseVisualStyleBackColor = true;
			// 
			// MR_AD1
			// 
			this->MR_AD1->AutoSize = true;
			this->MR_AD1->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MR_AD1->ForeColor = System::Drawing::Color::OliveDrab;
			this->MR_AD1->Location = System::Drawing::Point(3, 3);
			this->MR_AD1->Name = L"MR_AD1";
			this->MR_AD1->Size = System::Drawing::Size(119, 18);
			this->MR_AD1->TabIndex = 0;
			this->MR_AD1->TabStop = true;
			this->MR_AD1->Text = L"Motor Running  1";
			this->MR_AD1->UseVisualStyleBackColor = true;
			// 
			// panel2
			// 
			this->panel2->Controls->Add(this->MC_AD0);
			this->panel2->Controls->Add(this->MR_AD0);
			this->panel2->Location = System::Drawing::Point(120, 112);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(277, 27);
			this->panel2->TabIndex = 14;
			// 
			// MC_AD0
			// 
			this->MC_AD0->AutoSize = true;
			this->MC_AD0->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold));
			this->MC_AD0->ForeColor = System::Drawing::Color::OliveDrab;
			this->MC_AD0->Location = System::Drawing::Point(138, 3);
			this->MC_AD0->Name = L"MC_AD0";
			this->MC_AD0->Size = System::Drawing::Size(138, 18);
			this->MC_AD0->TabIndex = 1;
			this->MC_AD0->TabStop = true;
			this->MC_AD0->Text = L"Motion Completed  0";
			this->MC_AD0->UseVisualStyleBackColor = true;
			this->MC_AD0->CheckedChanged += gcnew System::EventHandler(this, &Sequential_Trigger::radioButton1_CheckedChanged);
			// 
			// MR_AD0
			// 
			this->MR_AD0->AutoSize = true;
			this->MR_AD0->Font = (gcnew System::Drawing::Font(L"Oklahoma", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->MR_AD0->ForeColor = System::Drawing::Color::OliveDrab;
			this->MR_AD0->Location = System::Drawing::Point(3, 3);
			this->MR_AD0->Name = L"MR_AD0";
			this->MR_AD0->Size = System::Drawing::Size(119, 18);
			this->MR_AD0->TabIndex = 0;
			this->MR_AD0->TabStop = true;
			this->MR_AD0->Text = L"Motor Running  0";
			this->MR_AD0->UseVisualStyleBackColor = true;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Calibri", 10, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::Color::Black;
			this->label8->Location = System::Drawing::Point(3, 65);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(516, 17);
			this->label8->TabIndex = 13;
			this->label8->Text = L"Please Select:  Motion Completed  or  Motor Running to setup a Sequential Motion " 
				L"Trigger ";
			// 
			// STA_3
			// 
			this->STA_3->AutoSize = true;
			this->STA_3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STA_3->ForeColor = System::Drawing::Color::Brown;
			this->STA_3->Location = System::Drawing::Point(417, 166);
			this->STA_3->Name = L"STA_3";
			this->STA_3->Size = System::Drawing::Size(95, 13);
			this->STA_3->TabIndex = 12;
			this->STA_3->Text = L"MASK ADDR3 :";
			// 
			// STA_2
			// 
			this->STA_2->AutoSize = true;
			this->STA_2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STA_2->ForeColor = System::Drawing::Color::Brown;
			this->STA_2->Location = System::Drawing::Point(418, 126);
			this->STA_2->Name = L"STA_2";
			this->STA_2->Size = System::Drawing::Size(95, 13);
			this->STA_2->TabIndex = 11;
			this->STA_2->Text = L"MASK ADDR2 :";
			// 
			// STA_1
			// 
			this->STA_1->AutoSize = true;
			this->STA_1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STA_1->ForeColor = System::Drawing::Color::Brown;
			this->STA_1->Location = System::Drawing::Point(19, 166);
			this->STA_1->Name = L"STA_1";
			this->STA_1->Size = System::Drawing::Size(95, 13);
			this->STA_1->TabIndex = 10;
			this->STA_1->Text = L"MASK ADDR1 :";
			// 
			// STA_0
			// 
			this->STA_0->AutoSize = true;
			this->STA_0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->STA_0->ForeColor = System::Drawing::Color::Brown;
			this->STA_0->Location = System::Drawing::Point(19, 126);
			this->STA_0->Name = L"STA_0";
			this->STA_0->Size = System::Drawing::Size(95, 13);
			this->STA_0->TabIndex = 6;
			this->STA_0->Text = L"MASK ADDR0 :";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Calibri", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(228, 38);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(154, 18);
			this->label7->TabIndex = 3;
			this->label7->Text = L"Motion Completed: \"1\"";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Calibri", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(12, 38);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(132, 18);
			this->label6->TabIndex = 2;
			this->label6->Text = L"Motor Running : \"0\"";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::Maroon;
			this->label5->Location = System::Drawing::Point(62, 10);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(295, 18);
			this->label5->TabIndex = 1;
			this->label5->Text = L"Sequential Trigger Mask Combination ";
			this->label5->Click += gcnew System::EventHandler(this, &Sequential_Trigger::label5_Click);
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Calibri", 11, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline))));
			this->label12->ForeColor = System::Drawing::Color::DarkRed;
			this->label12->Location = System::Drawing::Point(23, 83);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(113, 18);
			this->label12->TabIndex = 6;
			this->label12->Text = L"Pivot Controller :";
			// 
			// panel7
			// 
			this->panel7->BackColor = System::Drawing::SystemColors::ControlLight;
			this->panel7->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->panel7->Controls->Add(this->Pivot3);
			this->panel7->Controls->Add(this->Pivot2);
			this->panel7->Controls->Add(this->Pivot1);
			this->panel7->Controls->Add(this->Pivot0);
			this->panel7->Controls->Add(this->label13);
			this->panel7->Location = System::Drawing::Point(440, 12);
			this->panel7->Name = L"panel7";
			this->panel7->Size = System::Drawing::Size(407, 66);
			this->panel7->TabIndex = 101;
			// 
			// Pivot3
			// 
			this->Pivot3->AutoSize = true;
			this->Pivot3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Pivot3->Location = System::Drawing::Point(314, 34);
			this->Pivot3->Name = L"Pivot3";
			this->Pivot3->Size = System::Drawing::Size(67, 17);
			this->Pivot3->TabIndex = 5;
			this->Pivot3->TabStop = true;
			this->Pivot3->Text = L"ADDR3";
			this->Pivot3->UseVisualStyleBackColor = true;
			// 
			// Pivot2
			// 
			this->Pivot2->AutoSize = true;
			this->Pivot2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Pivot2->Location = System::Drawing::Point(206, 33);
			this->Pivot2->Name = L"Pivot2";
			this->Pivot2->Size = System::Drawing::Size(67, 17);
			this->Pivot2->TabIndex = 4;
			this->Pivot2->TabStop = true;
			this->Pivot2->Text = L"ADDR2";
			this->Pivot2->UseVisualStyleBackColor = true;
			// 
			// Pivot1
			// 
			this->Pivot1->AutoSize = true;
			this->Pivot1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Pivot1->Location = System::Drawing::Point(109, 34);
			this->Pivot1->Name = L"Pivot1";
			this->Pivot1->Size = System::Drawing::Size(67, 17);
			this->Pivot1->TabIndex = 3;
			this->Pivot1->TabStop = true;
			this->Pivot1->Text = L"ADDR1";
			this->Pivot1->UseVisualStyleBackColor = true;
			// 
			// Pivot0
			// 
			this->Pivot0->AutoSize = true;
			this->Pivot0->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->Pivot0->Location = System::Drawing::Point(17, 34);
			this->Pivot0->Name = L"Pivot0";
			this->Pivot0->Size = System::Drawing::Size(67, 17);
			this->Pivot0->TabIndex = 2;
			this->Pivot0->TabStop = true;
			this->Pivot0->Text = L"ADDR0";
			this->Pivot0->UseVisualStyleBackColor = true;
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Underline)), 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->label13->ForeColor = System::Drawing::Color::Green;
			this->label13->Location = System::Drawing::Point(40, 7);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(315, 18);
			this->label13->TabIndex = 1;
			this->label13->Text = L"Please Select A Pivot Controller Address";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(23, 131);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(808, 16);
			this->label11->TabIndex = 101;
			this->label11->Text = L"ii)The Status SEQ Register from each controller selected, must be identical to th" 
				L"e Vector Sequential Mask Trigger programmed ";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label14->Location = System::Drawing::Point(36, 147);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(97, 16);
			this->label14->TabIndex = 102;
			this->label14->Text = L"in this window.";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label15->ForeColor = System::Drawing::Color::Black;
			this->label15->Location = System::Drawing::Point(23, 163);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(489, 16);
			this->label15->TabIndex = 103;
			this->label15->Text = L"iii) More of one Pivot Controller can be programmed, per ST600uNET board.";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Font = (gcnew System::Drawing::Font(L"Arial", 10, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label17->ForeColor = System::Drawing::Color::Black;
			this->label17->Location = System::Drawing::Point(23, 179);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(369, 16);
			this->label17->TabIndex = 104;
			this->label17->Text = L"vi) Only one Pivot Controller can be setup  per commnad.";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Underline, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label28->Location = System::Drawing::Point(29, 276);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(149, 13);
			this->label28->TabIndex = 115;
			this->label28->Text = L"Trigger Mask Sent to ADDR0:";
//			this->label28->Click += gcnew System::EventHandler(this, &Sequential_Trigger::label28_Click);
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Underline, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label29->Location = System::Drawing::Point(29, 293);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(149, 13);
			this->label29->TabIndex = 116;
			this->label29->Text = L"Trigger Mask Sent to ADDR3:";
			// 
			// Sequential_Trigger
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(849, 587);
			this->Controls->Add(this->label17);
			this->Controls->Add(this->label15);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->panel7);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->panel3);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->Name = L"Sequential_Trigger";
			this->Text = L"Sequential_Trigger";
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->panel6->ResumeLayout(false);
			this->panel6->PerformLayout();
			this->panel5->ResumeLayout(false);
			this->panel5->PerformLayout();
			this->panel4->ResumeLayout(false);
			this->panel4->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->panel7->ResumeLayout(false);
			this->panel7->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Close22_Click(System::Object^  sender, System::EventArgs^  e) {// Close Windows

				 Form::Close();
			 }
//	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
//			 }
//private: System::Void Sequential_Trigger_Load(System::Object^  sender, System::EventArgs^  e) {
//		 }
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label5_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void radioButton1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Mask_Click(System::Object^  sender, System::EventArgs^  e) {// Create the mask word to be sent to RMV858

          //Clear the variable
		   sequential_trigger_mask=0;
		    String ^ str;
		   seq_motion_controllers_enabled =0 ;
		    unsigned short int Error_number =0;

          // No clean pivot_controllers_mask, may was created before , and we want to keep for interpolation 

			 if (Pivot0->Checked){
				 pivot_controllers_mask |=0x1;
				 if(motor_addr_mask==1){				
				 MC_AD0->Checked=true;
			     MC_AD0->AutoCheck=false;
			     MR_AD0->AutoCheck=false;
				 }
			 }else pivot_controllers_mask &=0xFE;

			 if (Pivot1->Checked) {
				 pivot_controllers_mask |=0x2;
                 if(motor_addr_mask==2){				   
				 MC_AD1->Checked=true;
                 MC_AD1->AutoCheck=false;
			     MR_AD1->AutoCheck=false;
				 }
			 }else pivot_controllers_mask &=0xFD;

			 if (Pivot2->Checked){
				 pivot_controllers_mask |=0x4;
                 if(motor_addr_mask==4){	                  
				 MC_AD2->Checked=true;
			     MC_AD2->AutoCheck=false;
			     MR_AD2->AutoCheck=false;
				 }
			 }else pivot_controllers_mask &=0xFB;

			 if (Pivot3->Checked){
				 pivot_controllers_mask |=0x8;
				 if(motor_addr_mask==8){	
    			 MC_AD3->Checked=true;
			     MC_AD3->AutoCheck=false;
			     MR_AD3->AutoCheck=false;
				 }
			 }else pivot_controllers_mask &=0x07;
			   
			   
			   if (STAddr0->Checked){
                    				
				 seq_motion_controllers_enabled  |= 0x01 ;
                 if (MR_AD0->Checked)  sequential_trigger_mask &= 0xFE;
                 if (MC_AD0->Checked) sequential_trigger_mask |= 0x01;
			 }
			 if (STAddr1->Checked){
				 seq_motion_controllers_enabled  |= 0x02 ;
                if (MR_AD1->Checked)  sequential_trigger_mask &= 0xFD;
                if (MC_AD1->Checked) sequential_trigger_mask |= 0x02;
			 }
			 if (STAddr2->Checked){
				  seq_motion_controllers_enabled  |= 0x04 ;
               if (MR_AD2->Checked)  sequential_trigger_mask &= 0xFB;
               if (MC_AD2->Checked)  sequential_trigger_mask |= 0x04;
			 }
			 if (STAddr3->Checked){
				 seq_motion_controllers_enabled  |= 0x08 ;
                if (MR_AD3->Checked)  sequential_trigger_mask &= 0xF7;
                if (MC_AD3->Checked)  sequential_trigger_mask |= 0x08;
			 }

			 CEnabled->Text = System::Convert::ToString(seq_motion_controllers_enabled,16) ;
             MaskT->Text = System::Convert::ToString(sequential_trigger_mask,16) ;
			 PivotC->Text = System::Convert::ToString(pivot_controllers_mask,16) ;

					
         //Open the SEQ window
           		   
			  if (ST600uNet_Set_Sequential_Motion(motor_addr_mask,seq_motion_controllers_enabled ,pivot_controllers_mask, & Error_number))
			  {
		   	            //  ST600uNet_GetError(Error);
				        // marshal_as<String^>(Error); 
				  str =  "Error Number :#" ;
				           str +=  System::Convert::ToString(Error_number, 16) ;    
					       MessageBox::Show( str,"Error in setting sequential motion  ", MessageBoxButtons::OK,MessageBoxIcon::Hand);   
						  return;
		      }// No Error Set up the Mask   
			  			
			  
			  
		 }
private: System::Void DisableSEQM_Click(System::Object^  sender, System::EventArgs^  e) {// Disable Sequential Motion 

		    unsigned short int Error_number =0;
		    String ^ str;
		   

			       if( ST600uNet_Disable_Sequential_Motion(motor_addr_mask, &Error_number))
					   {
				  	    str =  "Error Number :#" ;
				       str +=  System::Convert::ToString(Error_number, 16) ;    
				       MessageBox::Show( str,"Error in setting sequential motion ", MessageBoxButtons::OK,MessageBoxIcon::Hand);	
					   }

		 }
private: System::Void SEQMask_Click(System::Object^  sender, System::EventArgs^  e) {// Set The Tigger mask 

           unsigned short int Error_number =0;
		    String ^ str;
		   
          if  ( ST600uNet_Sequential_Motion_Interrupt_MASK(motor_addr_mask, sequential_trigger_mask ,& Error_number))         
			  {
					// ST600uNet_GetError(Error);
				     //str =  marshal_as<String^>(Error);     
				  str =  "Error Number :#" ;
				      str +=  System::Convert::ToString(Error_number, 16) ;    
				     MessageBox::Show( str,"Error in setting sequential motion ", MessageBoxButtons::OK,MessageBoxIcon::Hand);	
			  }		


		 }
		 /*
private: System::Void label26_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label28_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void label22_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
		 */
};
}
