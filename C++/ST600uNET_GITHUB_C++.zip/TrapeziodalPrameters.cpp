#include "StdAfx.h"
#include "TrapeziodalParameters.h"

